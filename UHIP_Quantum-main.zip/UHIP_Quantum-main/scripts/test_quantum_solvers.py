"""
Test Quantum-Inspired Solvers

Quick validation of Simulated Quantum Annealing components.
"""

import numpy as np
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.solvers.quantum import (
    TrotterExpansion,
    MetropolisSampler,
    SimulatedQuantumAnnealing,
    AnnealingSchedule,
    FlipStrategy
)
from core.qubo_formulation.ising_converter import IsingConverter

print("="*70)
print("Testing Quantum-Inspired Solver Modules")
print("="*70)

# Test 1: TrotterExpansion
print("\n1. Testing TrotterExpansion...")
trotter = TrotterExpansion(num_trotter_replicas=5)
print(f"   Created: {trotter}")

# Test coupling strength calculation
beta = 2.0
gamma = 1.5
J_tau = trotter.compute_coupling_strength(beta, gamma)
print(f"   J_τ({beta}, {gamma}) = {J_tau:.6f}")

# Test replica initialization
n = 10
replicas = trotter.initialize_replicas(n)
print(f"   Initialized replicas: shape {replicas.shape}, values in {{-1, +1}}")
assert replicas.shape == (5, n)
assert np.all(np.isin(replicas, [-1, 1]))

# Test replica energy calculation
h = np.random.randn(n)
J = np.random.randn(n, n)
J = (J + J.T) / 2
np.fill_diagonal(J, 0)
energy = trotter.compute_effective_energy(replicas, h, J, J_tau)
print(f"   Effective energy: {energy:.6f}")

# Test delta energy (single flip)
replica_idx, spin_idx = 0, 3
delta_E = trotter.compute_replica_delta_energy(replicas, h, J, J_tau, replica_idx, spin_idx)
print(f"   Delta E for flip [{replica_idx}, {spin_idx}]: {delta_E:.6f}")

# Verify delta E is correct
replicas_new = replicas.copy()
replicas_new[replica_idx, spin_idx] *= -1
energy_new = trotter.compute_effective_energy(replicas_new, h, J, J_tau)
actual_delta = energy_new - energy
print(f"   Verification: Computed={delta_E:.6f}, Actual={actual_delta:.6f}, " 
      f"Error={abs(delta_E - actual_delta):.9f}")
assert abs(delta_E - actual_delta) < 1e-6, "Delta E calculation error!"

print("   ✓ TrotterExpansion tests passed!")

# Test 2: MetropolisSampler
print("\n2. Testing MetropolisSampler...")
sampler = MetropolisSampler(flip_strategy=FlipStrategy.SINGLE_REPLICA_SINGLE_SPIN, seed=42)
print(f"   Created: {sampler}")

# Test single Metropolis step
replicas_test = trotter.initialize_replicas(n, rng=np.random.default_rng(42))
replicas_updated, accepted, delta_E = sampler.metropolis_step(
    replicas_test, h, J, J_tau, beta
)
print(f"   Metropolis step: accepted={accepted}, ΔE={delta_E:.6f}")

# Test sampling
replicas_sampled, sampling_info = sampler.sample(
    replicas_test, h, J, J_tau, beta, num_steps=100, burnin=20, thinning=2
)
print(f"   Sampling complete: acceptance rate = {sampling_info['acceptance_rate']:.3f}")
print(f"   ✓ MetropolisSampler tests passed!")

# Test 3: SimulatedQuantumAnnealing (small problem)
print("\n3. Testing SimulatedQuantumAnnealing...")

# Create a simple QUBO problem: minimize x^T Q x
# Use a problem with known structure
np.random.seed(42)
n_qubo = 8
Q = np.random.randn(n_qubo, n_qubo)
Q = (Q + Q.T) / 2  # Make symmetric
Q = Q + np.eye(n_qubo) * 0.1  # Ensure well-conditioned

print(f"   QUBO matrix: {n_qubo}×{n_qubo}, symmetric")

# Create annealing schedule
schedule = AnnealingSchedule(
    gamma_initial=2.0,
    gamma_final=0.05,
    temp_initial=0.5,
    temp_final=0.01,
    schedule_type='linear'
)
print(f"   Schedule: Γ: {schedule.gamma_initial} → {schedule.gamma_final}, "
      f"T: {schedule.temp_initial} → {schedule.temp_final}")

# Create SQA solver
sqa = SimulatedQuantumAnnealing(
    num_trotter_replicas=4,
    num_sweeps=100,
    sweeps_per_step=10,
    schedule=schedule,
    flip_strategy=FlipStrategy.SINGLE_REPLICA_SINGLE_SPIN,
    seed=42,
    verbose=False
)
print(f"   Created: {sqa}")

# Solve
print(f"   Running SQA solver...")
result = sqa.solve(Q)

print(f"\n   Results:")
print(f"   - Best energy: {result.best_energy:.6f}")
print(f"   - Solution: {result.best_solution}")
print(f"   - Runtime: {result.runtime:.3f}s")
print(f"   - Iterations: {result.iterations}")
print(f"   - Success: {result.success}")
print(f"   - Average acceptance rate: {result.metadata['average_acceptance_rate']:.3f}")
print(f"   - Final Γ: {result.metadata['final_gamma']:.4f}")
print(f"   - Final T: {result.metadata['final_temperature']:.4f}")

# Verify solution is binary
assert np.all(np.isin(result.best_solution, [0, 1])), "Solution not binary!"
assert len(result.best_solution) == n_qubo, "Solution wrong size!"

# Verify energy is correct
computed_energy = result.best_solution.T @ Q @ result.best_solution
assert abs(computed_energy - result.best_energy) < 1e-6, "Energy mismatch!"

print(f"   ✓ SimulatedQuantumAnnealing tests passed!")

# Test 4: Annealing Schedule
print("\n4. Testing AnnealingSchedule...")
schedule_test = AnnealingSchedule(
    gamma_initial=3.0,
    gamma_final=0.1,
    temp_initial=1.0,
    temp_final=0.01,
    schedule_type='power_law',
    gamma_exponent=2.0,
    temp_exponent=1.5
)

t_max = 100
gammas = [schedule_test.get_gamma(t, t_max) for t in [0, 25, 50, 75, 100]]
temps = [schedule_test.get_temperature(t, t_max) for t in [0, 25, 50, 75, 100]]

print(f"   Γ progression: {' → '.join([f'{g:.3f}' for g in gammas])}")
print(f"   T progression: {' → '.join([f'{t:.3f}' for t in temps])}")

# Verify monotonic decrease
assert all(gammas[i] >= gammas[i+1] for i in range(len(gammas)-1)), "Γ not decreasing!"
print(f"   ✓ AnnealingSchedule tests passed!")

# Summary
print("\n" + "="*70)
print("✓ All quantum-inspired solver module tests passed!")
print("="*70)
print("\nModules created:")
print("  1. trotter_expansion.py      - Suzuki-Trotter decomposition")
print("  2. metropolis_sampler.py     - Monte Carlo sampling")
print("  3. simulated_quantum_annealing.py - Main SQA solver")
print("\nKey features:")
print("  - Rigorous mathematical formulations")
print("  - Path integral Monte Carlo via Trotter expansion")
print("  - Transverse field annealing schedules")
print("  - Comprehensive result tracking")
print("  - Integration with QUBO/Ising formulations")
print("="*70)
