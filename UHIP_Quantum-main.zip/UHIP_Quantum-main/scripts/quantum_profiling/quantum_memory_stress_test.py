"""
Quantum Circuit Memory Stress Testing
======================================

This script performs RAM/memory stress testing for quantum circuits with
different qubit sizes to determine optimal quantum resource allocation.

Tests:
- Qubit sizes from 1 to maximum feasible (based on memory constraints)
- Memory usage (RAM) per qubit size
- Circuit depth and gate count
- Execution time
- Simulator backend performance

Outputs:
- Optimal qubit size recommendation
- Resource usage metrics
- Performance analysis
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import time
import psutil
import sys
from pathlib import Path
from typing import Dict, List, Tuple
import json
import traceback

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

try:
    from qiskit import QuantumCircuit, transpile
    from qiskit.circuit import Parameter
    from qiskit_aer import AerSimulator
    from qiskit.quantum_info import SparsePauliOp
except ImportError:
    print("ERROR: Qiskit not installed. Run: pip install qiskit qiskit-aer")
    sys.exit(1)

from core.quantum_circuits.qaoa_builder import QAOACircuitBuilder
from core.quantum_circuits.backend_interface import BackendManager
from core.qubo_formulation.ising_converter import IsingConverter


class QuantumMemoryStressTester:
    """
    Performs comprehensive memory and resource stress testing for quantum circuits.
    """
    
    def __init__(self, max_qubits: int = 25, results_dir: Path = None):
        """
        Initialize stress tester.
        
        Args:
            max_qubits: Maximum number of qubits to test (default: 25)
            results_dir: Directory to save results
        """
        self.max_qubits = max_qubits
        self.results_dir = results_dir or Path("data/results/quantum_stress_test")
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        self.process = psutil.Process()
        self.results = []
        
    def get_memory_mb(self) -> float:
        """Get current memory usage in MB."""
        return self.process.memory_info().rss / 1024 / 1024
    
    def create_test_qubo(self, n_qubits: int) -> np.ndarray:
        """
        Create a test QUBO matrix for n qubits.
        
        Args:
            n_qubits: Number of qubits/variables
            
        Returns:
            QUBO matrix (n_qubits x n_qubits)
        """
        # Create a random symmetric QUBO matrix
        np.random.seed(42)
        Q = np.random.randn(n_qubits, n_qubits)
        Q = (Q + Q.T) / 2  # Make symmetric
        return Q
    
    def test_qaoa_circuit(self, n_qubits: int, p: int = 1) -> Dict:
        """
        Test QAOA circuit for given number of qubits.
        
        Args:
            n_qubits: Number of qubits
            p: QAOA circuit depth (default: 1)
            
        Returns:
            Dictionary with test results
        """
        result = {
            'n_qubits': n_qubits,
            'p_layers': p,
            'success': False,
            'memory_mb': 0,
            'circuit_depth': 0,
            'gate_count': 0,
            'cx_gate_count': 0,
            'single_qubit_gates': 0,
            'two_qubit_gates': 0,
            'build_time_s': 0,
            'transpile_time_s': 0,
            'execute_time_s': 0,
            'total_time_s': 0,
            'statevector_size': 2**n_qubits,
            'error': None
        }
        
        try:
            # Measure memory before
            mem_before = self.get_memory_mb()
            
            # Create QUBO
            Q = self.create_test_qubo(n_qubits)
            
            # Convert to Ising
            converter = IsingConverter()
            ising = converter.qubo_to_ising(Q)
            
            # Build QAOA circuit
            start_build = time.time()
            builder = QAOACircuitBuilder(p=p)
            circuit = builder.build_qaoa_circuit(ising)
            result['build_time_s'] = time.time() - start_build
            
            # Get circuit metrics
            result['circuit_depth'] = circuit.depth()
            ops = circuit.count_ops()
            result['gate_count'] = sum(ops.values())
            result['cx_gate_count'] = ops.get('cx', 0) + ops.get('cz', 0)
            result['single_qubit_gates'] = result['gate_count'] - result['cx_gate_count']
            result['two_qubit_gates'] = result['cx_gate_count']
            
            # Transpile circuit
            start_transpile = time.time()
            simulator = AerSimulator()
            transpiled = transpile(circuit, simulator, optimization_level=1)
            result['transpile_time_s'] = time.time() - start_transpile
            
            # Execute circuit (if feasible)
            if n_qubits <= 20:  # Only execute for smaller circuits
                start_execute = time.time()
                # Bind parameters to random values for execution
                params = {param: np.random.rand() for param in circuit.parameters}
                bound_circuit = circuit.assign_parameters(params)
                job = simulator.run(bound_circuit, shots=1024)
                job.result()  # Wait for completion
                result['execute_time_s'] = time.time() - start_execute
            
            # Measure memory after
            mem_after = self.get_memory_mb()
            result['memory_mb'] = mem_after - mem_before
            
            result['total_time_s'] = result['build_time_s'] + result['transpile_time_s'] + result['execute_time_s']
            result['success'] = True
            
        except Exception as e:
            result['error'] = str(e)
            result['success'] = False
            print(f"  ✗ Error at {n_qubits} qubits: {str(e)}")
        
        return result
    
    def test_simple_circuit(self, n_qubits: int) -> Dict:
        """
        Test a simple quantum circuit for baseline measurements.
        
        Args:
            n_qubits: Number of qubits
            
        Returns:
            Dictionary with test results
        """
        result = {
            'n_qubits': n_qubits,
            'type': 'simple',
            'success': False,
            'memory_mb': 0,
            'build_time_s': 0,
            'execute_time_s': 0,
            'statevector_size': 2**n_qubits,
            'error': None
        }
        
        try:
            mem_before = self.get_memory_mb()
            
            # Build simple circuit
            start = time.time()
            circuit = QuantumCircuit(n_qubits)
            circuit.h(range(n_qubits))  # Hadamard on all qubits
            for i in range(n_qubits - 1):
                circuit.cx(i, i + 1)  # Linear entanglement
            circuit.measure_all()
            result['build_time_s'] = time.time() - start
            
            # Execute if feasible
            if n_qubits <= 20:
                start = time.time()
                simulator = AerSimulator()
                job = simulator.run(circuit, shots=1024)
                job.result()
                result['execute_time_s'] = time.time() - start
            
            mem_after = self.get_memory_mb()
            result['memory_mb'] = mem_after - mem_before
            result['success'] = True
            
        except Exception as e:
            result['error'] = str(e)
            result['success'] = False
        
        return result
    
    def run_stress_test(self, test_simple: bool = True, test_qaoa: bool = True):
        """
        Run complete stress test across qubit range.
        
        Args:
            test_simple: Whether to test simple circuits (baseline)
            test_qaoa: Whether to test QAOA circuits
        """
        print("="*70)
        print("Quantum Circuit Memory Stress Test")
        print("="*70)
        print(f"Testing qubit range: 1 to {self.max_qubits}")
        print(f"Available RAM: {psutil.virtual_memory().total / (1024**3):.2f} GB")
        print(f"Available RAM (free): {psutil.virtual_memory().available / (1024**3):.2f} GB")
        print()
        
        qubit_range = range(1, self.max_qubits + 1)
        
        for n_qubits in qubit_range:
            print(f"\n{'='*70}")
            print(f"Testing {n_qubits} qubits (statevector size: 2^{n_qubits} = {2**n_qubits:,})")
            print(f"{'='*70}")
            
            # Test simple circuit for baseline
            if test_simple:
                print(f"  Testing simple circuit...")
                simple_result = self.test_simple_circuit(n_qubits)
                if simple_result['success']:
                    print(f"  ✓ Simple: Memory={simple_result['memory_mb']:.2f} MB, "
                          f"Build={simple_result['build_time_s']:.4f}s, "
                          f"Execute={simple_result['execute_time_s']:.4f}s")
                self.results.append(simple_result)
            
            # Test QAOA circuit
            if test_qaoa:
                for p in [1, 2, 3]:
                    print(f"  Testing QAOA (p={p})...")
                    qaoa_result = self.test_qaoa_circuit(n_qubits, p=p)
                    if qaoa_result['success']:
                        print(f"  ✓ QAOA-p{p}: Memory={qaoa_result['memory_mb']:.2f} MB, "
                              f"Depth={qaoa_result['circuit_depth']}, "
                              f"Gates={qaoa_result['gate_count']}, "
                              f"Time={qaoa_result['total_time_s']:.4f}s")
                    self.results.append(qaoa_result)
                    
                    # Break if memory usage is too high
                    if qaoa_result['success'] and qaoa_result['memory_mb'] > 1000:  # 1 GB threshold
                        print(f"\n  ⚠ Memory threshold exceeded at {n_qubits} qubits (p={p})")
                        print(f"    Stopping further tests for this qubit count")
                        break
            
            # Check if we should stop
            if self.results:
                last_result = self.results[-1]
                if last_result.get('memory_mb', 0) > 2000:  # 2 GB hard limit
                    print(f"\n⚠ Hard memory limit exceeded at {n_qubits} qubits")
                    print(f"  Stopping stress test")
                    break
    
    def analyze_results(self) -> Dict:
        """
        Analyze test results and provide recommendations.
        
        Returns:
            Dictionary with analysis and recommendations
        """
        df = pd.DataFrame(self.results)
        df_success = df[df['success'] == True]
        
        if len(df_success) == 0:
            return {'error': 'No successful tests'}
        
        # Filter QAOA results
        df_qaoa = df_success[df_success.get('p_layers', 0) > 0].copy()
        
        analysis = {
            'max_qubits_tested': int(df_success['n_qubits'].max()),
            'max_qubits_successful': int(df_success['n_qubits'].max()),
            'total_tests': int(len(df)),
            'successful_tests': int(len(df_success)),
            'failed_tests': int(len(df) - len(df_success)),
        }
        
        if len(df_qaoa) > 0:
            # Find optimal qubit size (best balance of performance and resources)
            # Use 100 MB memory threshold for "feasible" simulation
            df_feasible = df_qaoa[df_qaoa['memory_mb'] < 100]
            
            if len(df_feasible) > 0:
                optimal_idx = df_feasible['n_qubits'].idxmax()
                optimal = df_feasible.loc[optimal_idx]
                
                analysis.update({
                    'recommended_qubits': int(optimal['n_qubits']),
                    'recommended_p_layers': int(optimal['p_layers']),
                    'recommended_circuit_depth': int(optimal['circuit_depth']),
                    'recommended_gate_count': int(optimal['gate_count']),
                    'estimated_memory_mb': float(optimal['memory_mb']),
                    'estimated_time_s': float(optimal['total_time_s']),
                })
            
            # Memory scaling analysis
            if len(df_qaoa) > 1:
                # Fit exponential: memory ~ a * 2^(b * n_qubits)
                log_mem = np.log(df_qaoa['memory_mb'].values + 1)
                n_qubits = df_qaoa['n_qubits'].values
                
                if len(n_qubits) > 1:
                    coeffs = np.polyfit(n_qubits, log_mem, 1)
                    analysis['memory_scaling_exponent'] = float(coeffs[0])
        
        return analysis
    
    def generate_report(self):
        """
        Generate comprehensive report with visualizations.
        """
        df = pd.DataFrame(self.results)
        df_success = df[df['success'] == True]
        
        print("\n" + "="*70)
        print("STRESS TEST RESULTS")
        print("="*70)
        
        # Summary statistics
        analysis = self.analyze_results()
        
        print("\n### Summary:")
        print(f"  Total tests: {analysis['total_tests']}")
        print(f"  Successful: {analysis['successful_tests']}")
        print(f"  Failed: {analysis['failed_tests']}")
        print(f"  Max qubits tested: {analysis['max_qubits_tested']}")
        
        if 'recommended_qubits' in analysis:
            print("\n### Recommendations:")
            print(f"  Optimal qubit count: {analysis['recommended_qubits']}")
            print(f"  Recommended p-layers: {analysis['recommended_p_layers']}")
            print(f"  Circuit depth: {analysis['recommended_circuit_depth']}")
            print(f"  Gate count: {analysis['recommended_gate_count']}")
            print(f"  Estimated memory: {analysis['estimated_memory_mb']:.2f} MB")
            print(f"  Estimated time: {analysis['estimated_time_s']:.4f} s")
        
        # Save results
        results_file = self.results_dir / 'stress_test_results.csv'
        df.to_csv(results_file, index=False)
        print(f"\n✓ Results saved to: {results_file}")
        
        analysis_file = self.results_dir / 'analysis.json'
        with open(analysis_file, 'w') as f:
            json.dump(analysis, f, indent=2)
        print(f"✓ Analysis saved to: {analysis_file}")
        
        # Generate visualizations
        self.plot_results(df_success)
        
        return analysis
    
    def plot_results(self, df: pd.DataFrame):
        """
        Create visualization plots.
        
        Args:
            df: DataFrame with successful test results
        """
        # Filter for plotting
        df_qaoa = df[df.get('p_layers', 0) > 0].copy()
        
        if len(df_qaoa) == 0:
            print("No QAOA results to plot")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        
        # 1. Memory vs Qubits
        for p in df_qaoa['p_layers'].unique():
            df_p = df_qaoa[df_qaoa['p_layers'] == p]
            axes[0, 0].plot(df_p['n_qubits'], df_p['memory_mb'], 
                          marker='o', linewidth=2, label=f'p={int(p)}')
        axes[0, 0].set_xlabel('Number of Qubits')
        axes[0, 0].set_ylabel('Memory Usage (MB)')
        axes[0, 0].set_title('Memory Requirements vs Qubit Count')
        axes[0, 0].set_yscale('log')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)
        
        # 2. Circuit Depth vs Qubits
        for p in df_qaoa['p_layers'].unique():
            df_p = df_qaoa[df_qaoa['p_layers'] == p]
            axes[0, 1].plot(df_p['n_qubits'], df_p['circuit_depth'], 
                          marker='s', linewidth=2, label=f'p={int(p)}')
        axes[0, 1].set_xlabel('Number of Qubits')
        axes[0, 1].set_ylabel('Circuit Depth')
        axes[0, 1].set_title('Circuit Depth vs Qubit Count')
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)
        
        # 3. Gate Count vs Qubits
        for p in df_qaoa['p_layers'].unique():
            df_p = df_qaoa[df_qaoa['p_layers'] == p]
            axes[1, 0].plot(df_p['n_qubits'], df_p['gate_count'], 
                          marker='^', linewidth=2, label=f'p={int(p)}')
        axes[1, 0].set_xlabel('Number of Qubits')
        axes[1, 0].set_ylabel('Total Gate Count')
        axes[1, 0].set_title('Gate Count vs Qubit Count')
        axes[1, 0].set_yscale('log')
        axes[1, 0].legend()
        axes[1, 0].grid(True, alpha=0.3)
        
        # 4. Execution Time vs Qubits
        for p in df_qaoa['p_layers'].unique():
            df_p = df_qaoa[df_qaoa['p_layers'] == p]
            axes[1, 1].plot(df_p['n_qubits'], df_p['total_time_s'], 
                          marker='D', linewidth=2, label=f'p={int(p)}')
        axes[1, 1].set_xlabel('Number of Qubits')
        axes[1, 1].set_ylabel('Total Time (seconds)')
        axes[1, 1].set_title('Execution Time vs Qubit Count')
        axes[1, 1].set_yscale('log')
        axes[1, 1].legend()
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        plot_file = self.results_dir / 'stress_test_analysis.png'
        plt.savefig(plot_file, dpi=300, bbox_inches='tight')
        print(f"✓ Plot saved to: {plot_file}")
        
        plt.close()


def main():
    """Main execution function."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Quantum Circuit Memory Stress Test')
    parser.add_argument('--max-qubits', type=int, default=20,
                      help='Maximum number of qubits to test (default: 20)')
    parser.add_argument('--results-dir', type=str, default='data/results/quantum_stress_test',
                      help='Directory to save results')
    parser.add_argument('--skip-simple', action='store_true',
                      help='Skip simple circuit tests')
    parser.add_argument('--skip-qaoa', action='store_true',
                      help='Skip QAOA circuit tests')
    
    args = parser.parse_args()
    
    # Create tester
    tester = QuantumMemoryStressTester(
        max_qubits=args.max_qubits,
        results_dir=Path(args.results_dir)
    )
    
    # Run stress test
    tester.run_stress_test(
        test_simple=not args.skip_simple,
        test_qaoa=not args.skip_qaoa
    )
    
    # Generate report
    analysis = tester.generate_report()
    
    print("\n" + "="*70)
    print("Stress test complete!")
    print("="*70)
    
    return analysis


if __name__ == '__main__':
    main()
