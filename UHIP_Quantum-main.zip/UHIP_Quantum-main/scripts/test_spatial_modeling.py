#!/usr/bin/env python3
"""
Test script for spatial modeling modules.

Tests the urban grid, heat diffusion, and connectivity analysis components.
"""

import numpy as np
import sys

print("Testing Spatial Modeling Modules...")
print("=" * 60)

# Test 1: UrbanGrid
print("\n1. Testing UrbanGrid...")
try:
    from core.spatial_modeling import UrbanGrid, create_synthetic_grid
    
    # Create grid
    grid = UrbanGrid(n_rows=10, n_cols=10, cell_size=50.0)
    print(f"   ✓ Created grid: {grid}")
    
    # Test indexing
    k = grid.flatten_index(5, 7)
    row, col = grid.unflatten_index(k)
    assert row == 5 and col == 7, "Index conversion failed"
    print(f"   ✓ Index conversion: (5,7) -> {k} -> ({row},{col})")
    
    # Test centroids
    centroid = grid.get_centroid(0)
    print(f"   ✓ Centroid of cell 0: {centroid}")
    
    # Test distances
    dist = grid.get_distance(0, 99)
    print(f"   ✓ Distance from corner to corner: {dist:.2f} m")
    
    # Test neighbors
    neighbors = grid.get_neighbors(50, connectivity=4)
    print(f"   ✓ Cell 50 has {len(neighbors)} neighbors (4-connected)")
    
    # Test temperature field
    temp_field = np.random.uniform(25, 35, (10, 10))
    grid.set_temperature_field(temp_field)
    print(f"   ✓ Set temperature field: {temp_field.shape}")
    
    # Test synthetic grid
    synthetic_grid = create_synthetic_grid(20, 20, random_seed=42)
    candidates = synthetic_grid.get_candidate_cells()
    print(f"   ✓ Synthetic grid has {len(candidates)} candidate cells")
    
    print("   ✓ UrbanGrid tests PASSED")
    
except Exception as e:
    print(f"   ✗ UrbanGrid tests FAILED: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 2: HeatDiffusionSolver
print("\n2. Testing HeatDiffusionSolver...")
try:
    from core.spatial_modeling import HeatDiffusionSolver
    
    # Create solver
    grid = UrbanGrid(20, 20, cell_size=50.0)
    solver = HeatDiffusionSolver(grid, alpha=1e-5, method='explicit')
    print(f"   ✓ Created solver: {solver}")
    print(f"   ✓ Stable timestep: {solver.dt_stable:.2f} seconds")
    
    # Set initial temperature
    solver.set_initial_temperature(30.0)
    print(f"   ✓ Set uniform initial temperature: 30°C")
    
    # Add green space cooling
    green_cells = [210, 211, 212, 230, 231, 232]  # 2x3 patch
    solver.add_green_space_cooling(green_cells, cooling_rate=2.0)
    print(f"   ✓ Added cooling at {len(green_cells)} green cells")
    
    # Simulate
    result = solver.evolve(t_final=3600, dt=solver.dt_stable)
    print(f"   ✓ Simulated 1 hour: {len(result['temperatures'])} snapshots")
    
    # Check temperature reduction
    stats = solver.get_statistics()
    print(f"   ✓ Final temperature: mean={stats['mean']:.2f}°C, "
          f"min={stats['min']:.2f}°C, max={stats['max']:.2f}°C")
    
    # Test implicit method
    solver2 = HeatDiffusionSolver(grid, alpha=1e-5, method='implicit')
    solver2.set_initial_temperature(30.0)
    solver2.add_green_space_cooling(green_cells, cooling_rate=2.0)
    result2 = solver2.evolve(t_final=1800, dt=100)  # Larger timestep
    print(f"   ✓ Implicit method simulation completed")
    
    print("   ✓ HeatDiffusionSolver tests PASSED")
    
except Exception as e:
    print(f"   ✗ HeatDiffusionSolver tests FAILED: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 3: ConnectivityAnalyzer
print("\n3. Testing ConnectivityAnalyzer...")
try:
    from core.spatial_modeling import ConnectivityAnalyzer, analyze_green_network_coverage
    
    # Create analyzer
    grid = UrbanGrid(10, 10, cell_size=50.0)
    analyzer = ConnectivityAnalyzer(grid, connectivity=4)
    print(f"   ✓ Created analyzer: {analyzer}")
    
    # Test connected network
    connected_cells = [44, 45, 54, 55]  # 2x2 square
    is_connected = analyzer.verify_connectivity(connected_cells)
    print(f"   ✓ Connected cells (2x2 square): {is_connected}")
    assert is_connected, "2x2 square should be connected"
    
    # Test disconnected network
    disconnected_cells = [10, 11, 12, 88, 89]  # Two separate groups
    is_connected = analyzer.verify_connectivity(disconnected_cells)
    n_components = analyzer.count_components(disconnected_cells)
    print(f"   ✓ Disconnected cells: connected={is_connected}, components={n_components}")
    assert not is_connected, "Should be disconnected"
    assert n_components == 2, "Should have 2 components"
    
    # Test connectivity metrics
    metrics = analyzer.compute_connectivity_metrics(connected_cells)
    print(f"   ✓ Connectivity metrics: {metrics['n_components']} components, "
          f"avg_degree={metrics['avg_degree']:.2f}")
    
    # Test distance computation
    green_cells = [22, 23, 32, 33]
    distances = analyzer.compute_distances(green_cells, [0, 99], metric='euclidean')
    print(f"   ✓ Distance matrix shape: {distances.shape}")
    
    # Test coverage analysis
    coverage = analyze_green_network_coverage(grid, green_cells, service_distance=150.0)
    print(f"   ✓ Green coverage: {coverage['coverage_fraction']:.1%}, "
          f"avg_distance={coverage['avg_distance_to_green']:.1f}m")
    
    # Test solution validation
    solution = np.zeros(50)
    solution[[10, 11, 12, 20, 21]] = 1  # Select some cells
    candidate_indices = list(range(50))
    validation = analyzer.validate_solution_connectivity(solution, candidate_indices)
    print(f"   ✓ Solution validation: {validation['n_selected']} selected, "
          f"connected={validation['is_connected']}")
    
    print("   ✓ ConnectivityAnalyzer tests PASSED")
    
except Exception as e:
    print(f"   ✗ ConnectivityAnalyzer tests FAILED: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 4: Integration with existing modules
print("\n4. Testing integration with existing modules...")
try:
    from core.problem_modeling.cooling_kernels import GaussianCoolingKernel
    from core.spatial_modeling import UrbanGrid
    
    # Create grid and kernel
    grid = UrbanGrid(15, 15, cell_size=50.0)
    kernel = GaussianCoolingKernel(sigma=75.0, amplitude=-1.5)
    
    # Get candidate positions
    candidates = grid.get_candidate_cells()[:50]  # First 50
    positions = np.array([grid.get_centroid(k) for k in candidates])
    
    # Compute kernel matrix
    K = kernel.kernel_matrix(positions)
    print(f"   ✓ Computed cooling kernel matrix: {K.shape}")
    print(f"   ✓ Kernel sparsity: {np.sum(K == 0) / K.size:.1%} zeros")
    
    print("   ✓ Integration tests PASSED")
    
except Exception as e:
    print(f"   ✗ Integration tests FAILED: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n" + "=" * 60)
print("All tests PASSED! ✓")
print("=" * 60)
