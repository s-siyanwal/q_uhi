"""
Test script to verify classical QUBO solvers

This script creates a simple QUBO problem and tests all three classical solvers.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import numpy as np
from core.solvers.classical import (
    SimulatedAnnealingSolver,
    SimulatedAnnealingConfig,
    TabuSearchSolver,
    TabuSearchConfig,
    GeneticAlgorithmSolver,
    GeneticAlgorithmConfig
)

def create_test_qubo(n=20, seed=42):
    """Create a simple test QUBO matrix."""
    rng = np.random.default_rng(seed)
    
    # Create random symmetric QUBO
    Q = rng.random((n, n)) - 0.5
    Q = (Q + Q.T) / 2
    
    # Add diagonal to encourage sparsity
    np.fill_diagonal(Q, rng.random(n) * 2 - 1)
    
    return Q

def test_simulated_annealing():
    """Test Simulated Annealing solver."""
    print("=" * 60)
    print("Testing Simulated Annealing Solver")
    print("=" * 60)
    
    Q = create_test_qubo(n=20)
    
    solver = SimulatedAnnealingSolver(seed=42)
    config = SimulatedAnnealingConfig(
        max_iterations=2000,
        initial_temperature=10.0,
        cooling_schedule='exponential',
        cooling_rate=0.95,
        verbose=True
    )
    
    result = solver.solve(Q, config=config)
    
    print(f"\nResult:")
    print(f"  Best energy: {result.best_energy:.6f}")
    print(f"  Solution: {result.best_solution[:10]}... (showing first 10 bits)")
    print(f"  Iterations: {result.iterations}")
    print(f"  Runtime: {result.runtime:.3f}s")
    print(f"  Success: {result.success}")
    
    return result

def test_tabu_search():
    """Test Tabu Search solver."""
    print("\n" + "=" * 60)
    print("Testing Tabu Search Solver")
    print("=" * 60)
    
    Q = create_test_qubo(n=20)
    
    solver = TabuSearchSolver(seed=42)
    config = TabuSearchConfig(
        max_iterations=2000,
        tabu_tenure=10,
        adaptive_tabu=True,
        aspiration_enabled=True,
        verbose=True
    )
    
    result = solver.solve(Q, config=config)
    
    print(f"\nResult:")
    print(f"  Best energy: {result.best_energy:.6f}")
    print(f"  Solution: {result.best_solution[:10]}... (showing first 10 bits)")
    print(f"  Iterations: {result.iterations}")
    print(f"  Runtime: {result.runtime:.3f}s")
    print(f"  Success: {result.success}")
    
    return result

def test_genetic_algorithm():
    """Test Genetic Algorithm solver."""
    print("\n" + "=" * 60)
    print("Testing Genetic Algorithm Solver")
    print("=" * 60)
    
    Q = create_test_qubo(n=20)
    
    solver = GeneticAlgorithmSolver(seed=42)
    config = GeneticAlgorithmConfig(
        population_size=50,
        max_generations=100,
        tournament_size=3,
        crossover_rate=0.8,
        mutation_rate=0.02,
        crossover_type='single_point',
        elitism_count=2,
        verbose=True
    )
    
    result = solver.solve(Q, config=config)
    
    print(f"\nResult:")
    print(f"  Best energy: {result.best_energy:.6f}")
    print(f"  Solution: {result.best_solution[:10]}... (showing first 10 bits)")
    print(f"  Generations: {result.iterations}")
    print(f"  Runtime: {result.runtime:.3f}s")
    print(f"  Success: {result.success}")
    
    return result

def compare_solvers():
    """Compare all three solvers on the same problem."""
    print("\n" + "=" * 60)
    print("Comparing All Solvers on Same Problem")
    print("=" * 60)
    
    Q = create_test_qubo(n=30, seed=123)
    
    # Simulated Annealing
    sa_solver = SimulatedAnnealingSolver(seed=42)
    sa_config = SimulatedAnnealingConfig(max_iterations=3000, verbose=False)
    sa_result = sa_solver.solve(Q, config=sa_config)
    
    # Tabu Search
    ts_solver = TabuSearchSolver(seed=42)
    ts_config = TabuSearchConfig(max_iterations=3000, verbose=False)
    ts_result = ts_solver.solve(Q, config=ts_config)
    
    # Genetic Algorithm
    ga_solver = GeneticAlgorithmSolver(seed=42)
    ga_config = GeneticAlgorithmConfig(population_size=50, max_generations=150, verbose=False)
    ga_result = ga_solver.solve(Q, config=ga_config)
    
    print(f"\nResults Comparison:")
    print(f"{'Solver':<25} {'Best Energy':<15} {'Runtime (s)':<15}")
    print("-" * 60)
    print(f"{'Simulated Annealing':<25} {sa_result.best_energy:<15.6f} {sa_result.runtime:<15.3f}")
    print(f"{'Tabu Search':<25} {ts_result.best_energy:<15.6f} {ts_result.runtime:<15.3f}")
    print(f"{'Genetic Algorithm':<25} {ga_result.best_energy:<15.6f} {ga_result.runtime:<15.3f}")
    
    # Find best
    results = {
        'Simulated Annealing': sa_result.best_energy,
        'Tabu Search': ts_result.best_energy,
        'Genetic Algorithm': ga_result.best_energy
    }
    best_solver = min(results, key=results.get)
    print(f"\nBest solver: {best_solver} with energy {results[best_solver]:.6f}")

if __name__ == "__main__":
    # Test each solver individually
    test_simulated_annealing()
    test_tabu_search()
    test_genetic_algorithm()
    
    # Compare all solvers
    compare_solvers()
    
    print("\n" + "=" * 60)
    print("All tests completed successfully!")
    print("=" * 60)
