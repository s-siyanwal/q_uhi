"""
Base Solver Class for Classical QUBO Solvers

Provides a common interface and utility methods for classical optimization algorithms.
"""

import numpy as np
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
import time

from core.utils.math_helpers import calculate_energy_from_qubo
from core.utils.experiment_logger import ExperimentLogger


@dataclass
class SolverResult:
    """
    Structured result from a QUBO solver.
    
    Attributes:
        best_solution: Best binary solution found
        best_energy: Energy of best solution
        convergence_history: List of energies over iterations
        metadata: Additional solver-specific information
        runtime: Total runtime in seconds
        iterations: Total iterations performed
        success: Whether solver completed successfully
    """
    best_solution: np.ndarray
    best_energy: float
    convergence_history: List[float] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    runtime: float = 0.0
    iterations: int = 0
    success: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary."""
        return {
            'best_solution': self.best_solution.tolist(),
            'best_energy': float(self.best_energy),
            'convergence_history': [float(e) for e in self.convergence_history],
            'metadata': self.metadata,
            'runtime': float(self.runtime),
            'iterations': int(self.iterations),
            'success': bool(self.success)
        }


class BaseSolver(ABC):
    """
    Abstract base class for classical QUBO solvers.
    
    All solvers should inherit from this class and implement the solve() method.
    Provides common functionality for:
    - Solution validation
    - Energy calculation
    - Logging integration
    - Result structuring
    """
    
    def __init__(self, logger: Optional[ExperimentLogger] = None, seed: Optional[int] = None):
        """
        Initialize base solver.
        
        Args:
            logger: Experiment logger for tracking
            seed: Random seed for reproducibility
        """
        self.logger = logger
        self.rng = np.random.default_rng(seed)
        self.seed = seed
        
        # Performance tracking
        self.start_time = None
        self.iteration_count = 0
        self.energy_history = []
        
    @abstractmethod
    def solve(self, Q: np.ndarray, **kwargs) -> SolverResult:
        """
        Solve the QUBO problem: min x^T Q x, where x ∈ {0,1}^n
        
        Args:
            Q: QUBO matrix (n × n, symmetric)
            **kwargs: Algorithm-specific parameters
            
        Returns:
            SolverResult containing solution and performance data
        """
        pass
    
    def _validate_qubo(self, Q: np.ndarray):
        """
        Validate QUBO matrix.
        
        Args:
            Q: QUBO matrix to validate
            
        Raises:
            ValueError: If Q is invalid
        """
        if Q.ndim != 2:
            raise ValueError(f"Q must be 2D matrix, got {Q.ndim}D")
        
        if Q.shape[0] != Q.shape[1]:
            raise ValueError(f"Q must be square, got shape {Q.shape}")
        
        if not np.allclose(Q, Q.T, atol=1e-8):
            import warnings
            warnings.warn("Q is not symmetric, results may be incorrect")
    
    def _validate_solution(self, x: np.ndarray, Q: np.ndarray):
        """
        Validate that solution is binary and correct dimension.
        
        Args:
            x: Solution vector
            Q: QUBO matrix
            
        Raises:
            ValueError: If solution is invalid
        """
        if len(x) != Q.shape[0]:
            raise ValueError(f"Solution length {len(x)} doesn't match Q dimension {Q.shape[0]}")
        
        if not np.all(np.logical_or(x == 0, x == 1)):
            raise ValueError("Solution must be binary (0 or 1)")
    
    def _calculate_energy(self, x: np.ndarray, Q: np.ndarray) -> float:
        """
        Calculate QUBO energy E = x^T Q x
        
        Args:
            x: Binary solution vector
            Q: QUBO matrix
            
        Returns:
            Energy value
        """
        return calculate_energy_from_qubo(x, Q)
    
    def _initialize_solution(self, n: int, sparsity: Optional[float] = None) -> np.ndarray:
        """
        Generate random initial solution.
        
        Args:
            n: Problem dimension
            sparsity: Fraction of 1s (default 0.5)
            
        Returns:
            Random binary vector
        """
        if sparsity is None:
            return self.rng.integers(0, 2, size=n)
        else:
            return (self.rng.random(n) < sparsity).astype(int)
    
    def _log_iteration(self, iteration: int, energy: float, **kwargs):
        """
        Log iteration to experiment logger if available.
        
        Args:
            iteration: Iteration number
            energy: Current energy
            **kwargs: Additional parameters to log
        """
        if self.logger is not None:
            self.logger.log_iteration(iteration, energy, **kwargs)
    
    def _log_solution(self, solution: np.ndarray, energy: float, is_feasible: bool = True, 
                     metadata: Optional[Dict] = None):
        """
        Log final solution.
        
        Args:
            solution: Binary solution
            energy: Solution energy
            is_feasible: Whether solution is feasible
            metadata: Additional metadata
        """
        if self.logger is not None:
            self.logger.log_solution(solution, energy, is_feasible, metadata)
    
    def _start_timer(self):
        """Start timing the solve process."""
        self.start_time = time.time()
        self.iteration_count = 0
        self.energy_history = []
    
    def _get_runtime(self) -> float:
        """Get elapsed runtime in seconds."""
        if self.start_time is None:
            return 0.0
        return time.time() - self.start_time
    
    def _record_energy(self, energy: float):
        """Record energy in history."""
        self.energy_history.append(float(energy))
        self.iteration_count += 1
    
    def _create_result(self, best_solution: np.ndarray, best_energy: float,
                      metadata: Optional[Dict] = None, success: bool = True) -> SolverResult:
        """
        Create structured result object.
        
        Args:
            best_solution: Best solution found
            best_energy: Energy of best solution
            metadata: Additional solver-specific metadata
            success: Whether solver completed successfully
            
        Returns:
            SolverResult object
        """
        return SolverResult(
            best_solution=best_solution,
            best_energy=best_energy,
            convergence_history=self.energy_history.copy(),
            metadata=metadata or {},
            runtime=self._get_runtime(),
            iterations=self.iteration_count,
            success=success
        )
    
    def __repr__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}(seed={self.seed})"
