"""
Simulated Annealing Solver for QUBO Problems

Implements classical simulated annealing with Metropolis acceptance criterion
for solving binary quadratic unconstrained optimization problems.

Algorithm Reference:
    Kirkpatrick, S., Gelatt, C. D., & Vecchi, M. P. (1983).
    "Optimization by simulated annealing." Science, 220(4598), 671-680.
    
Mathematical Framework:
    At temperature T, accept worse solutions with probability:
        P_accept = exp(-ΔE/T)
    where ΔE = E_new - E_old
    
    Temperature is decreased according to a cooling schedule:
        - Exponential: T(t) = T_0 * α^t, α ∈ (0,1)
        - Logarithmic: T(t) = T_0 / log(1 + t)
        
Theorem (Convergence):
    With logarithmic cooling and sufficient iterations, simulated annealing
    converges to global optimum with probability → 1.
    
    Reference: Geman & Geman (1984), "Stochastic Relaxation, Gibbs Distributions,
    and the Bayesian Restoration of Images", IEEE PAMI.
"""

import numpy as np
from typing import Optional, Literal, Callable, Dict, Any
from dataclasses import dataclass

from core.solvers.classical.base_solver import BaseSolver, SolverResult
from core.utils.math_helpers import (
    metropolis_acceptance_probability,
    cooling_schedule_exponential,
    cooling_schedule_logarithmic,
    calculate_delta_energy_single_flip
)
from core.utils.experiment_logger import ExperimentLogger


@dataclass
class SimulatedAnnealingConfig:
    """
    Configuration for Simulated Annealing solver.
    
    Attributes:
        max_iterations: Maximum number of iterations
        initial_temperature: Starting temperature T_0
        final_temperature: Stopping temperature (optional)
        cooling_schedule: Type of cooling ('exponential' or 'logarithmic')
        cooling_rate: Alpha parameter for exponential cooling (0.85-0.99)
        reheat_interval: Iterations between reheating (0 = no reheating)
        reheat_temperature: Temperature to reheat to
        track_acceptance_rate: Whether to track acceptance statistics
        verbose: Print progress information
    """
    max_iterations: int = 10000
    initial_temperature: float = 100.0
    final_temperature: float = 0.01
    cooling_schedule: Literal['exponential', 'logarithmic'] = 'exponential'
    cooling_rate: float = 0.95
    reheat_interval: int = 0
    reheat_temperature: Optional[float] = None
    track_acceptance_rate: bool = True
    verbose: bool = False


class SimulatedAnnealingSolver(BaseSolver):
    """
    Simulated Annealing solver for QUBO problems.
    
    The algorithm explores the solution space by:
    1. Starting from a random or provided initial solution
    2. Iteratively proposing bit-flip moves
    3. Accepting improvements deterministically
    4. Accepting worse solutions with Metropolis probability
    5. Gradually reducing temperature to freeze at local/global optimum
    
    Features:
    - Multiple cooling schedules (exponential, logarithmic)
    - Optional reheating to escape local minima
    - Efficient delta-energy computation for single bit flips
    - Acceptance rate tracking
    - Best solution recording throughout optimization
    
    Usage:
        >>> solver = SimulatedAnnealingSolver(seed=42)
        >>> config = SimulatedAnnealingConfig(max_iterations=5000, initial_temperature=50.0)
        >>> result = solver.solve(Q, config=config)
        >>> print(f"Best energy: {result.best_energy}")
    """
    
    def __init__(self, logger: Optional[ExperimentLogger] = None, seed: Optional[int] = None):
        """
        Initialize Simulated Annealing solver.
        
        Args:
            logger: Experiment logger for tracking
            seed: Random seed for reproducibility
        """
        super().__init__(logger, seed)
        
        # SA-specific tracking
        self.temperature_history = []
        self.acceptance_history = []
        
    def solve(self, Q: np.ndarray, 
              initial_solution: Optional[np.ndarray] = None,
              config: Optional[SimulatedAnnealingConfig] = None,
              **kwargs) -> SolverResult:
        """
        Solve QUBO problem using Simulated Annealing.
        
        Args:
            Q: QUBO matrix (n × n, symmetric)
            initial_solution: Starting solution (random if None)
            config: Simulated annealing configuration
            **kwargs: Override config parameters
            
        Returns:
            SolverResult with best solution and convergence data
            
        Raises:
            ValueError: If Q is invalid
        """
        # Validate input
        self._validate_qubo(Q)
        n = Q.shape[0]
        
        # Configuration
        if config is None:
            config = SimulatedAnnealingConfig()
        
        # Override with kwargs
        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)
        
        # Initialize
        self._start_timer()
        if initial_solution is None:
            x_current = self._initialize_solution(n)
        else:
            self._validate_solution(initial_solution, Q)
            x_current = initial_solution.copy()
        
        # Calculate initial energy
        E_current = self._calculate_energy(x_current, Q)
        
        # Track best solution
        x_best = x_current.copy()
        E_best = E_current
        
        # Initialize temperature
        temperature = config.initial_temperature
        
        # Setup cooling schedule function
        cooling_fn = self._get_cooling_function(config)
        
        # Acceptance tracking
        n_accepted = 0
        n_proposed = 0
        acceptance_rates = []
        
        # Main optimization loop
        for iteration in range(config.max_iterations):
            # Update temperature
            temperature = cooling_fn(iteration)
            
            # Check stopping criterion
            if temperature < config.final_temperature:
                if config.verbose:
                    print(f"Stopped: temperature {temperature:.6f} < {config.final_temperature}")
                break
            
            # Reheating mechanism
            if (config.reheat_interval > 0 and 
                iteration > 0 and 
                iteration % config.reheat_interval == 0):
                temperature = config.reheat_temperature or config.initial_temperature
                if config.verbose:
                    print(f"Iteration {iteration}: Reheating to T={temperature:.2f}")
            
            # Propose move: flip a random bit
            flip_idx = self.rng.integers(0, n)
            
            # Calculate energy change efficiently
            delta_E = calculate_delta_energy_single_flip(x_current, Q, flip_idx)
            
            # Metropolis acceptance criterion
            accept_prob = metropolis_acceptance_probability(delta_E, temperature)
            accept = self.rng.random() < accept_prob
            
            n_proposed += 1
            if accept:
                n_accepted += 1
                # Apply move
                x_current[flip_idx] = 1 - x_current[flip_idx]
                E_current += delta_E
                
                # Update best solution if improved
                if E_current < E_best:
                    E_best = E_current
                    x_best = x_current.copy()
            
            # Record metrics
            self._record_energy(E_best)
            self.temperature_history.append(temperature)
            if config.track_acceptance_rate:
                current_rate = n_accepted / n_proposed if n_proposed > 0 else 0.0
                acceptance_rates.append(current_rate)
            
            # Logging
            if iteration % 100 == 0 or iteration < 10:
                self._log_iteration(
                    iteration,
                    E_current,
                    temperature=temperature,
                    best_energy=E_best,
                    accepted=accept
                )
                
                if config.verbose and iteration % 1000 == 0:
                    acc_rate = n_accepted / n_proposed if n_proposed > 0 else 0.0
                    print(f"Iter {iteration}: E_curr={E_current:.4f}, E_best={E_best:.4f}, "
                          f"T={temperature:.4f}, acc_rate={acc_rate:.3f}")
        
        # Final logging
        self._log_solution(x_best, E_best, is_feasible=True, metadata={
            'final_temperature': temperature,
            'total_acceptance_rate': n_accepted / n_proposed if n_proposed > 0 else 0.0
        })
        
        # Create result
        metadata = {
            'algorithm': 'simulated_annealing',
            'cooling_schedule': config.cooling_schedule,
            'initial_temperature': config.initial_temperature,
            'final_temperature': temperature,
            'cooling_rate': config.cooling_rate,
            'total_proposed': n_proposed,
            'total_accepted': n_accepted,
            'acceptance_rate': n_accepted / n_proposed if n_proposed > 0 else 0.0,
            'temperature_history': self.temperature_history,
        }
        
        if config.track_acceptance_rate:
            metadata['acceptance_rate_history'] = acceptance_rates
        
        result = self._create_result(x_best, E_best, metadata=metadata)
        
        if config.verbose:
            print(f"\nOptimization complete:")
            print(f"  Best energy: {E_best:.6f}")
            print(f"  Iterations: {iteration + 1}")
            print(f"  Runtime: {result.runtime:.2f}s")
            print(f"  Final temperature: {temperature:.6f}")
            print(f"  Acceptance rate: {metadata['acceptance_rate']:.3f}")
        
        return result
    
    def _get_cooling_function(self, config: SimulatedAnnealingConfig) -> Callable[[int], float]:
        """
        Get cooling schedule function.
        
        Args:
            config: SA configuration
            
        Returns:
            Function that maps iteration -> temperature
        """
        if config.cooling_schedule == 'exponential':
            return lambda t: cooling_schedule_exponential(
                config.initial_temperature, 
                config.cooling_rate, 
                t
            )
        elif config.cooling_schedule == 'logarithmic':
            return lambda t: cooling_schedule_logarithmic(
                config.initial_temperature, 
                t
            )
        else:
            raise ValueError(f"Unknown cooling schedule: {config.cooling_schedule}")
    
    def solve_with_restarts(self, Q: np.ndarray, n_restarts: int = 10,
                           config: Optional[SimulatedAnnealingConfig] = None) -> SolverResult:
        """
        Solve with multiple random restarts and return best solution.
        
        Multiple restarts can help escape poor local minima and increase
        probability of finding global optimum.
        
        Args:
            Q: QUBO matrix
            n_restarts: Number of independent runs
            config: SA configuration
            
        Returns:
            Best result across all restarts
        """
        self._validate_qubo(Q)
        
        best_result = None
        all_energies = []
        
        for restart in range(n_restarts):
            # Solve with new random initial solution
            result = self.solve(Q, initial_solution=None, config=config)
            all_energies.append(result.best_energy)
            
            # Track best
            if best_result is None or result.best_energy < best_result.best_energy:
                best_result = result
            
            if config and config.verbose:
                print(f"Restart {restart + 1}/{n_restarts}: E={result.best_energy:.6f}")
        
        # Add restart metadata
        best_result.metadata['n_restarts'] = n_restarts
        best_result.metadata['all_restart_energies'] = all_energies
        best_result.metadata['restart_energy_std'] = float(np.std(all_energies))
        
        return best_result
    
    def __repr__(self) -> str:
        """String representation."""
        return f"SimulatedAnnealingSolver(seed={self.seed})"
