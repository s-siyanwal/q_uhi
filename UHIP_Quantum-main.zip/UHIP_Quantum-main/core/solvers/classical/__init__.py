"""
Classical Solver Modules for UHI-QUBO Framework

This package provides classical optimization algorithms for solving
QUBO (Quadratic Unconstrained Binary Optimization) problems.

Available Solvers:
- SimulatedAnnealingSolver: Metropolis-based annealing with multiple cooling schedules
- TabuSearchSolver: Tabu search with adaptive tenure and aspiration criteria
- GeneticAlgorithmSolver: Genetic algorithm with tournament selection and elitism

Each solver provides:
- Structured results with convergence history
- Integration with experiment logging
- Multiple restart capabilities
- Comprehensive docstrings with algorithm references
"""

from core.solvers.classical.base_solver import BaseSolver, SolverResult
from core.solvers.classical.simulated_annealing import (
    SimulatedAnnealingSolver,
    SimulatedAnnealingConfig
)
from core.solvers.classical.tabu_search import (
    TabuSearchSolver,
    TabuSearchConfig
)
from core.solvers.classical.genetic_algorithm import (
    GeneticAlgorithmSolver,
    GeneticAlgorithmConfig
)

__all__ = [
    'BaseSolver',
    'SolverResult',
    'SimulatedAnnealingSolver',
    'SimulatedAnnealingConfig',
    'TabuSearchSolver',
    'TabuSearchConfig',
    'GeneticAlgorithmSolver',
    'GeneticAlgorithmConfig',
]
