"""
Genetic Algorithm Solver for QUBO Problems

Implements a classical genetic algorithm with tournament selection, crossover,
and mutation operators for solving binary quadratic unconstrained optimization.

Algorithm Reference:
    Holland, J. H. (1992). "Adaptation in Natural and Artificial Systems."
    MIT Press. (Original work published 1975)
    
    Goldberg, D. E. (1989). "Genetic Algorithms in Search, Optimization,
    and Machine Learning." Addison-Wesley.
    
Mathematical Framework:
    Genetic algorithms evolve a population of solutions through:
    1. Selection: Choose parents based on fitness (lower energy = higher fitness)
    2. Crossover: Combine parent solutions to create offspring
    3. Mutation: Apply random bit flips to maintain diversity
    4. Elitism: Preserve best solutions across generations
    
    Convergence properties:
    - Schema theorem: Good building blocks propagate
    - With elitism: best solution is non-decreasing
    - Diversity maintains exploration capability
    
Key Operators:
    - Tournament selection: Select k individuals, choose best
    - Single-point crossover: Split at random point, combine segments
    - Uniform crossover: Randomly inherit each bit from parents
    - Bit-flip mutation: Flip each bit with probability p_mut
"""

import numpy as np
from typing import Optional, Literal, List, Tuple, Dict, Any
from dataclasses import dataclass

from core.solvers.classical.base_solver import BaseSolver, SolverResult
from core.utils.math_helpers import calculate_energy_from_qubo
from core.utils.experiment_logger import ExperimentLogger


@dataclass
class GeneticAlgorithmConfig:
    """
    Configuration for Genetic Algorithm solver.
    
    Attributes:
        population_size: Number of individuals in population
        max_generations: Maximum number of generations
        tournament_size: Number of individuals in tournament selection
        crossover_rate: Probability of applying crossover
        mutation_rate: Probability of mutating each bit
        crossover_type: Type of crossover ('single_point', 'uniform', 'two_point')
        elitism_count: Number of best individuals to preserve
        diversity_threshold: Minimum diversity to maintain (0-1)
        adaptive_mutation: Increase mutation when diversity is low
        verbose: Print progress information
    """
    population_size: int = 100
    max_generations: int = 500
    tournament_size: int = 3
    crossover_rate: float = 0.8
    mutation_rate: float = 0.01
    crossover_type: Literal['single_point', 'uniform', 'two_point'] = 'single_point'
    elitism_count: int = 2
    diversity_threshold: float = 0.1
    adaptive_mutation: bool = True
    verbose: bool = False


class GeneticAlgorithmSolver(BaseSolver):
    """
    Genetic Algorithm solver for QUBO problems.
    
    Evolves a population of binary solutions using biologically-inspired
    operators: selection, crossover, mutation, and elitism.
    
    Features:
    - Tournament selection for parent choosing
    - Multiple crossover strategies (single-point, two-point, uniform)
    - Bit-flip mutation with adaptive rates
    - Elitism to preserve best solutions
    - Diversity monitoring and maintenance
    - Population statistics tracking
    
    The algorithm maintains a population of solutions and iteratively
    improves it through generations. Elitism ensures the best solution
    never deteriorates.
    
    Usage:
        >>> solver = GeneticAlgorithmSolver(seed=42)
        >>> config = GeneticAlgorithmConfig(population_size=100, max_generations=200)
        >>> result = solver.solve(Q, config=config)
        >>> print(f"Best energy: {result.best_energy}")
    """
    
    def __init__(self, logger: Optional[ExperimentLogger] = None, seed: Optional[int] = None):
        """
        Initialize Genetic Algorithm solver.
        
        Args:
            logger: Experiment logger for tracking
            seed: Random seed for reproducibility
        """
        super().__init__(logger, seed)
        
        # GA-specific tracking
        self.diversity_history = []
        self.avg_fitness_history = []
        
    def solve(self, Q: np.ndarray,
              initial_population: Optional[np.ndarray] = None,
              config: Optional[GeneticAlgorithmConfig] = None,
              **kwargs) -> SolverResult:
        """
        Solve QUBO problem using Genetic Algorithm.
        
        Args:
            Q: QUBO matrix (n × n, symmetric)
            initial_population: Starting population (random if None)
            config: Genetic algorithm configuration
            **kwargs: Override config parameters
            
        Returns:
            SolverResult with best solution and convergence data
            
        Raises:
            ValueError: If Q is invalid
        """
        # Validate input
        self._validate_qubo(Q)
        n = Q.shape[0]
        
        # Configuration
        if config is None:
            config = GeneticAlgorithmConfig()
        
        # Override with kwargs
        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)
        
        # Validate config
        if config.elitism_count >= config.population_size:
            raise ValueError("elitism_count must be less than population_size")
        
        # Initialize
        self._start_timer()
        
        # Initialize population
        if initial_population is None:
            population = self._initialize_population(n, config.population_size)
        else:
            if initial_population.shape != (config.population_size, n):
                raise ValueError(
                    f"initial_population shape {initial_population.shape} doesn't match "
                    f"expected ({config.population_size}, {n})"
                )
            population = initial_population.copy()
        
        # Evaluate initial population
        energies = self._evaluate_population(population, Q)
        
        # Track best solution
        best_idx = np.argmin(energies)
        x_best = population[best_idx].copy()
        E_best = energies[best_idx]
        
        # Statistics tracking
        self.diversity_history = []
        self.avg_fitness_history = []
        generation_best_energies = []
        
        # Current mutation rate (for adaptive)
        current_mutation_rate = config.mutation_rate
        
        # Main evolution loop
        for generation in range(config.max_generations):
            # Calculate diversity
            diversity = self._calculate_diversity(population)
            self.diversity_history.append(diversity)
            
            # Calculate average fitness
            avg_energy = np.mean(energies)
            self.avg_fitness_history.append(avg_energy)
            generation_best_energies.append(E_best)
            
            # Adaptive mutation
            if config.adaptive_mutation:
                if diversity < config.diversity_threshold:
                    # Low diversity: increase mutation
                    current_mutation_rate = min(0.1, config.mutation_rate * 2.0)
                else:
                    # Normal diversity: use base rate
                    current_mutation_rate = config.mutation_rate
            
            # Create new population
            new_population = []
            
            # Elitism: preserve best individuals
            elite_indices = np.argsort(energies)[:config.elitism_count]
            for idx in elite_indices:
                new_population.append(population[idx].copy())
            
            # Generate offspring
            while len(new_population) < config.population_size:
                # Tournament selection
                parent1 = self._tournament_selection(population, energies, config.tournament_size)
                parent2 = self._tournament_selection(population, energies, config.tournament_size)
                
                # Crossover
                if self.rng.random() < config.crossover_rate:
                    offspring1, offspring2 = self._crossover(
                        parent1, parent2, config.crossover_type
                    )
                else:
                    # No crossover: copy parents
                    offspring1, offspring2 = parent1.copy(), parent2.copy()
                
                # Mutation
                offspring1 = self._mutate(offspring1, current_mutation_rate)
                offspring2 = self._mutate(offspring2, current_mutation_rate)
                
                # Add to new population
                new_population.append(offspring1)
                if len(new_population) < config.population_size:
                    new_population.append(offspring2)
            
            # Update population
            population = np.array(new_population[:config.population_size])
            energies = self._evaluate_population(population, Q)
            
            # Update best solution
            gen_best_idx = np.argmin(energies)
            if energies[gen_best_idx] < E_best:
                E_best = energies[gen_best_idx]
                x_best = population[gen_best_idx].copy()
            
            # Record metrics
            self._record_energy(E_best)
            
            # Logging
            if generation % 10 == 0 or generation < 5:
                self._log_iteration(
                    generation,
                    energies[gen_best_idx],
                    best_energy=E_best
                )
                
                if config.verbose and generation % 50 == 0:
                    print(f"Gen {generation}: E_best={E_best:.4f}, "
                          f"E_avg={avg_energy:.4f}, E_curr={energies[gen_best_idx]:.4f}, "
                          f"diversity={diversity:.4f}, mut_rate={current_mutation_rate:.4f}")
        
        # Final logging
        self._log_solution(x_best, E_best, is_feasible=True, metadata={
            'final_generation': generation,
            'final_diversity': diversity,
            'final_avg_energy': avg_energy
        })
        
        # Create result
        metadata = {
            'algorithm': 'genetic_algorithm',
            'population_size': config.population_size,
            'max_generations': config.max_generations,
            'tournament_size': config.tournament_size,
            'crossover_rate': config.crossover_rate,
            'mutation_rate': config.mutation_rate,
            'crossover_type': config.crossover_type,
            'elitism_count': config.elitism_count,
            'final_diversity': diversity,
            'final_avg_energy': avg_energy,
            'diversity_history': self.diversity_history,
            'avg_fitness_history': self.avg_fitness_history,
            'generation_best_energies': generation_best_energies,
        }
        
        result = self._create_result(x_best, E_best, metadata=metadata)
        
        if config.verbose:
            print(f"\nOptimization complete:")
            print(f"  Best energy: {E_best:.6f}")
            print(f"  Generations: {generation + 1}")
            print(f"  Runtime: {result.runtime:.2f}s")
            print(f"  Final diversity: {diversity:.4f}")
            print(f"  Final avg energy: {avg_energy:.4f}")
        
        return result
    
    def _initialize_population(self, n: int, pop_size: int) -> np.ndarray:
        """
        Initialize random population.
        
        Args:
            n: Problem dimension
            pop_size: Population size
            
        Returns:
            Random binary population matrix (pop_size × n)
        """
        return self.rng.integers(0, 2, size=(pop_size, n))
    
    def _evaluate_population(self, population: np.ndarray, Q: np.ndarray) -> np.ndarray:
        """
        Evaluate energy for entire population.
        
        Args:
            population: Binary population matrix
            Q: QUBO matrix
            
        Returns:
            Array of energies for each individual
        """
        energies = np.array([
            calculate_energy_from_qubo(individual, Q)
            for individual in population
        ])
        return energies
    
    def _tournament_selection(self, population: np.ndarray, energies: np.ndarray,
                             tournament_size: int) -> np.ndarray:
        """
        Tournament selection: choose best from random subset.
        
        Args:
            population: Current population
            energies: Energy values
            tournament_size: Number of individuals in tournament
            
        Returns:
            Selected individual
        """
        # Select random tournament participants
        tournament_indices = self.rng.choice(
            len(population), 
            size=tournament_size, 
            replace=False
        )
        
        # Find best (lowest energy) in tournament
        tournament_energies = energies[tournament_indices]
        winner_idx = tournament_indices[np.argmin(tournament_energies)]
        
        return population[winner_idx].copy()
    
    def _crossover(self, parent1: np.ndarray, parent2: np.ndarray,
                   crossover_type: str) -> Tuple[np.ndarray, np.ndarray]:
        """
        Apply crossover operator to create offspring.
        
        Args:
            parent1: First parent
            parent2: Second parent
            crossover_type: Type of crossover
            
        Returns:
            Tuple of two offspring
        """
        n = len(parent1)
        
        if crossover_type == 'single_point':
            # Single-point crossover
            point = self.rng.integers(1, n)
            offspring1 = np.concatenate([parent1[:point], parent2[point:]])
            offspring2 = np.concatenate([parent2[:point], parent1[point:]])
            
        elif crossover_type == 'two_point':
            # Two-point crossover
            point1, point2 = sorted(self.rng.choice(n, size=2, replace=False))
            offspring1 = parent1.copy()
            offspring2 = parent2.copy()
            offspring1[point1:point2] = parent2[point1:point2]
            offspring2[point1:point2] = parent1[point1:point2]
            
        elif crossover_type == 'uniform':
            # Uniform crossover
            mask = self.rng.integers(0, 2, size=n).astype(bool)
            offspring1 = np.where(mask, parent1, parent2)
            offspring2 = np.where(mask, parent2, parent1)
            
        else:
            raise ValueError(f"Unknown crossover type: {crossover_type}")
        
        return offspring1, offspring2
    
    def _mutate(self, individual: np.ndarray, mutation_rate: float) -> np.ndarray:
        """
        Apply bit-flip mutation.
        
        Each bit is flipped with probability mutation_rate.
        
        Args:
            individual: Individual to mutate
            mutation_rate: Probability of flipping each bit
            
        Returns:
            Mutated individual
        """
        mutated = individual.copy()
        mutation_mask = self.rng.random(len(individual)) < mutation_rate
        mutated[mutation_mask] = 1 - mutated[mutation_mask]
        return mutated
    
    def _calculate_diversity(self, population: np.ndarray) -> float:
        """
        Calculate population diversity.
        
        Diversity is measured as average Hamming distance between individuals
        normalized by problem dimension.
        
        Args:
            population: Current population
            
        Returns:
            Diversity measure in [0, 1]
        """
        n_individuals, n_bits = population.shape
        
        if n_individuals <= 1:
            return 0.0
        
        # Calculate pairwise Hamming distances (sample for efficiency)
        n_samples = min(50, n_individuals * (n_individuals - 1) // 2)
        total_distance = 0.0
        
        for _ in range(n_samples):
            idx1, idx2 = self.rng.choice(n_individuals, size=2, replace=False)
            distance = np.sum(population[idx1] != population[idx2])
            total_distance += distance
        
        # Normalize by number of bits
        avg_distance = total_distance / n_samples
        diversity = avg_distance / n_bits
        
        return diversity
    
    def solve_with_restarts(self, Q: np.ndarray, n_restarts: int = 5,
                           config: Optional[GeneticAlgorithmConfig] = None) -> SolverResult:
        """
        Solve with multiple independent runs and return best solution.
        
        Args:
            Q: QUBO matrix
            n_restarts: Number of independent runs
            config: GA configuration
            
        Returns:
            Best result across all restarts
        """
        self._validate_qubo(Q)
        
        best_result = None
        all_energies = []
        
        for restart in range(n_restarts):
            # Solve with new random population
            result = self.solve(Q, initial_population=None, config=config)
            all_energies.append(result.best_energy)
            
            # Track best
            if best_result is None or result.best_energy < best_result.best_energy:
                best_result = result
            
            if config and config.verbose:
                print(f"Restart {restart + 1}/{n_restarts}: E={result.best_energy:.6f}")
        
        # Add restart metadata
        best_result.metadata['n_restarts'] = n_restarts
        best_result.metadata['all_restart_energies'] = all_energies
        best_result.metadata['restart_energy_std'] = float(np.std(all_energies))
        
        return best_result
    
    def __repr__(self) -> str:
        """String representation."""
        return f"GeneticAlgorithmSolver(seed={self.seed})"
