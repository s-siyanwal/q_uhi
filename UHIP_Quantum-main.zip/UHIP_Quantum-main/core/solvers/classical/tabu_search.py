"""
Tabu Search Solver for QUBO Problems

Implements classical tabu search with adaptive tabu tenure and aspiration criteria
for solving binary quadratic unconstrained optimization problems.

Algorithm Reference:
    Glover, F. (1989). "Tabu Search—Part I." ORSA Journal on Computing, 1(3), 190-206.
    Glover, F. (1990). "Tabu Search—Part II." ORSA Journal on Computing, 2(1), 4-32.
    
Mathematical Framework:
    Tabu search is a metaheuristic that:
    1. Maintains a tabu list of recently visited solutions or moves
    2. Explores neighborhood by selecting best non-tabu move
    3. Uses aspiration criteria to override tabu status
    4. Adapts search parameters based on search progress
    
    Key components:
    - Tabu list: Prevents cycling by forbidding recent moves
    - Aspiration criterion: Allows tabu moves if they improve best-known solution
    - Intensification: Focus search near good solutions
    - Diversification: Encourage exploration of new regions
    
Theorem (Properties):
    Tabu search with appropriate parameter settings is guaranteed to:
    - Avoid cycling for at least tabu_tenure iterations
    - Accept improving moves regardless of tabu status (aspiration)
    - Explore beyond local optima (through tabu mechanism)
"""

import numpy as np
from typing import Optional, List, Set, Dict, Any
from dataclasses import dataclass
from collections import deque

from core.solvers.classical.base_solver import BaseSolver, SolverResult
from core.utils.math_helpers import calculate_delta_energy_single_flip
from core.utils.experiment_logger import ExperimentLogger


@dataclass
class TabuSearchConfig:
    """
    Configuration for Tabu Search solver.
    
    Attributes:
        max_iterations: Maximum number of iterations
        tabu_tenure: Number of iterations a move remains tabu
        min_tabu_tenure: Minimum tabu tenure (for adaptive)
        max_tabu_tenure: Maximum tabu tenure (for adaptive)
        adaptive_tabu: Use adaptive tabu tenure
        aspiration_enabled: Enable aspiration criteria
        neighborhood_size: Size of neighborhood to explore (None = all)
        diversification_interval: Iterations between diversification
        diversification_strength: Number of random flips for diversification
        verbose: Print progress information
    """
    max_iterations: int = 10000
    tabu_tenure: int = 10
    min_tabu_tenure: int = 5
    max_tabu_tenure: int = 20
    adaptive_tabu: bool = True
    aspiration_enabled: bool = True
    neighborhood_size: Optional[int] = None
    diversification_interval: int = 500
    diversification_strength: int = 5
    verbose: bool = False


class TabuSearchSolver(BaseSolver):
    """
    Tabu Search solver for QUBO problems.
    
    The algorithm maintains a short-term memory (tabu list) to guide the search
    away from recently visited solutions, combined with aspiration criteria to
    accept excellent moves even if tabu.
    
    Features:
    - Adaptive tabu tenure based on search progress
    - Aspiration criteria for overriding tabu status
    - Neighborhood exploration with optional sampling
    - Periodic diversification to escape plateaus
    - Efficient delta-energy computation
    - Trajectory tracking and best solution recording
    
    The tabu list is implemented as a queue of recently flipped variables,
    preventing the immediate reversal of recent moves.
    
    Usage:
        >>> solver = TabuSearchSolver(seed=42)
        >>> config = TabuSearchConfig(max_iterations=5000, tabu_tenure=15)
        >>> result = solver.solve(Q, config=config)
        >>> print(f"Best energy: {result.best_energy}")
    """
    
    def __init__(self, logger: Optional[ExperimentLogger] = None, seed: Optional[int] = None):
        """
        Initialize Tabu Search solver.
        
        Args:
            logger: Experiment logger for tracking
            seed: Random seed for reproducibility
        """
        super().__init__(logger, seed)
        
        # Tabu search specific tracking
        self.tabu_list = deque()
        self.tabu_set = set()
        self.iterations_since_improvement = 0
        
    def solve(self, Q: np.ndarray,
              initial_solution: Optional[np.ndarray] = None,
              config: Optional[TabuSearchConfig] = None,
              **kwargs) -> SolverResult:
        """
        Solve QUBO problem using Tabu Search.
        
        Args:
            Q: QUBO matrix (n × n, symmetric)
            initial_solution: Starting solution (random if None)
            config: Tabu search configuration
            **kwargs: Override config parameters
            
        Returns:
            SolverResult with best solution and convergence data
            
        Raises:
            ValueError: If Q is invalid
        """
        # Validate input
        self._validate_qubo(Q)
        n = Q.shape[0]
        
        # Configuration
        if config is None:
            config = TabuSearchConfig()
        
        # Override with kwargs
        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)
        
        # Initialize
        self._start_timer()
        if initial_solution is None:
            x_current = self._initialize_solution(n)
        else:
            self._validate_solution(initial_solution, Q)
            x_current = initial_solution.copy()
        
        # Calculate initial energy
        E_current = self._calculate_energy(x_current, Q)
        
        # Track best solution
        x_best = x_current.copy()
        E_best = E_current
        
        # Initialize tabu list
        self.tabu_list = deque(maxlen=config.tabu_tenure)
        self.tabu_set = set()
        self.iterations_since_improvement = 0
        
        # Current tabu tenure (for adaptive)
        current_tabu_tenure = config.tabu_tenure
        
        # Statistics
        n_tabu_overrides = 0
        n_diversifications = 0
        tabu_tenure_history = []
        
        # Main optimization loop
        for iteration in range(config.max_iterations):
            # Adaptive tabu tenure
            if config.adaptive_tabu:
                current_tabu_tenure = self._compute_adaptive_tenure(
                    config, self.iterations_since_improvement
                )
                self.tabu_list = deque(self.tabu_list, maxlen=current_tabu_tenure)
                tabu_tenure_history.append(current_tabu_tenure)
            
            # Diversification mechanism
            if (config.diversification_interval > 0 and 
                iteration > 0 and 
                iteration % config.diversification_interval == 0):
                x_current = self._diversify(x_current, config.diversification_strength)
                E_current = self._calculate_energy(x_current, Q)
                n_diversifications += 1
                if config.verbose:
                    print(f"Iteration {iteration}: Diversification (strength={config.diversification_strength})")
            
            # Explore neighborhood
            best_move_idx = None
            best_move_delta = float('inf')
            best_move_energy = E_current
            aspiration_used = False
            
            # Determine neighborhood to explore
            if config.neighborhood_size is None or config.neighborhood_size >= n:
                # Full neighborhood
                candidate_indices = range(n)
            else:
                # Sample random subset
                candidate_indices = self.rng.choice(
                    n, 
                    size=min(config.neighborhood_size, n), 
                    replace=False
                )
            
            # Evaluate all candidate moves
            for flip_idx in candidate_indices:
                # Calculate energy change
                delta_E = calculate_delta_energy_single_flip(x_current, Q, flip_idx)
                move_energy = E_current + delta_E
                
                # Check if move is tabu
                is_tabu = flip_idx in self.tabu_set
                
                # Aspiration criterion: accept if better than best known
                aspiration = (config.aspiration_enabled and 
                            move_energy < E_best)
                
                # Accept move if:
                # 1. Not tabu, OR
                # 2. Tabu but satisfies aspiration criterion
                if not is_tabu or aspiration:
                    if delta_E < best_move_delta:
                        best_move_idx = flip_idx
                        best_move_delta = delta_E
                        best_move_energy = move_energy
                        aspiration_used = aspiration and is_tabu
            
            # No valid move found - force a move anyway
            if best_move_idx is None:
                # Select best move ignoring tabu (emergency escape)
                deltas = [calculate_delta_energy_single_flip(x_current, Q, i) 
                         for i in candidate_indices]
                best_move_idx = candidate_indices[np.argmin(deltas)]
                best_move_delta = min(deltas)
                best_move_energy = E_current + best_move_delta
                if config.verbose:
                    print(f"Iteration {iteration}: Forced move (all neighbors tabu)")
            
            # Apply best move
            x_current[best_move_idx] = 1 - x_current[best_move_idx]
            E_current = best_move_energy
            
            # Update tabu list
            self._update_tabu_list(best_move_idx, current_tabu_tenure)
            
            if aspiration_used:
                n_tabu_overrides += 1
            
            # Update best solution
            if E_current < E_best:
                E_best = E_current
                x_best = x_current.copy()
                self.iterations_since_improvement = 0
            else:
                self.iterations_since_improvement += 1
            
            # Record metrics
            self._record_energy(E_best)
            
            # Logging
            if iteration % 100 == 0 or iteration < 10:
                self._log_iteration(
                    iteration,
                    E_current,
                    best_energy=E_best
                )
                
                if config.verbose and iteration % 1000 == 0:
                    print(f"Iter {iteration}: E_curr={E_current:.4f}, E_best={E_best:.4f}, "
                          f"tabu_tenure={current_tabu_tenure}, "
                          f"iters_since_imp={self.iterations_since_improvement}")
        
        # Final logging
        self._log_solution(x_best, E_best, is_feasible=True, metadata={
            'final_tabu_tenure': current_tabu_tenure,
            'iterations_since_improvement': self.iterations_since_improvement
        })
        
        # Create result
        metadata = {
            'algorithm': 'tabu_search',
            'initial_tabu_tenure': config.tabu_tenure,
            'final_tabu_tenure': current_tabu_tenure,
            'adaptive_tabu': config.adaptive_tabu,
            'aspiration_enabled': config.aspiration_enabled,
            'n_tabu_overrides': n_tabu_overrides,
            'n_diversifications': n_diversifications,
            'iterations_since_improvement': self.iterations_since_improvement,
        }
        
        if config.adaptive_tabu:
            metadata['tabu_tenure_history'] = tabu_tenure_history
            metadata['avg_tabu_tenure'] = float(np.mean(tabu_tenure_history))
        
        result = self._create_result(x_best, E_best, metadata=metadata)
        
        if config.verbose:
            print(f"\nOptimization complete:")
            print(f"  Best energy: {E_best:.6f}")
            print(f"  Iterations: {iteration + 1}")
            print(f"  Runtime: {result.runtime:.2f}s")
            print(f"  Tabu overrides (aspiration): {n_tabu_overrides}")
            print(f"  Diversifications: {n_diversifications}")
        
        return result
    
    def _update_tabu_list(self, move_idx: int, tenure: int):
        """
        Update tabu list with new move.
        
        Args:
            move_idx: Index of variable that was flipped
            tenure: Current tabu tenure
        """
        # Update maxlen if changed
        if self.tabu_list.maxlen != tenure:
            # Create new deque with updated maxlen
            old_items = list(self.tabu_list)
            self.tabu_list = deque(old_items[-tenure:], maxlen=tenure)
            # Rebuild set from current list
            self.tabu_set = set(self.tabu_list)
        
        # Add new move to tabu list (automatically removes oldest if at maxlen)
        self.tabu_list.append(move_idx)
        self.tabu_set.add(move_idx)
        
        # Clean up set - remove items no longer in deque
        self.tabu_set = set(self.tabu_list)
    
    def _compute_adaptive_tenure(self, config: TabuSearchConfig, 
                                 iters_since_imp: int) -> int:
        """
        Compute adaptive tabu tenure based on search progress.
        
        Strategy:
        - Increase tenure when stuck (no improvement) to force more exploration
        - Decrease tenure when finding improvements to allow intensification
        
        Args:
            config: Tabu search configuration
            iters_since_imp: Iterations since last improvement
            
        Returns:
            Adjusted tabu tenure
        """
        # Base tenure
        base = config.tabu_tenure
        
        # Increase if stuck
        if iters_since_imp > 100:
            # Long stagnation: increase significantly
            adjustment = min(config.max_tabu_tenure, base + iters_since_imp // 50)
        elif iters_since_imp > 50:
            # Medium stagnation: increase moderately
            adjustment = min(config.max_tabu_tenure, base + 2)
        elif iters_since_imp < 10:
            # Recent improvement: decrease to intensify
            adjustment = max(config.min_tabu_tenure, base - 2)
        else:
            # Normal: keep base
            adjustment = base
        
        return int(adjustment)
    
    def _diversify(self, x: np.ndarray, strength: int) -> np.ndarray:
        """
        Apply diversification by flipping random bits.
        
        Args:
            x: Current solution
            strength: Number of bits to flip
            
        Returns:
            Diversified solution
        """
        x_div = x.copy()
        flip_indices = self.rng.choice(len(x), size=min(strength, len(x)), replace=False)
        x_div[flip_indices] = 1 - x_div[flip_indices]
        return x_div
    
    def solve_with_restarts(self, Q: np.ndarray, n_restarts: int = 10,
                           config: Optional[TabuSearchConfig] = None) -> SolverResult:
        """
        Solve with multiple random restarts and return best solution.
        
        Args:
            Q: QUBO matrix
            n_restarts: Number of independent runs
            config: Tabu search configuration
            
        Returns:
            Best result across all restarts
        """
        self._validate_qubo(Q)
        
        best_result = None
        all_energies = []
        
        for restart in range(n_restarts):
            # Solve with new random initial solution
            result = self.solve(Q, initial_solution=None, config=config)
            all_energies.append(result.best_energy)
            
            # Track best
            if best_result is None or result.best_energy < best_result.best_energy:
                best_result = result
            
            if config and config.verbose:
                print(f"Restart {restart + 1}/{n_restarts}: E={result.best_energy:.6f}")
        
        # Add restart metadata
        best_result.metadata['n_restarts'] = n_restarts
        best_result.metadata['all_restart_energies'] = all_energies
        best_result.metadata['restart_energy_std'] = float(np.std(all_energies))
        
        return best_result
    
    def __repr__(self) -> str:
        """String representation."""
        return f"TabuSearchSolver(seed={self.seed})"
