"""
Quantum-Inspired Solvers for UHI-QUBO Framework

Implements simulated quantum annealing via path integral Monte Carlo
with Suzuki-Trotter decomposition.

Modules:
    - trotter_expansion: Suzuki-Trotter decomposition for quantum-to-classical mapping
    - metropolis_sampler: Monte Carlo sampling for replicated systems
    - simulated_quantum_annealing: Main SQA solver with annealing schedules

Mathematical foundation based on quantum annealing theory and path integral formulation.
"""

from core.solvers.quantum.trotter_expansion import (
    TrotterExpansion,
    TrotterParameters
)

from core.solvers.quantum.metropolis_sampler import (
    MetropolisSampler,
    FlipStrategy,
    SamplingStatistics
)

from core.solvers.quantum.simulated_quantum_annealing import (
    SimulatedQuantumAnnealing,
    AnnealingSchedule
)

__all__ = [
    # Trotter decomposition
    'TrotterExpansion',
    'TrotterParameters',
    
    # Metropolis sampling
    'MetropolisSampler',
    'FlipStrategy',
    'SamplingStatistics',
    
    # Main solver
    'SimulatedQuantumAnnealing',
    'AnnealingSchedule'
]
