"""
Metropolis-Hastings Monte Carlo Sampler for Quantum-Inspired Systems

Implements Metropolis algorithm for sampling from the effective classical
distribution induced by the Suzuki-Trotter path integral formulation.

Mathematical Foundation:
=======================
Target Distribution:
    P(s^1,...,s^M) = (1/Z) exp(-β E_eff[s^1,...,s^M])
    
where E_eff includes both classical and Trotter coupling terms.

Metropolis-Hastings Algorithm:
    1. Propose a move: s → s'
    2. Compute acceptance probability:
       α = min(1, exp(-β ΔE))
    3. Accept with probability α

Move Types:
    - Single spin flip: s_i^τ → -s_i^τ (one replica, one spin)
    - Multi-replica flip: s_i^τ → -s_i^τ for all τ or subset
    - Cluster moves: Swendsen-Wang or Wolff clusters (advanced)

Detailed Balance:
    P(s) T(s→s') α(s→s') = P(s') T(s'→s) α(s'→s)
    
ensures convergence to equilibrium distribution.

References:
    - Metropolis et al. (1953): "Equation of State Calculations by Fast Computing Machines"
    - Hastings (1970): "Monte Carlo Sampling Methods Using Markov Chains"
    - Newman & Barkema: "Monte Carlo Methods in Statistical Physics"
    - UHI-QUBO Mathematical Documents: Monte Carlo Sampling Section

Author: UHI-QUBO Research Framework
"""

import numpy as np
from typing import Tuple, Dict, Optional, Callable
from enum import Enum
from dataclasses import dataclass

from core.utils.math_helpers import metropolis_acceptance_probability


class FlipStrategy(Enum):
    """Monte Carlo move strategies for Trotter replicas."""
    SINGLE_REPLICA_SINGLE_SPIN = "single_spin"      # Flip one spin in one replica
    SINGLE_REPLICA_MULTI_SPIN = "multi_spin"        # Flip k spins in one replica
    MULTI_REPLICA_SINGLE_SPIN = "vertical_flip"     # Flip same spin across all replicas
    RANDOM_REPLICA_SINGLE_SPIN = "random_vertical"  # Flip same spin in random subset of replicas
    ADAPTIVE = "adaptive"                            # Dynamically choose strategy


@dataclass
class SamplingStatistics:
    """
    Statistics for Metropolis sampling.
    
    Attributes:
        total_proposals: Total number of moves proposed
        accepted_moves: Number of accepted moves
        acceptance_rate: Acceptance rate (accepted/total)
        energy_samples: History of energy samples
        average_energy: Mean energy over sampling period
        energy_std: Standard deviation of energy
    """
    total_proposals: int = 0
    accepted_moves: int = 0
    acceptance_rate: float = 0.0
    energy_samples: list = None
    average_energy: float = 0.0
    energy_std: float = 0.0
    
    def __post_init__(self):
        if self.energy_samples is None:
            self.energy_samples = []
    
    def update(self, accepted: bool, energy: Optional[float] = None):
        """Update statistics with new sample."""
        self.total_proposals += 1
        if accepted:
            self.accepted_moves += 1
        if energy is not None:
            self.energy_samples.append(energy)
        
        # Update derived statistics
        if self.total_proposals > 0:
            self.acceptance_rate = self.accepted_moves / self.total_proposals
        if len(self.energy_samples) > 0:
            self.average_energy = np.mean(self.energy_samples)
            self.energy_std = np.std(self.energy_samples)


class MetropolisSampler:
    """
    Metropolis-Hastings sampler for quantum-inspired Trotter replica systems.
    
    Samples from the effective classical distribution:
        P(s^1,...,s^M) ∝ exp(-β E_eff)
    
    where E_eff includes:
    1. Classical Ising energy for each replica
    2. Ferromagnetic coupling between adjacent time slices (Trotter coupling)
    
    The sampler implements various move strategies optimized for the
    2D structure of the replica system (space × imaginary time).
    """
    
    def __init__(self, 
                 flip_strategy: FlipStrategy = FlipStrategy.SINGLE_REPLICA_SINGLE_SPIN,
                 adaptive_acceptance_target: float = 0.234,  # Optimal for continuous distributions
                 seed: Optional[int] = None):
        """
        Initialize Metropolis sampler.
        
        Args:
            flip_strategy: Strategy for proposing moves
            adaptive_acceptance_target: Target acceptance rate for adaptive sampling
                                       (0.234 is theoretically optimal for high dimensions)
            seed: Random seed for reproducibility
        """
        self.flip_strategy = flip_strategy
        self.adaptive_acceptance_target = adaptive_acceptance_target
        self.rng = np.random.default_rng(seed)
        
        # Statistics tracking
        self.stats = SamplingStatistics()
        self.iteration_stats = []  # Track stats over time
        
    def propose_move(self, replicas: np.ndarray) -> Tuple[int, int, np.ndarray]:
        """
        Propose a move based on current flip strategy.
        
        Args:
            replicas: (M × n) current spin configuration
            
        Returns:
            Tuple of:
            - replica_indices: Indices of replicas to flip (list or single int)
            - spin_index: Index of spin to flip
            - new_replicas: Proposed configuration (copy with flip applied)
        """
        M, n = replicas.shape
        
        if self.flip_strategy == FlipStrategy.SINGLE_REPLICA_SINGLE_SPIN:
            # Most common: flip one spin in one time slice
            replica_idx = self.rng.integers(0, M)
            spin_idx = self.rng.integers(0, n)
            
            new_replicas = replicas.copy()
            new_replicas[replica_idx, spin_idx] *= -1
            
            return replica_idx, spin_idx, new_replicas
        
        elif self.flip_strategy == FlipStrategy.MULTI_REPLICA_SINGLE_SPIN:
            # Flip same spin across all time slices
            # This can help break time symmetry
            spin_idx = self.rng.integers(0, n)
            
            new_replicas = replicas.copy()
            new_replicas[:, spin_idx] *= -1
            
            return list(range(M)), spin_idx, new_replicas
        
        elif self.flip_strategy == FlipStrategy.RANDOM_REPLICA_SINGLE_SPIN:
            # Flip same spin in random subset of replicas
            spin_idx = self.rng.integers(0, n)
            num_replicas_to_flip = self.rng.integers(1, M + 1)
            replica_indices = self.rng.choice(M, size=num_replicas_to_flip, replace=False)
            
            new_replicas = replicas.copy()
            new_replicas[replica_indices, spin_idx] *= -1
            
            return replica_indices.tolist(), spin_idx, new_replicas
        
        else:  # SINGLE_REPLICA_SINGLE_SPIN as default
            replica_idx = self.rng.integers(0, M)
            spin_idx = self.rng.integers(0, n)
            
            new_replicas = replicas.copy()
            new_replicas[replica_idx, spin_idx] *= -1
            
            return replica_idx, spin_idx, new_replicas
    
    def compute_delta_energy_fast(self, replicas: np.ndarray, h: np.ndarray,
                                  J: np.ndarray, J_tau: float,
                                  replica_idx: int, spin_idx: int) -> float:
        """
        Fast computation of energy change for single spin flip.
        
        Mathematical formulation:
        =========================
        When flipping s_i^τ → -s_i^τ, the energy change is:
        
        ΔE = E_new - E_old = 2 * s_i^τ * [h_i + Σ_j J_ij s_j^τ + J_τ(s_i^{τ-1} + s_i^{τ+1})]
        
        Components:
        1. Linear field: h_i s_i^τ
        2. Spatial interactions: Σ_j J_ij s_i^τ s_j^τ
        3. Time coupling: J_τ(s_i^{τ-1} s_i^τ + s_i^τ s_i^{τ+1})
        
        Args:
            replicas: (M × n) current configuration
            h: (n,) local fields
            J: (n × n) coupling matrix
            J_tau: Trotter coupling strength
            replica_idx: Time slice τ
            spin_idx: Spin index i
            
        Returns:
            ΔE: Energy change
        """
        M, n = replicas.shape
        current_spin = replicas[replica_idx, spin_idx]
        
        # Local field contribution
        local_field = h[spin_idx]
        
        # Spatial coupling in current time slice
        spatial_coupling = np.dot(J[spin_idx, :], replicas[replica_idx])
        
        # Temporal coupling to adjacent slices
        prev_idx = (replica_idx - 1) % M
        next_idx = (replica_idx + 1) % M
        temporal_coupling = J_tau * (
            replicas[prev_idx, spin_idx] + replicas[next_idx, spin_idx]
        )
        
        # Total energy change
        delta_E = 2 * current_spin * (local_field + spatial_coupling + temporal_coupling)
        
        return float(delta_E)
    
    def compute_delta_energy_multi_replica(self, replicas: np.ndarray, h: np.ndarray,
                                          J: np.ndarray, J_tau: float,
                                          replica_indices: list, spin_idx: int) -> float:
        """
        Compute energy change for flipping same spin across multiple replicas.
        
        This is more complex as flipping multiple time slices affects:
        - Each slice's classical energy
        - Coupling between flipped slices
        - Coupling to non-flipped neighbors
        
        Args:
            replicas: (M × n) configuration
            h: Local fields
            J: Coupling matrix
            J_tau: Trotter coupling
            replica_indices: Which time slices to flip
            spin_idx: Which spin to flip
            
        Returns:
            Total energy change
        """
        delta_E = 0.0
        M, n = replicas.shape
        
        # Sort indices for easier neighbor handling
        sorted_indices = sorted(replica_indices)
        
        for replica_idx in sorted_indices:
            current_spin = replicas[replica_idx, spin_idx]
            
            # Local field
            local_field = h[spin_idx]
            
            # Spatial coupling
            spatial_coupling = np.dot(J[spin_idx, :], replicas[replica_idx])
            
            # Temporal coupling - more careful here
            prev_idx = (replica_idx - 1) % M
            next_idx = (replica_idx + 1) % M
            
            # Check if neighbors are also being flipped
            prev_flipped = prev_idx in replica_indices
            next_flipped = next_idx in replica_indices
            
            temporal_coupling = 0.0
            # If neighbor is flipped, sign stays same after both flip
            # If neighbor not flipped, sign changes
            if not prev_flipped:
                temporal_coupling += J_tau * replicas[prev_idx, spin_idx]
            else:
                temporal_coupling -= J_tau * replicas[prev_idx, spin_idx]
            
            if not next_flipped:
                temporal_coupling += J_tau * replicas[next_idx, spin_idx]
            else:
                temporal_coupling -= J_tau * replicas[next_idx, spin_idx]
            
            delta_E += 2 * current_spin * (local_field + spatial_coupling + temporal_coupling)
        
        return float(delta_E)
    
    def metropolis_step(self, replicas: np.ndarray, h: np.ndarray, J: np.ndarray,
                       J_tau: float, beta: float,
                       energy_func: Optional[Callable] = None) -> Tuple[np.ndarray, bool, float]:
        """
        Perform one Metropolis Monte Carlo step.
        
        Algorithm:
        ==========
        1. Propose a move: s → s'
        2. Compute ΔE = E(s') - E(s)
        3. Accept with probability α = min(1, exp(-β ΔE))
        4. Update state and statistics
        
        Args:
            replicas: (M × n) current spin configuration
            h: Local fields
            J: Coupling matrix  
            J_tau: Trotter coupling
            beta: Inverse temperature β = 1/T
            energy_func: Optional function to compute full energy (for validation)
            
        Returns:
            Tuple of:
            - new_replicas: Updated configuration
            - accepted: Whether move was accepted
            - delta_E: Energy change
        """
        # Propose move
        replica_info, spin_idx, proposed_replicas = self.propose_move(replicas)
        
        # Compute energy change
        if isinstance(replica_info, list):
            # Multi-replica flip
            delta_E = self.compute_delta_energy_multi_replica(
                replicas, h, J, J_tau, replica_info, spin_idx
            )
        else:
            # Single replica flip
            delta_E = self.compute_delta_energy_fast(
                replicas, h, J, J_tau, replica_info, spin_idx
            )
        
        # Metropolis acceptance criterion
        # Compute temperature once: T = 1/β
        temperature = 1.0 / beta if beta > 0 else float('inf')
        accept_prob = metropolis_acceptance_probability(delta_E, temperature)
        
        # Accept or reject
        if self.rng.random() < accept_prob:
            # Accept move
            accepted = True
            new_replicas = proposed_replicas
        else:
            # Reject move
            accepted = False
            new_replicas = replicas
            delta_E = 0.0  # No energy change
        
        # Update statistics
        self.stats.update(accepted)
        
        return new_replicas, accepted, delta_E
    
    def sample(self, replicas: np.ndarray, h: np.ndarray, J: np.ndarray,
              J_tau: float, beta: float, num_steps: int,
              burnin: int = 0, thinning: int = 1) -> Tuple[np.ndarray, Dict]:
        """
        Generate samples from equilibrium distribution via Metropolis algorithm.
        
        Args:
            replicas: (M × n) initial configuration
            h: Local fields
            J: Coupling matrix
            J_tau: Trotter coupling
            beta: Inverse temperature
            num_steps: Total number of Monte Carlo steps
            burnin: Number of initial steps to discard (equilibration)
            thinning: Keep every k-th sample to reduce correlation
            
        Returns:
            Tuple of:
            - final_replicas: Final configuration after sampling
            - sampling_info: Dictionary with sampling statistics and history
        """
        current_replicas = replicas.copy()
        
        # Storage for samples
        energy_history = []
        acceptance_history = []
        
        # Reset statistics
        self.stats = SamplingStatistics()
        
        for step in range(num_steps):
            # Perform Metropolis step
            current_replicas, accepted, delta_E = self.metropolis_step(
                current_replicas, h, J, J_tau, beta
            )
            
            # Record after burn-in and according to thinning
            if step >= burnin and (step - burnin) % thinning == 0:
                # Could compute full energy here if needed
                acceptance_history.append(1.0 if accepted else 0.0)
        
        # Compute statistics
        sampling_info = {
            'total_steps': num_steps,
            'burnin': burnin,
            'thinning': thinning,
            'acceptance_rate': self.stats.acceptance_rate,
            'total_accepted': self.stats.accepted_moves,
            'final_stats': {
                'acceptance_rate': self.stats.acceptance_rate,
                'total_proposals': self.stats.total_proposals,
                'accepted_moves': self.stats.accepted_moves
            }
        }
        
        return current_replicas, sampling_info
    
    def adaptive_sampling(self, replicas: np.ndarray, h: np.ndarray, J: np.ndarray,
                         J_tau: float, beta: float, num_steps: int,
                         adaptation_interval: int = 100) -> Tuple[np.ndarray, Dict]:
        """
        Adaptive sampling that adjusts strategy to maintain target acceptance rate.
        
        The theoretically optimal acceptance rate for high-dimensional
        continuous distributions is ~0.234 (Roberts & Rosenthal, 2001).
        For discrete systems, rates of 0.3-0.5 are often used.
        
        Args:
            replicas: Initial configuration
            h, J, J_tau, beta: Hamiltonian parameters
            num_steps: Total sampling steps
            adaptation_interval: How often to check and adapt
            
        Returns:
            Final replicas and adaptation history
        """
        current_replicas = replicas.copy()
        adaptation_history = []
        
        for interval_start in range(0, num_steps, adaptation_interval):
            interval_steps = min(adaptation_interval, num_steps - interval_start)
            
            # Sample for this interval
            current_replicas, info = self.sample(
                current_replicas, h, J, J_tau, beta, interval_steps
            )
            
            # Record adaptation
            adaptation_history.append({
                'step': interval_start,
                'acceptance_rate': info['acceptance_rate'],
                'strategy': self.flip_strategy.value
            })
            
            # Adapt strategy if needed
            if info['acceptance_rate'] < self.adaptive_acceptance_target - 0.1:
                # Acceptance too low - try simpler moves
                if self.flip_strategy == FlipStrategy.MULTI_REPLICA_SINGLE_SPIN:
                    self.flip_strategy = FlipStrategy.SINGLE_REPLICA_SINGLE_SPIN
            elif info['acceptance_rate'] > self.adaptive_acceptance_target + 0.2:
                # Acceptance too high - try more complex moves
                if self.flip_strategy == FlipStrategy.SINGLE_REPLICA_SINGLE_SPIN:
                    self.flip_strategy = FlipStrategy.RANDOM_REPLICA_SINGLE_SPIN
        
        sampling_info = {
            'total_steps': num_steps,
            'adaptation_history': adaptation_history,
            'final_acceptance_rate': self.stats.acceptance_rate
        }
        
        return current_replicas, sampling_info
    
    def parallel_tempering_step(self, replicas_list: list, h: np.ndarray, J: np.ndarray,
                               J_tau: float, beta_list: list) -> list:
        """
        Parallel tempering (replica exchange) for enhanced sampling.
        
        Maintains multiple copies at different temperatures and attempts
        to swap configurations between adjacent temperature levels.
        
        Args:
            replicas_list: List of (M × n) configurations at different T
            h, J, J_tau: Hamiltonian parameters
            beta_list: List of inverse temperatures (sorted)
            
        Returns:
            Updated list of configurations after attempted swaps
        """
        # This is a placeholder for advanced parallel tempering
        # Full implementation would require energy computation and swap logic
        raise NotImplementedError("Parallel tempering is an advanced feature")
    
    def get_statistics(self) -> Dict:
        """Get current sampling statistics."""
        return {
            'acceptance_rate': self.stats.acceptance_rate,
            'total_proposals': self.stats.total_proposals,
            'accepted_moves': self.stats.accepted_moves,
            'flip_strategy': self.flip_strategy.value
        }
    
    def reset_statistics(self):
        """Reset sampling statistics."""
        self.stats = SamplingStatistics()
    
    def __repr__(self) -> str:
        """String representation."""
        return f"MetropolisSampler(strategy={self.flip_strategy.value}, " \
               f"acceptance={self.stats.acceptance_rate:.3f})"
