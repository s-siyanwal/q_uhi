"""
Suzuki-Trotter Decomposition for Quantum Annealing Simulation

Implements path integral Monte Carlo formulation via Suzuki-Trotter expansion.
Maps quantum system to (M+1)-dimensional classical Ising model with 
nearest-neighbor coupling in the imaginary time direction.

Mathematical Foundation:
=======================
Quantum Ising Hamiltonian:
    H(t) = H_classical + H_quantum
    H_classical = -Σ_{i<j} J_ij s_i s_j - Σ_i h_i s_i
    H_quantum = -Γ(t) Σ_i σ_i^x

Suzuki-Trotter Expansion:
    e^{-βH} ≈ [e^{-βH_cl/M} e^{-βH_q/M}]^M + O(1/M²)

Path Integral Formulation:
    Z = Tr[e^{-βH}] → ∫ Ds exp(-S_eff[s])
    
Effective Action (M Trotter slices):
    S_eff = Σ_{τ=1}^M [β/M H_classical(s^τ) + β/M Σ_i ln(coth(βΓ/M)) s_i^τ s_i^{τ+1}]

Effective Coupling:
    J_τ = -(1/(2β)) ln[tanh(βΓ/M)]
    
This creates ferromagnetic coupling between adjacent time slices,
implementing quantum tunneling classically through thermal fluctuations.

References:
    - Suzuki, M. (1976). "Relationship between d-dimensional quantal spin systems 
      and (d+1)-dimensional Ising systems"
    - Quantum Annealing and Related Optimization Methods (Das & Chakrabarti)
    - Path integral formulation: Feynman & Hibbs
    - UHI-QUBO Mathematical Documents: Simulated Quantum Annealing Section

Author: UHI-QUBO Research Framework
"""

import numpy as np
from typing import Tuple, Dict, Optional
from dataclasses import dataclass


@dataclass
class TrotterParameters:
    """
    Parameters for Suzuki-Trotter decomposition.
    
    Attributes:
        M: Number of Trotter replicas (time slices)
        beta: Inverse temperature β = 1/T
        gamma: Transverse field strength Γ
        J_tau: Effective coupling between time slices
        effective_2d_size: Total system size (n × M)
    """
    M: int
    beta: float
    gamma: float
    J_tau: float
    effective_2d_size: int
    
    def __post_init__(self):
        """Validate parameters."""
        if self.M < 1:
            raise ValueError(f"Trotter number M must be ≥ 1, got {self.M}")
        if self.beta <= 0:
            raise ValueError(f"β must be positive, got {self.beta}")
        if self.gamma < 0:
            raise ValueError(f"Γ must be non-negative, got {self.gamma}")


class TrotterExpansion:
    """
    Suzuki-Trotter decomposition for quantum-to-classical mapping.
    
    Implements the path integral Monte Carlo formulation that maps a
    quantum Ising system in d dimensions to a classical Ising system
    in (d+1) dimensions via imaginary time discretization.
    
    The quantum mechanical partition function:
        Z_quantum = Tr[exp(-βH)]
    
    becomes a classical partition function over M replicas:
        Z_classical = Σ_{s^1,...,s^M} exp(-β H_eff[s^1,...,s^M])
    
    where each replica s^τ represents the system state at imaginary time τ.
    """
    
    def __init__(self, num_trotter_replicas: int = 10, validate: bool = True):
        """
        Initialize Trotter expansion.
        
        Args:
            num_trotter_replicas: Number of time slices M in the discretization
                                 Higher M → more accurate quantum approximation
                                 Typical range: 4-50 depending on problem size
            validate: Whether to validate parameters
        """
        self.M = num_trotter_replicas
        self.validate = validate
        
        if self.validate and self.M < 1:
            raise ValueError(f"Number of Trotter replicas must be ≥ 1, got {self.M}")
    
    def compute_coupling_strength(self, beta: float, gamma: float) -> float:
        """
        Calculate effective coupling J_τ between adjacent Trotter replicas.
        
        Mathematical derivation:
        ========================
        The transverse field term -Γ Σ_i σ_i^x in the quantum Hamiltonian
        introduces off-diagonal matrix elements. After Trotter decomposition,
        this becomes a ferromagnetic coupling in the time direction:
        
            J_τ = -(1/(2β)) ln[tanh(βΓ/M)]
        
        Physical interpretation:
        - When Γ >> T: Strong quantum fluctuations → strong time coupling
        - When Γ << T: Weak quantum effects → weak time coupling
        - As M → ∞: Trotter error → 0 (continuous time limit)
        
        Args:
            beta: Inverse temperature β = 1/(k_B T)
            gamma: Transverse field strength Γ
            
        Returns:
            J_τ: Effective ferromagnetic coupling strength
            
        Raises:
            ValueError: If parameters are invalid
            
        Note:
            The tanh argument βΓ/M should not be too large to avoid numerical issues.
            For βΓ/M > 10, tanh(βΓ/M) ≈ 1, and ln(tanh) becomes numerically unstable.
        """
        if self.validate:
            if beta <= 0:
                raise ValueError(f"β must be positive, got {beta}")
            if gamma < 0:
                raise ValueError(f"Γ must be non-negative, got {gamma}")
        
        # Handle special cases
        if gamma == 0:
            # No transverse field → no quantum effects → no time coupling
            return 0.0
        
        # Compute effective coupling
        # J_τ = -(1/(2β)) ln[tanh(βΓ/M)]
        arg = beta * gamma / self.M
        
        # For numerical stability, handle large arguments
        if arg > 10:
            # tanh(x) ≈ 1 - 2e^(-2x) for large x
            # ln(tanh(x)) ≈ ln(1 - 2e^(-2x)) ≈ -2e^(-2x)
            J_tau = -(-1 / beta) * np.exp(-2 * arg)
        else:
            tanh_val = np.tanh(arg)
            if tanh_val <= 0 or tanh_val >= 1:
                raise ValueError(f"tanh(βΓ/M) out of valid range: {tanh_val}")
            J_tau = -(1 / (2 * beta)) * np.log(tanh_val)
        
        return float(J_tau)
    
    def initialize_replicas(self, n: int, sparsity: Optional[float] = None,
                           rng: Optional[np.random.Generator] = None) -> np.ndarray:
        """
        Initialize M replicas of the n-dimensional system.
        
        Creates an (M × n) array where:
        - Each row represents one Trotter replica (time slice)
        - Each column represents one variable across time
        - Values are ±1 (Ising spins)
        
        Args:
            n: Problem dimension (number of spins)
            sparsity: Fraction of +1 spins (default 0.5)
            rng: Random number generator
            
        Returns:
            replicas: (M × n) array of Ising spins {-1, +1}
            
        Example:
            For n=3, M=4, might initialize:
            [[ 1, -1,  1],    # τ=0
             [-1,  1, -1],    # τ=1
             [ 1,  1,  1],    # τ=2
             [-1, -1,  1]]    # τ=3
        """
        if rng is None:
            rng = np.random.default_rng()
        
        if sparsity is None:
            # Random ±1 spins
            replicas = 2 * rng.integers(0, 2, size=(self.M, n)) - 1
        else:
            # Biased initialization
            replicas = 2 * (rng.random((self.M, n)) < sparsity).astype(int) - 1
        
        return replicas
    
    def compute_effective_energy(self, replicas: np.ndarray, h: np.ndarray,
                                J: np.ndarray, J_tau: float) -> float:
        """
        Compute total effective energy of the replicated system.
        
        Mathematical formulation:
        =========================
        E_eff = Σ_{τ=1}^M E_classical(s^τ) + E_coupling(s^τ, s^{τ+1})
        
        where:
        E_classical(s^τ) = -Σ_i h_i s_i^τ - Σ_{i<j} J_ij s_i^τ s_j^τ
        E_coupling(s^τ, s^{τ+1}) = -J_τ Σ_i s_i^τ s_i^{τ+1}
        
        The coupling term implements quantum tunneling via thermal fluctuations.
        Periodic boundary conditions: s^{M+1} = s^1 (closed path in imaginary time)
        
        Args:
            replicas: (M × n) array of spin configurations
            h: (n,) array of local fields
            J: (n × n) coupling matrix (symmetric, zero diagonal)
            J_tau: Effective Trotter coupling strength
            
        Returns:
            Total effective energy
            
        Note:
            This is the negative log of the classical partition function weight:
            P(s^1,...,s^M) ∝ exp(-β E_eff)
        """
        M, n = replicas.shape
        
        if len(h) != n:
            raise ValueError(f"h dimension {len(h)} doesn't match replica size {n}")
        if J.shape != (n, n):
            raise ValueError(f"J shape {J.shape} doesn't match replica size {n}")
        
        total_energy = 0.0
        
        # Classical energy for each time slice
        for tau in range(M):
            s_tau = replicas[tau]
            
            # Linear term: -Σ_i h_i s_i^τ
            linear_energy = -np.dot(h, s_tau)
            
            # Quadratic term: -Σ_{i<j} J_ij s_i^τ s_j^τ
            # Using symmetric J with zero diagonal: -0.5 * s^T J s
            quadratic_energy = -0.5 * s_tau.T @ J @ s_tau
            
            total_energy += linear_energy + quadratic_energy
        
        # Coupling energy between adjacent time slices
        # -J_τ Σ_{τ=1}^M Σ_i s_i^τ s_i^{τ+1}
        # With periodic boundary: s^{M+1} = s^1
        for tau in range(M):
            s_tau = replicas[tau]
            s_next = replicas[(tau + 1) % M]  # Periodic boundary
            
            coupling_energy = -J_tau * np.sum(s_tau * s_next)
            total_energy += coupling_energy
        
        return float(total_energy)
    
    def compute_replica_delta_energy(self, replicas: np.ndarray, h: np.ndarray,
                                    J: np.ndarray, J_tau: float,
                                    replica_idx: int, spin_idx: int) -> float:
        """
        Efficiently compute energy change for flipping a single spin in one replica.
        
        When flipping s_i^τ → -s_i^τ, only the following terms change:
        1. Linear field: -h_i s_i^τ
        2. Coupling within slice τ: -Σ_j J_ij s_i^τ s_j^τ
        3. Time coupling to previous slice: -J_τ s_i^{τ-1} s_i^τ
        4. Time coupling to next slice: -J_τ s_i^τ s_i^{τ+1}
        
        Args:
            replicas: (M × n) array of current spin configurations
            h: (n,) local fields
            J: (n × n) coupling matrix
            J_tau: Trotter coupling
            replica_idx: Which replica (time slice) τ
            spin_idx: Which spin i to flip
            
        Returns:
            ΔE: Energy change from flip
        """
        M, n = replicas.shape
        current_spin = replicas[replica_idx, spin_idx]
        
        # Energy change components
        delta_E = 0.0
        
        # 1. Linear field contribution: Δ = 2 * h_i * s_i^τ
        delta_E += 2 * h[spin_idx] * current_spin
        
        # 2. Spatial coupling within time slice τ
        # Δ = 2 * s_i^τ * Σ_j J_ij s_j^τ
        spatial_interaction = 2 * current_spin * np.dot(J[spin_idx, :], replicas[replica_idx])
        delta_E += spatial_interaction
        
        # 3. Time coupling to adjacent replicas
        # Δ = 2 * J_τ * s_i^τ * (s_i^{τ-1} + s_i^{τ+1})
        prev_replica = (replica_idx - 1) % M
        next_replica = (replica_idx + 1) % M
        
        time_interaction = 2 * J_tau * current_spin * (
            replicas[prev_replica, spin_idx] + replicas[next_replica, spin_idx]
        )
        delta_E += time_interaction
        
        return float(delta_E)
    
    def get_trotter_parameters(self, n: int, beta: float, gamma: float) -> TrotterParameters:
        """
        Get complete Trotter decomposition parameters.
        
        Args:
            n: Problem dimension
            beta: Inverse temperature
            gamma: Transverse field strength
            
        Returns:
            TrotterParameters object with all parameters
        """
        J_tau = self.compute_coupling_strength(beta, gamma)
        
        return TrotterParameters(
            M=self.M,
            beta=beta,
            gamma=gamma,
            J_tau=J_tau,
            effective_2d_size=n * self.M
        )
    
    def replicas_to_binary(self, replicas: np.ndarray, use_majority: bool = True) -> np.ndarray:
        """
        Extract binary solution from Trotter replicas.
        
        Strategies:
        1. Majority voting across replicas: x_i = 1 if Σ_τ s_i^τ > 0
        2. Use first replica: x_i = (1 + s_i^1) / 2
        
        Args:
            replicas: (M × n) array of Ising spins
            use_majority: If True, use majority voting; else use first replica
            
        Returns:
            Binary solution x ∈ {0,1}^n
        """
        M, n = replicas.shape
        
        if use_majority:
            # Majority vote across time slices
            replica_sum = np.sum(replicas, axis=0)
            # Convert Ising {-1,+1} to binary {0,1}
            binary = (replica_sum > 0).astype(int)
        else:
            # Use first replica
            # Convert Ising to binary: x = (1 + s) / 2
            binary = ((1 + replicas[0]) // 2).astype(int)
        
        return binary
    
    def binary_to_replicas(self, x: np.ndarray, M: Optional[int] = None) -> np.ndarray:
        """
        Initialize all replicas from a binary solution.
        
        Args:
            x: Binary solution {0,1}^n
            M: Number of replicas (default: self.M)
            
        Returns:
            (M × n) replicas initialized from x
        """
        if M is None:
            M = self.M
        
        # Convert binary to Ising: s = 2x - 1
        spins = 2 * x - 1
        
        # Replicate across all time slices
        replicas = np.tile(spins, (M, 1))
        
        return replicas
    
    def get_convergence_metric(self, replicas: np.ndarray) -> Dict[str, float]:
        """
        Compute convergence metrics for replica system.
        
        Metrics:
        - replica_variance: Variance across time slices (quantum decoherence)
        - time_correlation: Correlation between adjacent slices
        - magnetization: Average spin across all replicas
        
        Args:
            replicas: (M × n) spin configurations
            
        Returns:
            Dictionary of convergence metrics
        """
        M, n = replicas.shape
        
        # Variance across replicas for each variable
        replica_variance = np.mean(np.var(replicas, axis=0))
        
        # Time correlation between adjacent slices
        correlations = []
        for tau in range(M):
            s_tau = replicas[tau]
            s_next = replicas[(tau + 1) % M]
            corr = np.mean(s_tau * s_next)
            correlations.append(corr)
        time_correlation = np.mean(correlations)
        
        # Overall magnetization
        magnetization = np.mean(replicas)
        
        return {
            'replica_variance': float(replica_variance),
            'time_correlation': float(time_correlation),
            'magnetization': float(magnetization),
            'num_replicas': M,
            'problem_size': n
        }
    
    def __repr__(self) -> str:
        """String representation."""
        return f"TrotterExpansion(M={self.M})"
