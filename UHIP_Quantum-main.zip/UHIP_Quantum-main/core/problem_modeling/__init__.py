"""
Problem Modeling Module

Contains urban heat island (UHI) problem formulations and cooling kernels.
"""

from core.problem_modeling.cooling_kernels import (
    CoolingKernel,
    GaussianCoolingKernel,
    ExponentialCoolingKernel,
    PowerLawCoolingKernel,
    CompactSupportKernel,
    AnisotropicGaussianKernel,
    KernelParameters,
    compute_qubo_cooling_coefficients,
    estimate_kernel_parameters_from_data,
    create_kernel_from_parameters
)

from core.problem_modeling.uhi_green_layout import (
    UHIGreenLayoutProblem,
    UHIProblemConfig,
    GridCell
)

__all__ = [
    # Cooling kernels
    'CoolingKernel',
    'GaussianCoolingKernel',
    'ExponentialCoolingKernel',
    'PowerLawCoolingKernel',
    'CompactSupportKernel',
    'AnisotropicGaussianKernel',
    'KernelParameters',
    'compute_qubo_cooling_coefficients',
    'estimate_kernel_parameters_from_data',
    'create_kernel_from_parameters',
    
    # Problem formulation
    'UHIGreenLayoutProblem',
    'UHIProblemConfig',
    'GridCell'
]
