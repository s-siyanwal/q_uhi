"""
Spatial Cooling Kernels for UHI Modeling

Implements spatial interaction kernels for modeling Urban Heat Island (UHI)
cooling effects from green infrastructure.

Physical Basis:
- Green spaces reduce local temperature through evapotranspiration and shading
- Cooling effects extend to neighboring areas via advection and diffusion
- Spatial interactions decay with distance
- Multiple green spaces can have synergistic or competitive effects

Mathematical Formulation:
The cooling effect at location r from green infrastructure x is:
    ΔT(r, x) = Σ_i α_i(r) x_i + Σ_{i,j} β_ij(r) x_i x_j

where:
- α_i(r): Direct cooling contribution from cell i at location r
- β_ij(r): Interaction effect between cells i and j at location r
- x_i ∈ {0,1}: Binary indicator of green space in cell i

For QUBO formulation, we aggregate over the urban domain:
    Cooling objective = Σ_i α_i x_i + Σ_{i<j} β_ij x_i x_j

Reference: Section V (UHI-Green-Layout Problem Definition) from documents
"""

import numpy as np
from typing import Callable, Tuple, Optional, Dict
from scipy.spatial.distance import cdist
from dataclasses import dataclass

# Physical constant: standard correlation decay threshold (1/e) for kernel fitting
KERNEL_CORRELATION_DECAY_THRESHOLD = np.exp(-1)  # ≈ 0.368


@dataclass
class KernelParameters:
    """Parameters for spatial cooling kernels."""
    kernel_type: str  # 'gaussian', 'exponential', 'power_law', 'compact'
    length_scale: float  # Characteristic spatial scale (meters)
    amplitude: float  # Kernel amplitude (°C or normalized)
    cutoff_distance: Optional[float] = None  # Distance beyond which kernel is zero
    interaction_type: str = 'synergistic'  # 'synergistic' or 'competitive'


class CoolingKernel:
    """
    Base class for spatial cooling kernels.
    
    A kernel K(r₁, r₂) quantifies the interaction strength between
    two locations r₁ and r₂ in the spatial domain.
    """
    
    def __call__(self, r1: np.ndarray, r2: np.ndarray) -> float:
        """
        Evaluate kernel between two locations.
        
        Args:
            r1: Position vector [x1, y1]
            r2: Position vector [x2, y2]
            
        Returns:
            Kernel value K(r1, r2)
        """
        raise NotImplementedError
    
    def kernel_matrix(self, positions: np.ndarray) -> np.ndarray:
        """
        Compute kernel matrix for array of positions.
        
        Args:
            positions: Array of shape (n, 2) with [x, y] coordinates
            
        Returns:
            Kernel matrix K of shape (n, n) where K_ij = K(r_i, r_j)
        """
        n = positions.shape[0]
        K = np.zeros((n, n))
        
        for i in range(n):
            for j in range(i, n):
                K[i, j] = self(positions[i], positions[j])
                K[j, i] = K[i, j]  # Symmetric
        
        return K


class GaussianCoolingKernel(CoolingKernel):
    """
    Gaussian spatial kernel for diffusive cooling processes.
    
    Mathematical form:
        K(r₁, r₂) = A * exp(-||r₁ - r₂||² / (2σ²))
    
    Physical interpretation:
    - Models diffusion-dominated heat transfer
    - σ: Length scale of cooling influence
    - A: Maximum cooling amplitude
    
    Properties:
    - Smooth and infinitely differentiable
    - Long-range interactions (infinite support)
    - Commonly used in Gaussian Process regression
    
    Reference: Section V.2.1 (Gaussian Kernel Approximation)
    """
    
    def __init__(self, sigma: float, amplitude: float = 1.0,
                 cutoff_distance: Optional[float] = None):
        """
        Initialize Gaussian kernel.
        
        Args:
            sigma: Length scale (standard deviation in meters)
            amplitude: Kernel amplitude (cooling strength)
            cutoff_distance: Optional cutoff for computational efficiency
                           (kernel set to 0 beyond this distance)
        """
        self.sigma = sigma
        self.amplitude = amplitude
        self.cutoff_distance = cutoff_distance or (3 * sigma)  # 3σ captures ~99.7%
        
    def __call__(self, r1: np.ndarray, r2: np.ndarray) -> float:
        """
        Evaluate Gaussian kernel.
        
        K(r₁, r₂) = A * exp(-d²/(2σ²)) where d = ||r₁ - r₂||
        """
        distance = np.linalg.norm(r1 - r2)
        
        # Apply cutoff for sparsity
        if distance > self.cutoff_distance:
            return 0.0
        
        return self.amplitude * np.exp(-distance**2 / (2 * self.sigma**2))
    
    def kernel_matrix(self, positions: np.ndarray) -> np.ndarray:
        """
        Efficient computation using scipy.spatial.distance.
        
        For n positions, computes all n(n+1)/2 pairwise distances at once.
        """
        # Compute pairwise distance matrix
        dist_matrix = cdist(positions, positions, metric='euclidean')
        
        # Apply Gaussian kernel
        K = self.amplitude * np.exp(-dist_matrix**2 / (2 * self.sigma**2))
        
        # Apply cutoff
        if self.cutoff_distance is not None:
            K[dist_matrix > self.cutoff_distance] = 0.0
        
        return K


class ExponentialCoolingKernel(CoolingKernel):
    """
    Exponential decay kernel for advection-dominated cooling.
    
    Mathematical form:
        K(r₁, r₂) = A * exp(-||r₁ - r₂|| / λ)
    
    Physical interpretation:
    - Models advection-diffusion balance
    - λ: Characteristic decay length
    - Sharper decay than Gaussian (better for localized effects)
    
    Properties:
    - Continuous but not differentiable at r₁ = r₂
    - Intermediate range interactions
    - Used in Matérn covariance functions (ν=1/2)
    
    Reference: Section V.2.2 (Exponential Kernel)
    """
    
    def __init__(self, length_scale: float, amplitude: float = 1.0,
                 cutoff_distance: Optional[float] = None):
        """
        Initialize exponential kernel.
        
        Args:
            length_scale: Decay length λ (meters)
            amplitude: Kernel amplitude
            cutoff_distance: Distance cutoff for sparsity
        """
        self.length_scale = length_scale
        self.amplitude = amplitude
        self.cutoff_distance = cutoff_distance or (5 * length_scale)
    
    def __call__(self, r1: np.ndarray, r2: np.ndarray) -> float:
        """Evaluate exponential kernel."""
        distance = np.linalg.norm(r1 - r2)
        
        if distance > self.cutoff_distance:
            return 0.0
        
        return self.amplitude * np.exp(-distance / self.length_scale)
    
    def kernel_matrix(self, positions: np.ndarray) -> np.ndarray:
        """Efficient matrix computation."""
        dist_matrix = cdist(positions, positions, metric='euclidean')
        K = self.amplitude * np.exp(-dist_matrix / self.length_scale)
        
        if self.cutoff_distance is not None:
            K[dist_matrix > self.cutoff_distance] = 0.0
        
        return K


class PowerLawCoolingKernel(CoolingKernel):
    """
    Power law decay kernel for long-range interactions.
    
    Mathematical form:
        K(r₁, r₂) = A / (1 + ||r₁ - r₂||/λ)^p
    
    Physical interpretation:
    - Models cooling plumes and long-range advection
    - p controls decay rate (larger p = faster decay)
    - Includes regularization to avoid singularity at r₁ = r₂
    
    Properties:
    - Heavy-tailed (slower than exponential for p < ∞)
    - Suitable for urban canyons and channeled flow
    
    Reference: Section V.2.3 (Power Law Kernel)
    """
    
    def __init__(self, length_scale: float, power: float = 2.0,
                 amplitude: float = 1.0, regularization: float = 1.0):
        """
        Initialize power law kernel.
        
        Args:
            length_scale: Reference length λ
            power: Decay exponent p (typically 1-3)
            amplitude: Kernel amplitude
            regularization: Regularization parameter to avoid r₁=r₂ singularity
        """
        self.length_scale = length_scale
        self.power = power
        self.amplitude = amplitude
        self.regularization = regularization
    
    def __call__(self, r1: np.ndarray, r2: np.ndarray) -> float:
        """Evaluate power law kernel."""
        distance = np.linalg.norm(r1 - r2)
        normalized_dist = distance / self.length_scale
        
        return self.amplitude / (self.regularization + normalized_dist)**self.power
    
    def kernel_matrix(self, positions: np.ndarray) -> np.ndarray:
        """Efficient matrix computation."""
        dist_matrix = cdist(positions, positions, metric='euclidean')
        normalized_dist = dist_matrix / self.length_scale
        
        K = self.amplitude / (self.regularization + normalized_dist)**self.power
        
        return K


class CompactSupportKernel(CoolingKernel):
    """
    Compact support kernel for strictly local interactions.
    
    Mathematical form (Wendland C2):
        K(r₁, r₂) = A * (1 - d/R)^4 (4d/R + 1)  for d < R
        K(r₁, r₂) = 0                            for d ≥ R
    
    where d = ||r₁ - r₂||, R = support radius
    
    Physical interpretation:
    - Captures strictly local neighborhood effects
    - No interaction beyond distance R
    - Smooth at boundary (C2 continuous)
    
    Properties:
    - Exactly zero beyond R (sparse matrices)
    - Computationally efficient for large problems
    - Positive definite (valid covariance function)
    
    Reference: Wendland (1995), Piecewise polynomial kernels
    """
    
    def __init__(self, support_radius: float, amplitude: float = 1.0):
        """
        Initialize compact support kernel.
        
        Args:
            support_radius: Radius R beyond which kernel is zero
            amplitude: Kernel amplitude
        """
        self.support_radius = support_radius
        self.amplitude = amplitude
    
    def __call__(self, r1: np.ndarray, r2: np.ndarray) -> float:
        """Evaluate Wendland C2 kernel."""
        distance = np.linalg.norm(r1 - r2)
        
        if distance >= self.support_radius:
            return 0.0
        
        # Normalized distance
        t = distance / self.support_radius
        
        # Wendland C2 kernel: (1-t)^4 (4t + 1)
        return self.amplitude * (1 - t)**4 * (4*t + 1)
    
    def kernel_matrix(self, positions: np.ndarray) -> np.ndarray:
        """Efficient matrix computation with sparsity."""
        dist_matrix = cdist(positions, positions, metric='euclidean')
        
        # Normalized distance
        t = dist_matrix / self.support_radius
        
        # Initialize kernel matrix
        K = np.zeros_like(dist_matrix)
        
        # Apply kernel only where d < R
        mask = dist_matrix < self.support_radius
        K[mask] = self.amplitude * (1 - t[mask])**4 * (4*t[mask] + 1)
        
        return K


class AnisotropicGaussianKernel(CoolingKernel):
    """
    Anisotropic Gaussian kernel with directional preferences.
    
    Mathematical form:
        K(r₁, r₂) = A * exp(-0.5 * Δr^T Σ^{-1} Δr)
    
    where Σ is a covariance matrix encoding directional length scales.
    
    Physical interpretation:
    - Models prevailing wind direction effects
    - Elongated cooling plumes downwind
    - Different length scales in x and y directions
    
    Application:
    - Urban areas with dominant wind patterns
    - Anisotropic urban geometry (street canyons)
    
    Reference: Section V.2.4 (Anisotropic Effects)
    """
    
    def __init__(self, sigma_x: float, sigma_y: float, 
                 rotation_angle: float = 0.0, amplitude: float = 1.0):
        """
        Initialize anisotropic Gaussian kernel.
        
        Args:
            sigma_x: Length scale in principal x direction
            sigma_y: Length scale in principal y direction
            rotation_angle: Rotation of principal axes (radians)
            amplitude: Kernel amplitude
        """
        self.sigma_x = sigma_x
        self.sigma_y = sigma_y
        self.rotation_angle = rotation_angle
        self.amplitude = amplitude
        
        # Construct covariance matrix
        # Σ = R Λ R^T where Λ = diag(σ_x², σ_y²), R = rotation matrix
        cos_theta = np.cos(rotation_angle)
        sin_theta = np.sin(rotation_angle)
        R = np.array([[cos_theta, -sin_theta],
                     [sin_theta, cos_theta]])
        
        Lambda = np.diag([sigma_x**2, sigma_y**2])
        self.Sigma = R @ Lambda @ R.T
        self.Sigma_inv = np.linalg.inv(self.Sigma)
    
    def __call__(self, r1: np.ndarray, r2: np.ndarray) -> float:
        """Evaluate anisotropic Gaussian kernel."""
        delta_r = r1 - r2
        
        # Mahalanobis distance: sqrt(Δr^T Σ^{-1} Δr)
        exponent = -0.5 * delta_r.T @ self.Sigma_inv @ delta_r
        
        return self.amplitude * np.exp(exponent)
    
    def kernel_matrix(self, positions: np.ndarray) -> np.ndarray:
        """Efficient matrix computation."""
        n = positions.shape[0]
        K = np.zeros((n, n))
        
        for i in range(n):
            delta_r = positions - positions[i]  # Broadcasting
            # Vectorized Mahalanobis distance
            exponents = -0.5 * np.sum((delta_r @ self.Sigma_inv) * delta_r, axis=1)
            K[i, :] = self.amplitude * np.exp(exponents)
        
        return K


def compute_qubo_cooling_coefficients(positions: np.ndarray, 
                                      kernel: CoolingKernel,
                                      base_cooling: Optional[np.ndarray] = None
                                      ) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute QUBO coefficients (α, β) from spatial kernel.
    
    Given:
    - n candidate cells at positions r_i
    - Cooling kernel K(r_i, r_j)
    
    Compute:
    - α_i: Direct cooling benefit of cell i (diagonal contribution)
    - β_ij: Interaction between cells i and j (off-diagonal)
    
    Physical model:
    Total cooling = Σ_i α_i x_i + Σ_{i<j} β_ij x_i x_j
    
    Default construction:
    - α_i = K(r_i, r_i) + base_cooling_i
    - β_ij = K(r_i, r_j) for i ≠ j
    
    Sign convention:
    - Positive α_i: Cooling benefit (minimize negative of temperature)
    - Negative β_ij: Synergistic cooling (adjacent greens amplify effect)
    - Positive β_ij: Competitive cooling (diminishing returns)
    
    Args:
        positions: Array of cell centers, shape (n, 2)
        kernel: Cooling kernel instance
        base_cooling: Optional array of base cooling values (length n)
        
    Returns:
        (alpha, beta):
        - alpha: Linear coefficients (n,)
        - beta: Quadratic coefficients (n, n, symmetric)
        
    Example:
        >>> positions = np.array([[0, 0], [100, 0], [0, 100]])
        >>> kernel = GaussianCoolingKernel(sigma=50, amplitude=-0.5)
        >>> alpha, beta = compute_qubo_cooling_coefficients(positions, kernel)
    """
    n = positions.shape[0]
    
    # Compute kernel matrix
    K = kernel.kernel_matrix(positions)
    
    # Linear coefficients: diagonal + base cooling
    alpha = np.diag(K).copy()
    if base_cooling is not None:
        if len(base_cooling) != n:
            raise ValueError(f"base_cooling must have length {n}")
        alpha += base_cooling
    
    # Quadratic coefficients: off-diagonal kernel values
    beta = K.copy()
    np.fill_diagonal(beta, 0)  # Remove diagonal (absorbed in alpha)
    
    return alpha, beta


def estimate_kernel_parameters_from_data(positions: np.ndarray,
                                         cooling_measurements: np.ndarray,
                                         kernel_type: str = 'gaussian'
                                         ) -> KernelParameters:
    """
    Estimate kernel parameters from empirical cooling data.
    
    Uses simple heuristics:
    1. Amplitude from variance of measurements
    2. Length scale from spatial correlation decay
    
    For production use, consider:
    - Gaussian Process regression with hyperparameter optimization
    - Maximum likelihood estimation
    - Bayesian inference
    
    Args:
        positions: Observation locations (n, 2)
        cooling_measurements: Observed cooling effects (n,)
        kernel_type: Type of kernel to fit
        
    Returns:
        Estimated kernel parameters
    """
    # Amplitude estimate: standard deviation of measurements
    amplitude = float(np.std(cooling_measurements))
    
    # Length scale estimate: distance at which correlation drops to e^{-1}
    # Compute pairwise distances and correlations
    dist_matrix = cdist(positions, positions)
    cooling_centered = cooling_measurements - np.mean(cooling_measurements)
    correlation_matrix = np.outer(cooling_centered, cooling_centered)
    correlation_matrix /= (amplitude**2 + 1e-10)
    
    # Flatten upper triangle
    triu_indices = np.triu_indices_from(dist_matrix, k=1)
    distances = dist_matrix[triu_indices]
    correlations = correlation_matrix[triu_indices]
    
    # Sort by distance  
    sorted_idx = np.argsort(distances)
    sorted_dist = distances[sorted_idx]
    sorted_corr = np.abs(correlations[sorted_idx])
    
    # Find distance where correlation drops to decay threshold
    crossing_idx = np.where(sorted_corr < KERNEL_CORRELATION_DECAY_THRESHOLD)[0]
    if len(crossing_idx) > 0:
        length_scale = float(sorted_dist[crossing_idx[0]])
    else:
        # Fallback: use median distance
        length_scale = float(np.median(distances))
    
    return KernelParameters(
        kernel_type=kernel_type,
        length_scale=length_scale,
        amplitude=amplitude,
        cutoff_distance=3 * length_scale,
        interaction_type='synergistic'
    )


def create_kernel_from_parameters(params: KernelParameters) -> CoolingKernel:
    """
    Factory function to create kernel from parameters.
    
    Args:
        params: Kernel parameters
        
    Returns:
        Cooling kernel instance
    """
    if params.kernel_type == 'gaussian':
        return GaussianCoolingKernel(
            sigma=params.length_scale,
            amplitude=params.amplitude,
            cutoff_distance=params.cutoff_distance
        )
    elif params.kernel_type == 'exponential':
        return ExponentialCoolingKernel(
            length_scale=params.length_scale,
            amplitude=params.amplitude,
            cutoff_distance=params.cutoff_distance
        )
    elif params.kernel_type == 'power_law':
        return PowerLawCoolingKernel(
            length_scale=params.length_scale,
            amplitude=params.amplitude
        )
    elif params.kernel_type == 'compact':
        return CompactSupportKernel(
            support_radius=params.length_scale,
            amplitude=params.amplitude
        )
    else:
        raise ValueError(f"Unknown kernel type: {params.kernel_type}")
