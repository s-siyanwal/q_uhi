"""
UHI Green Space Layout Problem - Main Problem Class

Implements the complete UHI-Green-Layout-QUBO problem formulation.

Problem Statement:
Given an urban grid with candidate locations for green infrastructure,
determine the optimal allocation of green spaces to minimize Urban Heat
Island (UHI) intensity subject to area, budget, and equity constraints.

Mathematical Formulation:
    minimize    f(x) = ΔI_UHI(x) = Σ α_i x_i + Σ β_ij x_i x_j
    subject to  Σ area_i x_i ≤ A_max          (area constraint)
                Σ cost_i x_i ≤ B_max          (budget constraint)
                equity constraints             (fairness)
                x_i ∈ {0, 1}                  (binary decisions)

where:
- x_i = 1 if green space allocated to cell i, 0 otherwise
- α_i: Direct cooling benefit of cell i
- β_ij: Interaction cooling effect between cells i and j
- ΔI_UHI: Change in UHI intensity (negative = cooling)

Reference: Section V (UHI-Green-Layout Problem) from mathematical documents
"""

import numpy as np
from typing import Tuple, Dict, List, Optional, Set
from dataclasses import dataclass, field
import warnings

from core.problem_modeling.cooling_kernels import (
    CoolingKernel, GaussianCoolingKernel, compute_qubo_cooling_coefficients,
    KernelParameters, create_kernel_from_parameters
)
from core.qubo_formulation.qubo_matrix_builder import QUBOMatrixBuilder, QUBOBuildConfig
from core.qubo_formulation.binary_encoding import BinaryVariableSet


@dataclass
class GridCell:
    """Represents a single grid cell in the urban domain."""
    index: int
    position: np.ndarray  # [x, y] coordinates in meters
    area: float  # m²
    land_use_type: str  # 'candidate', 'building', 'road', 'water', 'existing_green'
    base_temperature: float = 30.0  # °C baseline temperature
    greening_cost: float = 0.0  # Cost to convert to green space
    population_density: float = 0.0  # people/km²
    metadata: Dict = field(default_factory=dict)
    
    def is_candidate(self) -> bool:
        """Check if cell is a candidate for green space allocation."""
        return self.land_use_type == 'candidate'


@dataclass
class UHIProblemConfig:
    """Configuration for UHI green layout problem."""
    grid_rows: int
    grid_cols: int
    cell_size: float = 50.0  # meters (50m × 50m cells)
    
    # Physical parameters
    cooling_kernel_type: str = 'gaussian'
    cooling_length_scale: float = 100.0  # meters
    cooling_amplitude: float = -2.0  # °C per green cell
    
    # Constraints
    area_budget_fraction: float = 0.3  # Max 30% of area
    total_budget: Optional[float] = None  # $ total budget
    min_green_cells: Optional[int] = None
    max_green_cells: Optional[int] = None
    
    # Equity constraints
    enable_equity_constraints: bool = False
    min_green_per_district: Optional[int] = None
    
    # QUBO formulation
    penalty_weight: Optional[float] = None
    auto_penalty: bool = True
    
    def __post_init__(self):
        """Validate configuration."""
        if self.grid_rows < 1 or self.grid_cols < 1:
            raise ValueError("Grid dimensions must be positive")
        if self.cell_size <= 0:
            raise ValueError("Cell size must be positive")
        if not 0 < self.area_budget_fraction <= 1:
            raise ValueError("area_budget_fraction must be in (0, 1]")


class UHIGreenLayoutProblem:
    """
    Main class for UHI-Green-Layout-QUBO problem.
    
    Workflow:
    1. Initialize grid and cells
    2. Define land use (candidates, fixed infrastructure)
    3. Setup cooling model (kernel, parameters)
    4. Add constraints (area, budget, equity)
    5. Build QUBO formulation
    6. Solve with classical or quantum solver
    7. Validate and visualize solution
    
    Example:
        >>> config = UHIProblemConfig(grid_rows=10, grid_cols=10)
        >>> problem = UHIGreenLayoutProblem(config)
        >>> problem.setup_uniform_grid()
        >>> problem.setup_cooling_model()
        >>> Q, metadata = problem.build_qubo()
        >>> # Solve Q using your preferred solver
    """
    
    def __init__(self, config: UHIProblemConfig):
        """
        Initialize UHI green layout problem.
        
        Args:
            config: Problem configuration
        """
        self.config = config
        
        # Grid properties
        self.n_rows = config.grid_rows
        self.n_cols = config.grid_cols
        self.n_cells = self.n_rows * self.n_cols
        self.cell_size = config.cell_size
        self.cell_area = config.cell_size ** 2
        
        # Grid cells
        self.cells: List[GridCell] = []
        self.candidate_indices: List[int] = []
        self.fixed_indices: Set[int] = set()
        self.n_candidates = 0
        
        # Physical model
        self.cooling_kernel: Optional[CoolingKernel] = None
        self.alpha: Optional[np.ndarray] = None  # Linear cooling coeffs
        self.beta: Optional[np.ndarray] = None   # Quadratic cooling coeffs
        
        # Binary variables
        self.binary_vars: Optional[BinaryVariableSet] = None
        
        # QUBO formulation
        self.qubo_builder: Optional[QUBOMatrixBuilder] = None
        self.Q_matrix: Optional[np.ndarray] = None
        self.qubo_metadata: Dict = {}
        
        # Solution
        self.solution: Optional[np.ndarray] = None
        self.solution_energy: Optional[float] = None
        
    def setup_uniform_grid(self, candidate_fraction: float = 0.5,
                           random_seed: Optional[int] = None):
        """
        Setup uniform grid with random candidate cells.
        
        Creates a regular grid where a fraction of cells are candidates
        for green space allocation, and the rest are fixed infrastructure.
        
        Args:
            candidate_fraction: Fraction of cells that are candidates
            random_seed: Random seed for reproducibility (None = non-deterministic)
        """
        # Create random number generator for thread-safe reproducibility
        rng = np.random.default_rng(random_seed)
        
        self.cells = []
        
        for row in range(self.n_rows):
            for col in range(self.n_cols):
                index = row * self.n_cols + col
                
                # Cell center position
                x = (col + 0.5) * self.cell_size
                y = (row + 0.5) * self.cell_size
                position = np.array([x, y])
                
                # Randomly assign as candidate or building
                if rng.random() < candidate_fraction:
                    land_use = 'candidate'
                    cost = rng.uniform(50, 150)  # k$ per cell
                else:
                    land_use = 'building'
                    cost = 0.0
                
                cell = GridCell(
                    index=index,
                    position=position,
                    area=self.cell_area,
                    land_use_type=land_use,
                    base_temperature=30.0 + rng.normal(0, 1),
                    greening_cost=cost,
                    population_density=rng.uniform(100, 1000)
                )
                
                self.cells.append(cell)
                
                if cell.is_candidate():
                    self.candidate_indices.append(index)
                else:
                    self.fixed_indices.add(index)
        
        self.n_candidates = len(self.candidate_indices)
        
        # Create binary variables for candidates only
        self.binary_vars = BinaryVariableSet(
            size=self.n_candidates,
            name_prefix="green"
        )
        for i, cell_idx in enumerate(self.candidate_indices):
            self.binary_vars.set_description(
                i, f"Green space in cell {cell_idx} at {self.cells[cell_idx].position}"
            )
    
    def setup_from_land_use_map(self, land_use_map: np.ndarray,
                               cost_map: Optional[np.ndarray] = None):
        """
        Setup grid from land use classification map.
        
        Args:
            land_use_map: Array of shape (n_rows, n_cols) with land use codes:
                         0 = building, 1 = candidate, 2 = road, 3 = water, 4 = existing green
            cost_map: Optional cost map (same shape)
        """
        if land_use_map.shape != (self.n_rows, self.n_cols):
            raise ValueError(f"land_use_map must be {self.n_rows}×{self.n_cols}")
        
        land_use_names = {
            0: 'building',
            1: 'candidate',
            2: 'road',
            3: 'water',
            4: 'existing_green'
        }
        
        self.cells = []
        
        for row in range(self.n_rows):
            for col in range(self.n_cols):
                index = row * self.n_cols + col
                
                x = (col + 0.5) * self.cell_size
                y = (row + 0.5) * self.cell_size
                position = np.array([x, y])
                
                land_use_code = land_use_map[row, col]
                land_use = land_use_names.get(land_use_code, 'building')
                
                cost = 0.0
                if cost_map is not None:
                    cost = cost_map[row, col]
                elif land_use == 'candidate':
                    cost = 100.0  # Default cost
                
                cell = GridCell(
                    index=index,
                    position=position,
                    area=self.cell_area,
                    land_use_type=land_use,
                    greening_cost=cost
                )
                
                self.cells.append(cell)
                
                if cell.is_candidate():
                    self.candidate_indices.append(index)
                else:
                    self.fixed_indices.add(index)
        
        self.n_candidates = len(self.candidate_indices)
        self.binary_vars = BinaryVariableSet(size=self.n_candidates, name_prefix="green")
    
    def setup_cooling_model(self, kernel: Optional[CoolingKernel] = None,
                           base_cooling_per_cell: Optional[float] = None):
        """
        Setup UHI cooling model using spatial kernel.
        
        Computes:
        - α_i: Direct cooling benefit of greening cell i
        - β_ij: Interaction cooling between cells i and j
        
        Mathematical model:
            ΔI_UHI(x) = Σ α_i x_i + Σ β_ij x_i x_j
        
        Args:
            kernel: Cooling kernel (if None, uses config defaults)
            base_cooling_per_cell: Base cooling per cell (°C)
        """
        if kernel is None:
            # Create default kernel from config
            kernel_params = KernelParameters(
                kernel_type=self.config.cooling_kernel_type,
                length_scale=self.config.cooling_length_scale,
                amplitude=self.config.cooling_amplitude,
                cutoff_distance=3 * self.config.cooling_length_scale
            )
            kernel = create_kernel_from_parameters(kernel_params)
        
        self.cooling_kernel = kernel
        
        # Get positions of candidate cells only
        candidate_positions = np.array([
            self.cells[idx].position for idx in self.candidate_indices
        ])
        
        # Base cooling values
        base_cooling = None
        if base_cooling_per_cell is not None:
            base_cooling = np.full(self.n_candidates, base_cooling_per_cell)
        
        # Compute QUBO coefficients
        self.alpha, self.beta = compute_qubo_cooling_coefficients(
            candidate_positions,
            kernel,
            base_cooling
        )
        
        # Sign convention: we want to MINIMIZE temperature (maximize cooling)
        # If kernel gives negative values (cooling), negate to get costs to minimize
        # If kernel gives positive values (temperature reduction), use as is
        # Adjust based on your convention
        
    def build_qubo(self) -> Tuple[np.ndarray, Dict]:
        """
        Build complete QUBO matrix with all constraints.
        
        Combines:
        1. Physical cooling objective (α, β)
        2. Area constraint penalty
        3. Budget constraint penalty (if applicable)
        4. Cardinality constraints (if applicable)
        
        Returns:
            (Q, metadata):
            - Q: QUBO matrix (n_candidates × n_candidates)
            - metadata: Problem information and statistics
        """
        if self.alpha is None or self.beta is None:
            raise RuntimeError("Must call setup_cooling_model() first")
        
        # Initialize QUBO builder
        qubo_config = QUBOBuildConfig(
            n_variables=self.n_candidates,
            auto_penalty_weight=self.config.auto_penalty,
            penalty_weight=self.config.penalty_weight or 10.0,
            penalty_safety_factor=2.0
        )
        self.qubo_builder = QUBOMatrixBuilder(qubo_config)
        
        # Add physical objective
        self.qubo_builder.add_physical_objective(self.alpha, self.beta)
        
        # Add area constraint: Σ area_i x_i ≤ A_max
        candidate_areas = np.array([
            self.cells[idx].area for idx in self.candidate_indices
        ])
        total_candidate_area = np.sum(candidate_areas)
        area_max = self.config.area_budget_fraction * total_candidate_area
        
        self.qubo_builder.add_area_constraint(candidate_areas, area_max)
        
        # Add budget constraint if specified
        if self.config.total_budget is not None:
            candidate_costs = np.array([
                self.cells[idx].greening_cost for idx in self.candidate_indices
            ])
            self.qubo_builder.add_budget_constraint(
                candidate_costs,
                self.config.total_budget
            )
        
        # Add cardinality constraints if specified
        if self.config.min_green_cells is not None:
            # Minimum greens: Σ x_i ≥ k_min
            # Reformulated as: Σ x_i = k_min + slack
            # For simplicity, use soft constraint via penalty
            pass  # TODO: Implement if needed
        
        if self.config.max_green_cells is not None:
            # Maximum greens: Σ x_i ≤ k_max
            unit_coeffs = np.ones(self.n_candidates)
            self.qubo_builder.add_inequality_constraint(
                unit_coeffs,
                self.config.max_green_cells,
                constraint_name="max_green_cells"
            )
        
        # Build final QUBO matrix
        self.Q_matrix = self.qubo_builder.build()
        
        # Collect metadata
        self.qubo_metadata = {
            'n_cells_total': self.n_cells,
            'n_candidates': self.n_candidates,
            'n_fixed': len(self.fixed_indices),
            'grid_shape': (self.n_rows, self.n_cols),
            'cell_size': self.cell_size,
            'area_budget': area_max,
            'total_budget': self.config.total_budget,
            'cooling_kernel': self.config.cooling_kernel_type,
            'length_scale': self.config.cooling_length_scale,
            'qubo_statistics': self.qubo_builder.get_statistics(),
            'constraints': self.qubo_builder.get_constraint_metadata()
        }
        
        return self.Q_matrix, self.qubo_metadata
    
    def set_solution(self, x: np.ndarray):
        """
        Set solution and compute its energy.
        
        Args:
            x: Binary solution vector (length n_candidates)
        """
        if len(x) != self.n_candidates:
            raise ValueError(f"Solution must have length {self.n_candidates}")
        
        if not np.all(np.logical_or(x == 0, x == 1)):
            raise ValueError("Solution must be binary")
        
        self.solution = x.copy()
        self.solution_energy = self.evaluate_solution(x)['total_energy']
    
    def evaluate_solution(self, x: np.ndarray) -> Dict[str, float]:
        """
        Evaluate solution and decompose energy.
        
        Args:
            x: Binary solution vector
            
        Returns:
            Dictionary with energy breakdown
        """
        if self.qubo_builder is None:
            raise RuntimeError("Must call build_qubo() first")
        
        return self.qubo_builder.evaluate_solution(x)
    
    def get_solution_grid(self) -> np.ndarray:
        """
        Convert solution to full grid representation.
        
        Returns:
            Grid of shape (n_rows, n_cols) with values:
            0 = no green space
            1 = new green space (from solution)
            2 = existing green space
            3 = building/fixed infrastructure
        """
        if self.solution is None:
            raise RuntimeError("No solution set")
        
        grid = np.full((self.n_rows, self.n_cols), 3, dtype=int)  # Default: fixed
        
        for i, cell_idx in enumerate(self.candidate_indices):
            row = cell_idx // self.n_cols
            col = cell_idx % self.n_cols
            
            if self.solution[i] == 1:
                grid[row, col] = 1  # New green space
            else:
                grid[row, col] = 0  # No allocation
        
        # Mark existing green spaces
        for cell in self.cells:
            if cell.land_use_type == 'existing_green':
                row = cell.index // self.n_cols
                col = cell.index % self.n_cols
                grid[row, col] = 2
        
        return grid
    
    def get_solution_statistics(self) -> Dict:
        """
        Compute statistics about the solution.
        
        Returns:
            Dictionary with solution statistics
        """
        if self.solution is None:
            raise RuntimeError("No solution set")
        
        n_selected = int(np.sum(self.solution))
        selected_indices = [self.candidate_indices[i] 
                          for i in range(self.n_candidates) if self.solution[i] == 1]
        
        total_area = sum(self.cells[idx].area for idx in selected_indices)
        total_cost = sum(self.cells[idx].greening_cost for idx in selected_indices)
        
        # Compute constraint violations
        eval_result = self.evaluate_solution(self.solution)
        
        return {
            'n_green_cells': n_selected,
            'total_area_m2': total_area,
            'total_cost': total_cost,
            'fraction_of_candidates': n_selected / self.n_candidates,
            'total_energy': eval_result['total_energy'],
            'physical_energy': eval_result['physical_energy'],
            'constraint_violations': eval_result['constraint_violations'],
            'selected_cell_indices': selected_indices
        }
    
    def validate_solution(self, x: np.ndarray, tolerance: float = 1e-6) -> Dict[str, bool]:
        """
        Validate that solution satisfies all constraints.
        
        Args:
            x: Binary solution
            tolerance: Numerical tolerance for constraint satisfaction
            
        Returns:
            Dictionary of constraint satisfaction flags
        """
        validation = {}
        
        # Check binary
        validation['is_binary'] = np.all(np.logical_or(x == 0, x == 1))
        
        # Check area constraint
        selected_area = sum(self.cells[self.candidate_indices[i]].area 
                          for i in range(self.n_candidates) if x[i] == 1)
        area_max = self.config.area_budget_fraction * sum(
            self.cells[idx].area for idx in self.candidate_indices
        )
        validation['satisfies_area_constraint'] = selected_area <= area_max + tolerance
        validation['area_utilization'] = selected_area / area_max
        
        # Check budget constraint
        if self.config.total_budget is not None:
            selected_cost = sum(self.cells[self.candidate_indices[i]].greening_cost
                              for i in range(self.n_candidates) if x[i] == 1)
            validation['satisfies_budget_constraint'] = (
                selected_cost <= self.config.total_budget + tolerance
            )
            validation['budget_utilization'] = selected_cost / self.config.total_budget
        
        # Overall feasibility
        validation['is_feasible'] = all([
            validation['is_binary'],
            validation['satisfies_area_constraint'],
            validation.get('satisfies_budget_constraint', True)
        ])
        
        return validation
    
    def export_problem(self) -> Dict:
        """
        Export complete problem data for serialization.
        
        Returns:
            Dictionary with all problem data
        """
        return {
            'config': self.config.__dict__,
            'n_cells': self.n_cells,
            'n_candidates': self.n_candidates,
            'candidate_indices': self.candidate_indices,
            'Q_matrix': self.Q_matrix.tolist() if self.Q_matrix is not None else None,
            'metadata': self.qubo_metadata,
            'alpha': self.alpha.tolist() if self.alpha is not None else None,
            'beta': self.beta.tolist() if self.beta is not None else None
        }
    
    def __repr__(self) -> str:
        """String representation."""
        return (f"UHIGreenLayoutProblem("
                f"grid={self.n_rows}×{self.n_cols}, "
                f"candidates={self.n_candidates}/{self.n_cells})")
