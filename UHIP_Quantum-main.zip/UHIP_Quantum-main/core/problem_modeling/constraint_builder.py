"""
Constraint Builder for UHI-QUBO Problems

Provides high-level utilities for constructing various constraint types
relevant to Urban Heat Island mitigation problems.

Constraint Categories:
1. Resource constraints (area, budget, manpower)
2. Spatial constraints (connectivity, clustering, separation)
3. Equity constraints (fairness across districts/demographics)
4. Regulatory constraints (zoning, minimum sizes)

Each constraint is converted to quadratic penalty form for QUBO embedding.

Reference: Section IV.3 (Constraint Formulation) from mathematical documents
"""

import numpy as np
from typing import List, Dict, Tuple, Optional, Set, Callable
from dataclasses import dataclass
from collections import defaultdict

from core.qubo_formulation.constraint_penalty import ConstraintPenaltyEncoder


@dataclass
class ConstraintSpec:
    """Specification for a constraint."""
    name: str
    constraint_type: str  # 'equality', 'inequality', 'spatial', 'equity'
    coefficients: np.ndarray
    target_value: Optional[float] = None
    max_value: Optional[float] = None
    min_value: Optional[float] = None
    penalty_weight: Optional[float] = None
    metadata: Dict = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class ConstraintBuilder:
    """
    Builder for UHI problem constraints.
    
    Provides methods to construct common constraint types and convert
    them to QUBO-compatible quadratic penalty forms.
    
    Usage:
        builder = ConstraintBuilder(n_variables=100)
        builder.add_area_constraint(areas, area_max)
        builder.add_connectivity_constraint(grid_graph)
        constraints = builder.get_constraints()
    """
    
    def __init__(self, n_variables: int):
        """
        Initialize constraint builder.
        
        Args:
            n_variables: Number of binary decision variables
        """
        self.n_variables = n_variables
        self.constraints: List[ConstraintSpec] = []
        
    def add_resource_constraint(self, resource_coefficients: np.ndarray,
                               resource_max: float,
                               resource_name: str = "resource",
                               constraint_type: str = "inequality"):
        """
        Add resource constraint: Σ r_i x_i ≤ R_max
        
        Generic resource constraint for area, budget, materials, labor, etc.
        
        Args:
            resource_coefficients: Resource consumption per variable r_i
            resource_max: Maximum available resource R_max
            resource_name: Name for tracking
            constraint_type: 'equality' or 'inequality'
            
        Example:
            # Water budget: each green cell needs 1000 L/day
            water_needs = np.full(n_cells, 1000.0)
            builder.add_resource_constraint(water_needs, max_water=50000, 
                                          resource_name="water")
        """
        if len(resource_coefficients) != self.n_variables:
            raise ValueError(f"Expected {self.n_variables} coefficients")
        
        constraint = ConstraintSpec(
            name=f"{resource_name}_constraint",
            constraint_type=constraint_type,
            coefficients=resource_coefficients,
            max_value=resource_max if constraint_type == 'inequality' else None,
            target_value=resource_max if constraint_type == 'equality' else None,
            metadata={'resource_type': resource_name}
        )
        
        self.constraints.append(constraint)
    
    def add_area_constraint(self, cell_areas: np.ndarray, area_max: float):
        """
        Add area constraint: Σ area_i x_i ≤ A_max
        
        Standard constraint for total green space area.
        
        Args:
            cell_areas: Area of each cell (m²)
            area_max: Maximum total green area (m²)
        """
        self.add_resource_constraint(
            cell_areas, area_max,
            resource_name="area",
            constraint_type="inequality"
        )
    
    def add_budget_constraint(self, costs: np.ndarray, budget_max: float):
        """
        Add budget constraint: Σ cost_i x_i ≤ B_max
        
        Args:
            costs: Implementation cost per cell
            budget_max: Maximum budget
        """
        self.add_resource_constraint(
            costs, budget_max,
            resource_name="budget",
            constraint_type="inequality"
        )
    
    def add_exact_count_constraint(self, target_count: int,
                                   variable_subset: Optional[List[int]] = None):
        """
        Add constraint: Σ x_i = k (select exactly k items)
        
        Args:
            target_count: Exact number of items to select
            variable_subset: Indices to consider (None = all)
            
        Example:
            # Select exactly 20 cells for pilot program
            builder.add_exact_count_constraint(target_count=20)
        """
        if variable_subset is None:
            coeffs = np.ones(self.n_variables)
            name = f"exact_count_{target_count}"
        else:
            coeffs = np.zeros(self.n_variables)
            coeffs[variable_subset] = 1.0
            name = f"exact_count_{target_count}_subset"
        
        constraint = ConstraintSpec(
            name=name,
            constraint_type='equality',
            coefficients=coeffs,
            target_value=float(target_count)
        )
        
        self.constraints.append(constraint)
    
    def add_min_count_constraint(self, min_count: int,
                                 variable_subset: Optional[List[int]] = None):
        """
        Add constraint: Σ x_i ≥ k_min (at least k items)
        
        Reformulated as equality with slack or approximate penalty.
        
        Args:
            min_count: Minimum number of items
            variable_subset: Indices to consider
        """
        # Approximate using quadratic penalty around k_min
        # For strict enforcement, would need slack variables
        if variable_subset is None:
            coeffs = np.ones(self.n_variables)
            name = f"min_count_{min_count}"
        else:
            coeffs = np.zeros(self.n_variables)
            coeffs[variable_subset] = 1.0
            name = f"min_count_{min_count}_subset"
        
        constraint = ConstraintSpec(
            name=name,
            constraint_type='equality',  # Approximate
            coefficients=coeffs,
            target_value=float(min_count),
            min_value=float(min_count),
            metadata={'approximation': 'quadratic_penalty'}
        )
        
        self.constraints.append(constraint)
    
    def add_max_count_constraint(self, max_count: int,
                                 variable_subset: Optional[List[int]] = None):
        """
        Add constraint: Σ x_i ≤ k_max (at most k items)
        
        Args:
            max_count: Maximum number of items
            variable_subset: Indices to consider
        """
        if variable_subset is None:
            coeffs = np.ones(self.n_variables)
            name = f"max_count_{max_count}"
        else:
            coeffs = np.zeros(self.n_variables)
            coeffs[variable_subset] = 1.0
            name = f"max_count_{max_count}_subset"
        
        constraint = ConstraintSpec(
            name=name,
            constraint_type='inequality',
            coefficients=coeffs,
            max_value=float(max_count)
        )
        
        self.constraints.append(constraint)
    
    def add_district_equity_constraint(self, district_assignments: List[int],
                                      min_green_per_district: int):
        """
        Add equity constraint: each district gets at least k green cells.
        
        For D districts, adds D constraints:
            Σ_{i ∈ district_d} x_i ≥ k  for d = 1, ..., D
        
        Args:
            district_assignments: District ID for each variable (length n_variables)
            min_green_per_district: Minimum green cells per district
            
        Example:
            # City has 4 districts (labeled 0, 1, 2, 3)
            districts = [0, 0, 1, 1, 2, 2, 3, 3, ...]  # one per cell
            builder.add_district_equity_constraint(districts, min_green_per_district=5)
        """
        if len(district_assignments) != self.n_variables:
            raise ValueError(f"district_assignments must have length {self.n_variables}")
        
        # Group variables by district
        district_groups = defaultdict(list)
        for var_idx, district_id in enumerate(district_assignments):
            district_groups[district_id].append(var_idx)
        
        # Add constraint for each district
        for district_id, var_indices in district_groups.items():
            coeffs = np.zeros(self.n_variables)
            coeffs[var_indices] = 1.0
            
            constraint = ConstraintSpec(
                name=f"equity_district_{district_id}",
                constraint_type='equality',  # Approximate as equality
                coefficients=coeffs,
                target_value=float(min_green_per_district),
                min_value=float(min_green_per_district),
                metadata={
                    'district_id': district_id,
                    'n_cells_in_district': len(var_indices)
                }
            )
            
            self.constraints.append(constraint)
    
    def add_proportional_allocation_constraint(self, 
                                              district_assignments: List[int],
                                              district_populations: Dict[int, float],
                                              total_green_cells: int,
                                              tolerance: float = 0.1):
        """
        Add constraint: allocate green space proportional to population.
        
        Each district d should receive:
            green_d ≈ (pop_d / total_pop) * total_green
        
        Implemented as: |Σ_{i∈d} x_i - target_d| ≤ tolerance * target_d
        
        Args:
            district_assignments: District ID per variable
            district_populations: Population per district
            total_green_cells: Total green cells to allocate
            tolerance: Relative tolerance (e.g., 0.1 = ±10%)
        """
        if len(district_assignments) != self.n_variables:
            raise ValueError(f"district_assignments must have length {self.n_variables}")
        
        total_population = sum(district_populations.values())
        
        # Group by district
        district_groups = defaultdict(list)
        for var_idx, district_id in enumerate(district_assignments):
            district_groups[district_id].append(var_idx)
        
        # Add constraint for each district
        for district_id, var_indices in district_groups.items():
            if district_id not in district_populations:
                continue
            
            pop = district_populations[district_id]
            target_green = (pop / total_population) * total_green_cells
            
            coeffs = np.zeros(self.n_variables)
            coeffs[var_indices] = 1.0
            
            constraint = ConstraintSpec(
                name=f"proportional_district_{district_id}",
                constraint_type='equality',
                coefficients=coeffs,
                target_value=target_green,
                metadata={
                    'district_id': district_id,
                    'population': pop,
                    'target_green_cells': target_green,
                    'tolerance': tolerance
                }
            )
            
            self.constraints.append(constraint)
    
    def add_connectivity_constraint(self, adjacency_matrix: np.ndarray,
                                    min_cluster_size: int = 2):
        """
        Add soft connectivity constraint: encourage spatially connected green cells.
        
        Penalizes isolated cells by rewarding adjacent selections:
            bonus = -w * Σ_{(i,j) adjacent} x_i x_j
        
        Note: This is added as a quadratic term to the objective, not a hard constraint.
        For hard connectivity, would need more complex formulation.
        
        Args:
            adjacency_matrix: Adjacency matrix (1 if cells i,j are neighbors)
            min_cluster_size: Minimum size for green clusters (soft)
        """
        if adjacency_matrix.shape != (self.n_variables, self.n_variables):
            raise ValueError(f"Adjacency matrix must be {self.n_variables}×{self.n_variables}")
        
        # Store as metadata (to be added to objective, not constraint)
        constraint = ConstraintSpec(
            name="connectivity_bonus",
            constraint_type='spatial',
            coefficients=np.zeros(self.n_variables),  # Not a linear constraint
            metadata={
                'adjacency_matrix': adjacency_matrix,
                'min_cluster_size': min_cluster_size,
                'type': 'connectivity',
                'formulation': 'quadratic_bonus'
            }
        )
        
        self.constraints.append(constraint)
    
    def add_separation_constraint(self, min_distance: float,
                                  cell_positions: np.ndarray,
                                  constraint_strength: float = 10.0):
        """
        Add separation constraint: green cells must be separated by min distance.
        
        For each pair (i,j) with distance d_ij < min_distance:
            penalize: P * x_i * x_j
        
        This discourages placing green spaces too close together.
        
        Args:
            min_distance: Minimum separation distance (meters)
            cell_positions: Positions of cells (n_variables, 2)
            constraint_strength: Penalty strength
        """
        if cell_positions.shape[0] != self.n_variables:
            raise ValueError(f"cell_positions must have {self.n_variables} rows")
        
        # Compute pairwise distances
        from scipy.spatial.distance import cdist
        dist_matrix = cdist(cell_positions, cell_positions, metric='euclidean')
        
        # Identify pairs that violate separation
        violation_matrix = (dist_matrix < min_distance).astype(float)
        np.fill_diagonal(violation_matrix, 0)  # Ignore self-interactions
        
        constraint = ConstraintSpec(
            name="separation_constraint",
            constraint_type='spatial',
            coefficients=np.zeros(self.n_variables),
            metadata={
                'min_distance': min_distance,
                'violation_matrix': violation_matrix,
                'type': 'separation',
                'constraint_strength': constraint_strength
            }
        )
        
        self.constraints.append(constraint)
    
    def add_zoning_constraint(self, zone_assignments: List[int],
                             allowed_zones: Set[int]):
        """
        Add zoning constraint: only allow green space in certain zones.
        
        Enforces: x_i = 0 for all i where zone(i) ∉ allowed_zones
        
        This is handled by fixing variables, not adding to QUBO.
        
        Args:
            zone_assignments: Zone ID for each variable
            allowed_zones: Set of zone IDs where greening is allowed
        """
        if len(zone_assignments) != self.n_variables:
            raise ValueError(f"zone_assignments must have length {self.n_variables}")
        
        prohibited_indices = [
            i for i, zone in enumerate(zone_assignments)
            if zone not in allowed_zones
        ]
        
        constraint = ConstraintSpec(
            name="zoning_constraint",
            constraint_type='binary_fixing',
            coefficients=np.zeros(self.n_variables),
            metadata={
                'prohibited_indices': prohibited_indices,
                'allowed_zones': list(allowed_zones),
                'type': 'zoning'
            }
        )
        
        self.constraints.append(constraint)
    
    def add_custom_linear_constraint(self, coefficients: np.ndarray,
                                     target: Optional[float] = None,
                                     max_value: Optional[float] = None,
                                     min_value: Optional[float] = None,
                                     name: str = "custom_constraint"):
        """
        Add custom linear constraint with arbitrary coefficients.
        
        Supports:
        - Equality: Σ c_i x_i = target
        - Upper bound: Σ c_i x_i ≤ max_value
        - Lower bound: Σ c_i x_i ≥ min_value
        
        Args:
            coefficients: Constraint coefficients c_i
            target: Target value for equality
            max_value: Upper bound for inequality
            min_value: Lower bound for inequality
            name: Constraint name
        """
        if len(coefficients) != self.n_variables:
            raise ValueError(f"Expected {self.n_variables} coefficients")
        
        if target is not None:
            constraint_type = 'equality'
        elif max_value is not None:
            constraint_type = 'inequality'
        elif min_value is not None:
            constraint_type = 'equality'  # Approximate
            target = min_value
        else:
            raise ValueError("Must specify target, max_value, or min_value")
        
        constraint = ConstraintSpec(
            name=name,
            constraint_type=constraint_type,
            coefficients=coefficients,
            target_value=target,
            max_value=max_value,
            min_value=min_value
        )
        
        self.constraints.append(constraint)
    
    def get_constraints(self) -> List[ConstraintSpec]:
        """Return list of all constraints."""
        return self.constraints.copy()
    
    def get_constraint_by_name(self, name: str) -> Optional[ConstraintSpec]:
        """Get constraint by name."""
        for constraint in self.constraints:
            if constraint.name == name:
                return constraint
        return None
    
    def get_constraints_by_type(self, constraint_type: str) -> List[ConstraintSpec]:
        """Get all constraints of a given type."""
        return [c for c in self.constraints if c.constraint_type == constraint_type]
    
    def remove_constraint(self, name: str) -> bool:
        """
        Remove constraint by name.
        
        Returns:
            True if constraint was found and removed
        """
        for i, constraint in enumerate(self.constraints):
            if constraint.name == name:
                self.constraints.pop(i)
                return True
        return False
    
    def clear_constraints(self):
        """Remove all constraints."""
        self.constraints = []
    
    def apply_constraints_to_qubo_builder(self, qubo_builder):
        """
        Apply all constraints to a QUBOMatrixBuilder.
        
        Args:
            qubo_builder: Instance of QUBOMatrixBuilder
        """
        from core.qubo_formulation.qubo_matrix_builder import QUBOMatrixBuilder
        
        if not isinstance(qubo_builder, QUBOMatrixBuilder):
            raise TypeError("qubo_builder must be a QUBOMatrixBuilder instance")
        
        for constraint in self.constraints:
            if constraint.constraint_type == 'equality':
                qubo_builder.add_equality_constraint(
                    constraint.coefficients,
                    constraint.target_value,
                    penalty_weight=constraint.penalty_weight,
                    constraint_name=constraint.name
                )
            elif constraint.constraint_type == 'inequality':
                qubo_builder.add_inequality_constraint(
                    constraint.coefficients,
                    constraint.max_value,
                    penalty_weight=constraint.penalty_weight,
                    constraint_name=constraint.name
                )
            elif constraint.constraint_type == 'spatial':
                # Spatial constraints handled separately
                # (e.g., connectivity added to physical objective)
                pass
            elif constraint.constraint_type == 'binary_fixing':
                # Binary fixing constraints handled by variable elimination
                pass
    
    def compute_penalty_matrices(self) -> List[Tuple[np.ndarray, str]]:
        """
        Compute penalty matrices for all constraints.
        
        Returns:
            List of (Q_penalty, constraint_name) tuples
        """
        penalty_matrices = []
        
        for constraint in self.constraints:
            if constraint.constraint_type == 'equality':
                Q_penalty = ConstraintPenaltyEncoder.equality_constraint_penalty(
                    constraint.coefficients,
                    constraint.target_value
                )
                penalty_matrices.append((Q_penalty, constraint.name))
                
            elif constraint.constraint_type == 'inequality':
                Q_penalty = ConstraintPenaltyEncoder.inequality_constraint_penalty_quadratic(
                    constraint.coefficients,
                    constraint.max_value
                )
                penalty_matrices.append((Q_penalty, constraint.name))
        
        return penalty_matrices
    
    def validate_solution(self, x: np.ndarray, tolerance: float = 1e-6) -> Dict[str, bool]:
        """
        Validate solution against all constraints.
        
        Args:
            x: Binary solution vector
            tolerance: Numerical tolerance
            
        Returns:
            Dictionary {constraint_name: is_satisfied}
        """
        validation = {}
        
        for constraint in self.constraints:
            if constraint.constraint_type in ['equality', 'inequality']:
                value = np.dot(constraint.coefficients, x)
                
                if constraint.constraint_type == 'equality':
                    satisfied = abs(value - constraint.target_value) <= tolerance
                    validation[constraint.name] = satisfied
                    
                elif constraint.constraint_type == 'inequality':
                    if constraint.max_value is not None:
                        satisfied = value <= constraint.max_value + tolerance
                        validation[constraint.name] = satisfied
                    if constraint.min_value is not None:
                        satisfied = value >= constraint.min_value - tolerance
                        validation[f"{constraint.name}_min"] = satisfied
        
        return validation
    
    def get_summary(self) -> Dict:
        """
        Get summary of all constraints.
        
        Returns:
            Dictionary with constraint statistics
        """
        type_counts = defaultdict(int)
        for constraint in self.constraints:
            type_counts[constraint.constraint_type] += 1
        
        return {
            'n_constraints': len(self.constraints),
            'n_variables': self.n_variables,
            'constraints_by_type': dict(type_counts),
            'constraint_names': [c.name for c in self.constraints]
        }
    
    def __repr__(self) -> str:
        """String representation."""
        return f"ConstraintBuilder(n_variables={self.n_variables}, n_constraints={len(self.constraints)})"
