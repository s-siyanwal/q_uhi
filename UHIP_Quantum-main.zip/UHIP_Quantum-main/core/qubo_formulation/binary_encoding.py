"""
Binary Variable Encoding for QUBO Problems

Mathematical Foundation:
- Binary variables: x_i ∈ {0, 1}
- QUBO form: f(x) = x^T Q x = Σ_i Q_ii x_i + Σ_{i<j} Q_ij x_i x_j

Reference: Section II (Preliminaries) from mathematical documents
"""

import numpy as np
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass


@dataclass
class BinaryVariable:
    """
    Represents a single binary decision variable.
    
    Attributes:
        index: Unique index for the variable
        name: Human-readable name
        description: Description of what the variable represents
        value: Current value (0 or 1, or None if unassigned)
    """
    index: int
    name: str
    description: str = ""
    value: Optional[int] = None
    
    def assign(self, value: int):
        """Assign a value to the variable."""
        if value not in (0, 1):
            raise ValueError(f"Binary variable must be 0 or 1, got {value}")
        self.value = value
    
    def is_assigned(self) -> bool:
        """Check if variable has been assigned."""
        return self.value is not None


class BinaryVariableSet:
    """
    Collection of binary variables with indexing and naming.
    
    Manages a set of binary variables for a QUBO problem, providing
    convenient access by index or name.
    """
    
    def __init__(self, size: int, name_prefix: str = "x"):
        """
        Initialize a set of binary variables.
        
        Args:
            size: Number of variables
            name_prefix: Prefix for variable names (default: "x")
        """
        self.size = size
        self.variables = [
            BinaryVariable(index=i, name=f"{name_prefix}_{i}")
            for i in range(size)
        ]
        self.name_to_var = {var.name: var for var in self.variables}
    
    def __len__(self) -> int:
        """Return number of variables."""
        return self.size
    
    def __getitem__(self, index: int) -> BinaryVariable:
        """Get variable by index."""
        if not 0 <= index < self.size:
            raise IndexError(f"Index {index} out of range [0, {self.size})")
        return self.variables[index]
    
    def get_by_name(self, name: str) -> BinaryVariable:
        """Get variable by name."""
        if name not in self.name_to_var:
            raise KeyError(f"Variable '{name}' not found")
        return self.name_to_var[name]
    
    def assign_values(self, values: np.ndarray):
        """
        Assign values to all variables.
        
        Args:
            values: Array of binary values
            
        Raises:
            ValueError: If values are not binary or size mismatch
        """
        if len(values) != self.size:
            raise ValueError(f"Expected {self.size} values, got {len(values)}")
        
        if not np.all(np.logical_or(values == 0, values == 1)):
            raise ValueError("All values must be 0 or 1")
        
        for i, val in enumerate(values):
            self.variables[i].assign(int(val))
    
    def get_values(self) -> np.ndarray:
        """
        Get current values of all variables.
        
        Returns:
            Array of values (or None for unassigned)
            
        Raises:
            ValueError: If any variable is unassigned
        """
        values = []
        for var in self.variables:
            if var.value is None:
                raise ValueError(f"Variable {var.name} is unassigned")
            values.append(var.value)
        return np.array(values, dtype=int)
    
    def reset(self):
        """Reset all variables to unassigned state."""
        for var in self.variables:
            var.value = None
    
    def set_description(self, index: int, description: str):
        """Set description for a variable."""
        self.variables[index].description = description


def create_binary_variable_array(size: int, name_prefix: str = "x",
                                 descriptions: Optional[List[str]] = None) -> BinaryVariableSet:
    """
    Create an array of binary variables.
    
    Args:
        size: Number of variables
        name_prefix: Prefix for variable names
        descriptions: Optional list of descriptions for each variable
        
    Returns:
        BinaryVariableSet instance
    """
    var_set = BinaryVariableSet(size, name_prefix)
    
    if descriptions is not None:
        if len(descriptions) != size:
            raise ValueError(f"Expected {size} descriptions, got {len(descriptions)}")
        for i, desc in enumerate(descriptions):
            var_set.set_description(i, desc)
    
    return var_set


def validate_binary_assignment(x: np.ndarray) -> Tuple[bool, str]:
    """
    Validate that an array contains only binary values.
    
    Mathematical verification: x_i ∈ {0, 1} for all i
    Reference: Definition II.1
    
    Args:
        x: Array to validate
        
    Returns:
        (is_valid, error_message)
    """
    if not isinstance(x, np.ndarray):
        return False, "Input must be a numpy array"
    
    if x.ndim != 1:
        return False, f"Expected 1D array, got {x.ndim}D"
    
    if not np.issubdtype(x.dtype, np.integer) and not np.issubdtype(x.dtype, np.floating):
        return False, f"Invalid dtype: {x.dtype}"
    
    # Check binary constraint
    if not np.all(np.logical_or(x == 0, x == 1)):
        invalid_indices = np.where(np.logical_and(x != 0, x != 1))[0]
        return False, f"Non-binary values at indices {invalid_indices[:5].tolist()}"
    
    return True, "Valid binary assignment"


def binary_vector_to_string(x: np.ndarray, group_size: int = 8) -> str:
    """
    Convert binary vector to human-readable string.
    
    Args:
        x: Binary vector
        group_size: Number of bits per group (for readability)
        
    Returns:
        String representation
    """
    bits = ''.join(str(int(b)) for b in x)
    
    # Group bits for readability
    if group_size > 0:
        groups = [bits[i:i+group_size] for i in range(0, len(bits), group_size)]
        return ' '.join(groups)
    
    return bits


def count_ones(x: np.ndarray) -> int:
    """
    Count number of ones in binary vector.
    
    Args:
        x: Binary vector
        
    Returns:
        Number of ones
    """
    return int(np.sum(x))


def flip_bit(x: np.ndarray, index: int) -> np.ndarray:
    """
    Flip a single bit in a binary vector (returns copy).
    
    Args:
        x: Binary vector
        index: Index of bit to flip
        
    Returns:
        New vector with bit flipped
    """
    x_new = x.copy()
    x_new[index] = 1 - x_new[index]
    return x_new


def flip_bit_inplace(x: np.ndarray, index: int):
    """
    Flip a single bit in a binary vector (in-place).
    
    Args:
        x: Binary vector (modified in-place)
        index: Index of bit to flip
    """
    x[index] = 1 - x[index]


def generate_neighborhood(x: np.ndarray, radius: int = 1) -> List[np.ndarray]:
    """
    Generate all binary vectors within Hamming distance radius.
    
    Args:
        x: Binary vector
        radius: Hamming distance radius
        
    Returns:
        List of neighbor vectors
    """
    n = len(x)
    neighbors = []
    
    if radius == 1:
        # Efficient for radius 1
        for i in range(n):
            neighbors.append(flip_bit(x, i))
    else:
        # General case (combinatorial)
        from itertools import combinations
        for r in range(1, radius + 1):
            for indices in combinations(range(n), r):
                x_neighbor = x.copy()
                for i in indices:
                    x_neighbor[i] = 1 - x_neighbor[i]
                neighbors.append(x_neighbor)
    
    return neighbors


class BinaryExpression:
    """
    Represents a mathematical expression over binary variables.
    
    Supports:
    - Linear terms: c_i * x_i
    - Quadratic terms: c_ij * x_i * x_j
    - Constant terms
    """
    
    def __init__(self, n_vars: int):
        """
        Initialize binary expression.
        
        Args:
            n_vars: Number of variables
        """
        self.n_vars = n_vars
        self.linear_coeffs = np.zeros(n_vars)
        self.quadratic_coeffs = np.zeros((n_vars, n_vars))
        self.constant = 0.0
    
    def add_linear_term(self, var_index: int, coefficient: float):
        """Add a linear term: coefficient * x_i"""
        self.linear_coeffs[var_index] += coefficient
    
    def add_quadratic_term(self, var_i: int, var_j: int, coefficient: float):
        """Add a quadratic term: coefficient * x_i * x_j"""
        self.quadratic_coeffs[var_i, var_j] += coefficient
        if var_i != var_j:
            self.quadratic_coeffs[var_j, var_i] += coefficient
    
    def add_constant(self, value: float):
        """Add a constant term."""
        self.constant += value
    
    def evaluate(self, x: np.ndarray) -> float:
        """
        Evaluate expression at binary vector x.
        
        Args:
            x: Binary vector
            
        Returns:
            Expression value
        """
        value = self.constant
        value += np.dot(self.linear_coeffs, x)
        value += x.T @ self.quadratic_coeffs @ x
        return float(value)
    
    def to_qubo_matrix(self) -> np.ndarray:
        """
        Convert expression to QUBO matrix Q.
        
        The QUBO matrix combines linear and quadratic terms:
        - Diagonal: linear coefficients
        - Off-diagonal: quadratic coefficients
        
        Returns:
            Symmetric QUBO matrix
        """
        Q = self.quadratic_coeffs.copy()
        np.fill_diagonal(Q, Q.diagonal() + self.linear_coeffs)
        
        # Ensure symmetry
        Q = (Q + Q.T) / 2
        
        return Q
