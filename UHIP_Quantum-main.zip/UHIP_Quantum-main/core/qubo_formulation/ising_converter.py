"""
QUBO to Ising Hamiltonian Conversion

Implements conversion between QUBO (binary) and Ising (spin) formulations.

Mathematical Transformation:
- QUBO variables: x_i ∈ {0, 1}
- Ising spins: s_i ∈ {-1, +1}
- Conversion: x_i = (1 + s_i) / 2  ⟺  s_i = 2x_i - 1

QUBO Energy:     E_QUBO(x) = x^T Q x
Ising Energy:    E_Ising(s) = -Σ h_i s_i - Σ_{i<j} J_ij s_i s_j + constant

Reference: Section II.2 (QUBO-Ising Equivalence) from mathematical documents
"""

import numpy as np
from typing import Tuple, Dict, Optional
from dataclasses import dataclass


@dataclass
class IsingModel:
    """
    Ising Hamiltonian representation.
    
    H = -Σ h_i s_i - Σ_{i<j} J_ij s_i s_j
    
    Attributes:
        h: Linear fields (local magnetic fields)
        J: Coupling matrix (interaction strengths)
        offset: Constant energy offset
        n: Number of spins
    """
    h: np.ndarray  # Shape (n,)
    J: np.ndarray  # Shape (n, n), symmetric
    offset: float
    n: int
    
    def __post_init__(self):
        """Validate Ising model parameters."""
        if len(self.h) != self.n:
            raise ValueError(f"h must have length {self.n}, got {len(self.h)}")
        if self.J.shape != (self.n, self.n):
            raise ValueError(f"J must be {self.n}x{self.n}, got {self.J.shape}")
        if not np.allclose(self.J, self.J.T):
            raise ValueError("J must be symmetric")
    
    def energy(self, spins: np.ndarray) -> float:
        """
        Compute Ising energy for spin configuration.
        
        H(s) = -Σ h_i s_i - Σ_{i<j} J_ij s_i s_j
        
        Args:
            spins: Spin configuration s ∈ {-1, +1}^n
            
        Returns:
            Energy value
        """
        if not np.all(np.logical_or(spins == -1, spins == 1)):
            raise ValueError("Spins must be ±1")
        
        # Linear term
        linear_energy = -np.dot(self.h, spins)
        
        # Quadratic term: -Σ_{i<j} J_ij s_i s_j
        # Since J is symmetric with zeros on diagonal, we can use:
        # -0.5 * s^T J s (the 0.5 accounts for double counting)
        quadratic_energy = -0.5 * spins.T @ self.J @ spins
        
        return linear_energy + quadratic_energy + self.offset


class IsingConverter:
    """
    Bidirectional converter between QUBO and Ising formulations.
    
    Theoretical Foundation:
    The transformation x_i = (1 + s_i)/2 establishes equivalence:
    
    Starting from QUBO: E(x) = Σ_i Σ_j Q_ij x_i x_j
    
    Substitute x_i = (1 + s_i)/2, x_j = (1 + s_j)/2:
    E(s) = Σ_i Σ_j Q_ij * (1 + s_i)/2 * (1 + s_j)/2
         = (1/4) Σ_i Σ_j Q_ij (1 + s_i + s_j + s_i s_j)
    
    Collecting terms:
    - Constant: (1/4) Σ_i Σ_j Q_ij
    - Linear in s_i: (1/4) Σ_j (Q_ij + Q_ji) + (1/4) Q_ii
    - Quadratic s_i s_j: (1/4) Q_ij  (for i ≠ j)
    
    Ising form: H = -Σ h_i s_i - Σ_{i<j} J_ij s_i s_j + offset
    
    Therefore:
    - h_i = -(1/4) [Q_ii + Σ_j(Q_ij + Q_ji)]
    - J_ij = -Q_ij/4  (for i < j)
    - offset = (1/4) Σ_i Σ_j Q_ij
    
    Reference: Theorem II.1 (QUBO-Ising Equivalence)
    """
    
    @staticmethod
    def qubo_to_ising(Q: np.ndarray) -> IsingModel:
        """
        Convert QUBO matrix to Ising Hamiltonian.
        
        Mathematical transformation:
        Given QUBO: E(x) = x^T Q x where x ∈ {0,1}^n
        Compute Ising: H(s) = -Σ h_i s_i - Σ_{i<j} J_ij s_i s_j + c
        
        Formulas:
        - h_i = -1/4 * [Q_ii + Σ_j Q_ij + Σ_j Q_ji]
        - J_ij = -1/4 * (Q_ij + Q_ji) for i < j
        - offset = 1/4 * Σ_i Σ_j Q_ij
        
        Args:
            Q: QUBO matrix (n × n, should be symmetric)
            
        Returns:
            IsingModel with equivalent energy landscape
            
        Example:
            >>> Q = np.array([[1, 2], [2, 3]])
            >>> ising = IsingConverter.qubo_to_ising(Q)
            >>> # Verify: E_QUBO([0,1]) == E_Ising([-1,1])
        """
        n = Q.shape[0]
        
        if Q.shape[0] != Q.shape[1]:
            raise ValueError(f"Q must be square, got shape {Q.shape}")
        
        # Ensure Q is symmetric (average if not exactly symmetric)
        if not np.allclose(Q, Q.T):
            Q = (Q + Q.T) / 2
        
        # Derive Ising parameters from QUBO
        # IMPORTANT: x^T Q x = Σ_i Σ_j Q_ij x_i x_j counts each off-diagonal pair TWICE for symmetric Q
        # So the effective energy is: Σ_i Q_ii x_i + 2*Σ_{i<j} Q_ij x_i x_j
        
        # Substitute x_i = (1 + s_i)/2:
        # For diagonal terms: Q_ii x_i = Q_ii (1+s_i)/2 = Q_ii/2 + Q_ii s_i/2
        # For off-diagonal i<j: 2*Q_ij x_i x_j = 2*Q_ij (1+s_i)/2 (1+s_j)/2
        #                                       = Q_ij/2 (1 + s_i + s_j + s_i s_j)
        
        # Collecting terms:
        # Constant: Σ_i Q_ii/2 + Σ_{i<j} Q_ij/2 = (1/2) Σ_i Q_ii + (1/2) Σ_{i<j} Q_ij
        # Linear s_i: Σ_i Q_ii/2 + Σ_{j>i} Q_ij/2 + Σ_{j<i} Q_ij/2 = (1/2)[Q_ii + Σ_j Q_ij]
        # Quadratic s_i s_j: Q_ij/2 for i<j
        
        # Actually, let me use a simpler approach:
        # For symmetric Q, extract upper triangle only and work with that
        
        h = np.zeros(n)
        J = np.zeros((n, n))
        offset = 0.0
        
        for i in range(n):
            # Diagonal contribution: Q_ii x_i = Q_ii (1+s_i)/2
            offset += Q[i,i] / 2
            h[i] += Q[i,i] / 2
            
            for j in range(i+1, n):
                # Off-diagonal contribution: (Q_ij + Q_ji) x_i x_j
                coeff = Q[i,j] + Q[j,i]  # = 2*Q_ij for symmetric
                # = coeff * (1+s_i)/2 * (1+s_j)/2 = (coeff/4)(1 + s_i + s_j + s_i s_j)
                offset += coeff / 4
                h[i] += coeff / 4
                h[j] += coeff / 4
                J[i,j] += coeff / 4
                J[j,i] += coeff / 4
        
        # Convert to standard Ising convention: H = -Σ h_i s_i - Σ_{i<j} J_ij s_i s_j
        # Our expansion gives: E = offset + Σ h_i s_i + Σ_{i<j} J_ij s_i s_j
        # So we need to negate h and J:
        h = -h
        J = -J
        
        return IsingModel(h=h, J=J, offset=offset, n=n)
    
    @staticmethod
    def ising_to_qubo(h: np.ndarray, J: np.ndarray, 
                     offset: Optional[float] = None) -> np.ndarray:
        """
        Convert Ising Hamiltonian to QUBO matrix.
        
        Inverse transformation: s_i = 2x_i - 1
        
        Starting from Ising: H(s) = -Σ h_i s_i - Σ_{i<j} J_ij s_i s_j
        Substitute s_i = 2x_i - 1:
        
        -h_i s_i = -h_i(2x_i - 1) = -2h_i x_i + h_i
        -J_ij s_i s_j = -J_ij(2x_i - 1)(2x_j - 1)
                      = -J_ij(4x_i x_j - 2x_i - 2x_j + 1)
                      = -4J_ij x_i x_j + 2J_ij x_i + 2J_ij x_j - J_ij
        
        Collecting into QUBO form x^T Q x:
        - Q_ii = -2h_i + 2Σ_{j≠i} J_ij
        - Q_ij = -4J_ij  (for i ≠ j)
        
        Args:
            h: Linear fields (n,)
            J: Coupling matrix (n, n, symmetric)
            offset: Constant offset (returned separately if needed)
            
        Returns:
            Q: QUBO matrix (n × n, symmetric)
            
        Note: The offset changes but relative energies are preserved.
        """
        n = len(h)
        
        if J.shape != (n, n):
            raise ValueError(f"J must be {n}×{n}, got {J.shape}")
        
        # Ensure J is symmetric
        if not np.allclose(J, J.T):
            J = (J + J.T) / 2
        
        Q = np.zeros((n, n))
        
        # Diagonal terms: Q_ii = -2h_i + 2Σ_{j≠i} J_ij
        for i in range(n):
            interaction_sum = np.sum(J[i, :]) - J[i, i]  # Sum over j≠i
            Q[i, i] = -2 * h[i] + 2 * interaction_sum
        
        # Off-diagonal terms: Q_ij = -4J_ij
        for i in range(n):
            for j in range(i+1, n):
                Q[i, j] = -4 * J[i, j]
                Q[j, i] = Q[i, j]  # Symmetric
        
        return Q
    
    @staticmethod
    def binary_to_spin(x: np.ndarray) -> np.ndarray:
        """
        Convert binary vector to spin vector.
        
        Transformation: s_i = 2x_i - 1
        Maps: 0 → -1, 1 → +1
        
        Args:
            x: Binary vector {0, 1}^n
            
        Returns:
            s: Spin vector {-1, +1}^n
        """
        if not np.all(np.logical_or(x == 0, x == 1)):
            raise ValueError("x must be binary (0 or 1)")
        
        return 2 * x - 1
    
    @staticmethod
    def spin_to_binary(s: np.ndarray) -> np.ndarray:
        """
        Convert spin vector to binary vector.
        
        Transformation: x_i = (1 + s_i) / 2
        Maps: -1 → 0, +1 → 1
        
        Args:
            s: Spin vector {-1, +1}^n
            
        Returns:
            x: Binary vector {0, 1}^n
        """
        if not np.all(np.logical_or(s == -1, s == 1)):
            raise ValueError("s must be spin (±1)")
        
        return ((s + 1) // 2).astype(int)
    
    @staticmethod
    def verify_equivalence(Q: np.ndarray, ising: IsingModel, 
                          n_random_tests: int = 100,
                          tolerance: float = 1e-10) -> Tuple[bool, str]:
        """
        Verify that QUBO and Ising formulations are equivalent.
        
        Tests energy equality: E_QUBO(x) = E_Ising(2x - 1) for random x
        
        Args:
            Q: QUBO matrix
            ising: Ising model
            n_random_tests: Number of random configurations to test
            tolerance: Numerical tolerance for equality
            
        Returns:
            (is_equivalent, message)
            
        Mathematical check:
        For all x ∈ {0,1}^n and corresponding s = 2x - 1 ∈ {-1,+1}^n:
            x^T Q x = H(s) - offset
        """
        n = Q.shape[0]
        
        if ising.n != n:
            return False, f"Dimension mismatch: Q is {n}×{n}, Ising has {ising.n} spins"
        
        max_diff = 0.0
        
        for _ in range(n_random_tests):
            # Random binary configuration
            x = np.random.randint(0, 2, n)
            s = IsingConverter.binary_to_spin(x)
            
            # QUBO energy
            E_qubo = x.T @ Q @ x
            
            # Ising energy (already includes offset)
            E_ising = ising.energy(s)
            
            # They should match directly
            diff = abs(E_qubo - E_ising)
            max_diff = max(max_diff, diff)
            
            if diff > tolerance:
                return False, (f"Energy mismatch at x={x}: "
                             f"E_QUBO={E_qubo:.6f}, E_Ising={E_ising:.6f}, "
                             f"diff={diff:.2e}")
        
        return True, f"Verified equivalent on {n_random_tests} tests (max diff: {max_diff:.2e})"
    
    @staticmethod
    def extract_field_and_couplings(Q: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Extract diagonal (field) and off-diagonal (coupling) parts.
        
        Useful for separate analysis of linear and quadratic terms.
        
        For QUBO: E(x) = Σ Q_ii x_i + Σ_{i<j} (Q_ij + Q_ji) x_i x_j
        
        Args:
            Q: QUBO matrix
            
        Returns:
            (h_qubo, J_qubo):
            - h_qubo: Diagonal elements (linear terms)
            - J_qubo: Upper triangular (interaction terms)
        """
        h_qubo = np.diag(Q).copy()
        J_qubo = np.triu(Q, k=1).copy()
        
        return h_qubo, J_qubo
    
    @staticmethod
    def get_coupling_statistics(J: np.ndarray) -> Dict[str, float]:
        """
        Compute statistics about Ising couplings.
        
        Useful for understanding problem structure and hardness.
        
        Args:
            J: Coupling matrix
            
        Returns:
            Statistics dictionary
        """
        # Extract upper triangle (avoid double counting)
        J_upper = np.triu(J, k=1)
        couplings = J_upper[J_upper != 0]
        
        if len(couplings) == 0:
            return {
                'n_couplings': 0,
                'mean_coupling': 0.0,
                'std_coupling': 0.0,
                'max_coupling': 0.0,
                'min_coupling': 0.0,
                'ferromagnetic_fraction': 0.0,
            }
        
        n_ferromagnetic = np.sum(couplings > 0)  # J > 0 favors alignment
        n_antiferromagnetic = np.sum(couplings < 0)
        
        return {
            'n_couplings': len(couplings),
            'mean_coupling': float(np.mean(np.abs(couplings))),
            'std_coupling': float(np.std(couplings)),
            'max_coupling': float(np.max(np.abs(couplings))),
            'min_coupling': float(np.min(np.abs(couplings[couplings != 0]))),
            'ferromagnetic_fraction': n_ferromagnetic / len(couplings),
            'antiferromagnetic_fraction': n_antiferromagnetic / len(couplings),
            'frustration_indicator': float(np.sum(couplings < 0) / len(couplings)),
        }
    
    @staticmethod
    def create_ising_dict(h: np.ndarray, J: np.ndarray, 
                         threshold: float = 1e-12) -> Dict:
        """
        Create dictionary representation of Ising model.
        
        Format compatible with D-Wave Ocean SDK and other libraries.
        
        Args:
            h: Linear fields
            J: Coupling matrix
            threshold: Ignore values below this
            
        Returns:
            Dictionary with:
            - 'linear': {i: h_i} for non-zero h_i
            - 'quadratic': {(i, j): J_ij} for i < j, non-zero J_ij
        """
        n = len(h)
        
        linear_dict = {}
        for i in range(n):
            if abs(h[i]) > threshold:
                linear_dict[i] = float(h[i])
        
        quadratic_dict = {}
        for i in range(n):
            for j in range(i+1, n):
                if abs(J[i, j]) > threshold:
                    quadratic_dict[(i, j)] = float(J[i, j])
        
        return {
            'linear': linear_dict,
            'quadratic': quadratic_dict
        }


def demonstrate_conversion():
    """
    Demonstration of QUBO-Ising conversion with example.
    
    Example from document:
    Simple 2-variable QUBO: minimize x₁ + 3x₂ - 2x₁x₂
    """
    # QUBO matrix for f(x) = x₁ + 3x₂ - 2x₁x₂
    # Q = [[1, -1], [-1, 3]]  (symmetric form with off-diagonal /2)
    Q = np.array([[1, -1], 
                  [-1, 3]], dtype=float)
    
    print("Original QUBO matrix:")
    print(Q)
    print()
    
    # Convert to Ising
    ising = IsingConverter.qubo_to_ising(Q)
    print("Ising Hamiltonian:")
    print(f"h = {ising.h}")
    print(f"J = \n{ising.J}")
    print(f"offset = {ising.offset}")
    print()
    
    # Verify equivalence
    is_equiv, msg = IsingConverter.verify_equivalence(Q, ising)
    print(f"Equivalence check: {msg}")
    print()
    
    # Test on specific configurations
    print("Energy comparison for all configurations:")
    for x1 in [0, 1]:
        for x2 in [0, 1]:
            x = np.array([x1, x2])
            s = IsingConverter.binary_to_spin(x)
            
            E_qubo = x.T @ Q @ x
            E_ising = ising.energy(s)
            
            print(f"x={x}, s={s}: E_QUBO={E_qubo:.4f}, "
                  f"E_Ising={E_ising:.4f} (offset: {ising.offset:.4f})")


if __name__ == "__main__":
    demonstrate_conversion()
