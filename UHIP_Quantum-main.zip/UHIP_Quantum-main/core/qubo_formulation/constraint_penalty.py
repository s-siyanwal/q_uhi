"""
Constraint Penalty Encoding for QUBO

Implements penalty methods for embedding constraints into QUBO formulations.

Mathematical Framework:
- Equality: g(x) = 0 → add P·(g(x))²
- Inequality: g(x) ≤ 0 → introduce penalty
- Penalty weight must satisfy Theorem IV.1 for exactness

Reference: Section IV.1 (Quadratic penalty embedding) from mathematical documents
"""

import numpy as np
from typing import Tuple, Optional, Callable


class ConstraintPenaltyEncoder:
    """
    Implements penalty method for constraint embedding into QUBO.
    
    Mathematical Basis:
    For a constraint g(x) = 0, we add penalty P·(g(x))²
    For inequality h(x) ≤ 0, we use max(0, h(x))² or slack variables
    
    Theorem IV.1: If P > range(f_physical), then the optimal solution
    of the penalized problem satisfies all constraints.
    """
    
    @staticmethod
    def equality_constraint_penalty(constraint_coeffs: np.ndarray,
                                    target_value: float) -> np.ndarray:
        """
        Convert equality constraint Σ c_i x_i = T into quadratic penalty.
        
        Constraint: Σ_i c_i x_i = T
        Penalty: (Σ_i c_i x_i - T)²
        
        Expanding: (Σ_i c_i x_i - T)² = Σ_i Σ_j c_i c_j x_i x_j - 2T Σ_i c_i x_i + T²
        
        The quadratic form x^T Q_penalty x has:
        - Q_ij = c_i * c_j for i < j
        - Q_ii = c_i² - 2T c_i (includes linear term on diagonal)
        
        Args:
            constraint_coeffs: Coefficients c_i
            target_value: Target value T
            
        Returns:
            Q_penalty matrix (symmetric)
            
        Reference: Section IV.2 (Constraint quadratization)
        """
        n = len(constraint_coeffs)
        Q_penalty = np.outer(constraint_coeffs, constraint_coeffs)
        
        # Add linear term to diagonal
        # Note: For binary x_i, x_i² = x_i, so linear terms go on diagonal
        linear_term = -2 * target_value * constraint_coeffs
        Q_penalty[np.diag_indices(n)] += linear_term
        
        return Q_penalty
    
    @staticmethod
    def inequality_constraint_penalty_quadratic(constraint_coeffs: np.ndarray,
                                               max_value: float) -> np.ndarray:
        """
        Convert inequality constraint Σ c_i x_i ≤ A_max into quadratic penalty.
        
        This uses exponential penalty that becomes quadratic for violations:
        Penalty = max(0, Σ c_i x_i - A_max)²
        
        For QUBO, we approximate by always applying penalty:
        (Σ c_i x_i - A_max)² with appropriate weight scaling
        
        Args:
            constraint_coeffs: Coefficients c_i (typically all positive)
            max_value: Maximum allowed value A_max
            
        Returns:
            Q_penalty matrix
            
        Note: This is exact only if the optimal solution would satisfy the constraint.
        For strict enforcement, may need slack variables or iterative penalty adjustment.
        """
        # Similar to equality, but with one-sided interpretation
        return ConstraintPenaltyEncoder.equality_constraint_penalty(
            constraint_coeffs, max_value
        )
    
    @staticmethod
    def cardinality_constraint_penalty(n_vars: int, target_count: int) -> np.ndarray:
        """
        Create penalty for cardinality constraint: Σ x_i = k
        
        This is a special case of equality constraint where all coefficients are 1.
        
        Penalty: (Σ_i x_i - k)²
        
        Args:
            n_vars: Number of variables
            target_count: Desired count k
            
        Returns:
            Q_penalty matrix
            
        Example: For "select exactly 5 out of 10", use target_count=5
        """
        coeffs = np.ones(n_vars)
        return ConstraintPenaltyEncoder.equality_constraint_penalty(coeffs, target_count)
    
    @staticmethod
    def at_most_k_constraint_penalty(n_vars: int, max_count: int) -> np.ndarray:
        """
        Create penalty for "at most k" constraint: Σ x_i ≤ k
        
        Args:
            n_vars: Number of variables
            max_count: Maximum count k
            
        Returns:
            Q_penalty matrix
        """
        coeffs = np.ones(n_vars)
        return ConstraintPenaltyEncoder.inequality_constraint_penalty_quadratic(
            coeffs, max_count
        )
    
    @staticmethod
    def at_least_k_constraint_penalty(n_vars: int, min_count: int) -> np.ndarray:
        """
        Create penalty for "at least k" constraint: Σ x_i ≥ k
        
        Reformulated as: -Σ x_i ≤ -k or equivalently Σ(1-x_i) ≤ (n-k)
        
        Args:
            n_vars: Number of variables
            min_count: Minimum count k
            
        Returns:
            Q_penalty matrix
        """
        # Σ x_i ≥ k  ⟺  n - Σ x_i ≤ n - k  ⟺  Σ (1 - x_i) ≤ n - k
        # But (1-x_i) needs reformulation for binary...
        # Simpler: penalty = max(0, k - Σ x_i)² ≈ (Σ x_i - k)² with opposite sign consideration
        
        # We use: (Σ x_i - k)² which penalizes both over and under
        # For "at least", we actually want: max(0, k - Σ x_i)²
        # In QUBO context, we use the quadratic form directly
        coeffs = np.ones(n_vars)
        return ConstraintPenaltyEncoder.equality_constraint_penalty(coeffs, min_count)
    
    @staticmethod
    def one_hot_constraint_penalty(group_size: int) -> np.ndarray:
        """
        Create penalty for one-hot encoding: exactly one of the group is 1.
        
        This enforces Σ_i x_i = 1 for a group of variables.
        
        Args:
            group_size: Number of variables in the group
            
        Returns:
            Q_penalty matrix
            
        Example: For selecting one option among three, use group_size=3
        """
        return ConstraintPenaltyEncoder.cardinality_constraint_penalty(group_size, 1)
    
    @staticmethod
    def calculate_sufficient_penalty_weight(Q_physical: np.ndarray,
                                           n_constraints: int = 1,
                                           safety_factor: float = 2.0) -> float:
        """
        Calculate penalty weight satisfying Theorem IV.1.
        
        Theorem IV.1 states: If P > range(f_physical), then optimal solution
        of penalized problem will be feasible.
        
        We estimate the range using eigenvalue bounds and add safety factor.
        
        Args:
            Q_physical: Physical objective QUBO matrix
            n_constraints: Number of constraints (for scaling)
            safety_factor: Multiplicative safety factor (default: 2.0)
            
        Returns:
            Penalty weight P
            
        Mathematical justification:
        - E(x) = x^T Q x for binary x
        - max E ≈ Σ max(λ_i, 0) where λ_i are eigenvalues
        - min E ≈ Σ min(λ_i, 0)
        - range ≈ max E - min E
        """
        if Q_physical.size == 0:
            return 1.0
        
        # Compute eigenvalues
        eigenvalues = np.linalg.eigvalsh(Q_physical)
        
        # Estimate max and min energies
        e_max_estimate = np.sum(np.maximum(eigenvalues, 0))
        e_min_estimate = np.sum(np.minimum(eigenvalues, 0))
        
        energy_range = e_max_estimate - e_min_estimate
        
        # Add safety factor and scale by number of constraints
        penalty_weight = safety_factor * energy_range
        
        # Ensure minimum penalty weight
        penalty_weight = max(penalty_weight, 10.0)
        
        return penalty_weight
    
    @staticmethod
    def verify_penalty_sufficiency(Q_physical: np.ndarray, penalty_weight: float,
                                   Q_penalty: np.ndarray,
                                   tolerance: float = 0.1) -> Tuple[bool, str]:
        """
        Verify that penalty weight is sufficient for constraint enforcement.
        
        Checks if P > range(f_physical) as required by Theorem IV.1
        
        Args:
            Q_physical: Physical objective matrix
            penalty_weight: Proposed penalty weight
            Q_penalty: Penalty matrix
            tolerance: Relative tolerance for sufficiency
            
        Returns:
            (is_sufficient, message)
        """
        # Estimate energy range
        eigenvalues = np.linalg.eigvalsh(Q_physical)
        e_max = np.sum(np.maximum(eigenvalues, 0))
        e_min = np.sum(np.minimum(eigenvalues, 0))
        energy_range = e_max - e_min
        
        required_penalty = energy_range * (1 + tolerance)
        
        if penalty_weight >= required_penalty:
            return True, f"Penalty {penalty_weight:.2f} > range {energy_range:.2f} ✓"
        else:
            return False, f"Penalty {penalty_weight:.2f} < required {required_penalty:.2f} ✗"
    
    @staticmethod
    def combine_penalties(penalty_matrices: list, weights: Optional[list] = None) -> np.ndarray:
        """
        Combine multiple penalty matrices with optional different weights.
        
        Args:
            penalty_matrices: List of penalty matrices
            weights: List of weights for each penalty (default: all 1.0)
            
        Returns:
            Combined penalty matrix
        """
        if not penalty_matrices:
            raise ValueError("No penalty matrices provided")
        
        if weights is None:
            weights = [1.0] * len(penalty_matrices)
        
        if len(weights) != len(penalty_matrices):
            raise ValueError("Number of weights must match number of matrices")
        
        # Check all matrices have same shape
        shape = penalty_matrices[0].shape
        for mat in penalty_matrices:
            if mat.shape != shape:
                raise ValueError(f"All matrices must have same shape, got {mat.shape} vs {shape}")
        
        # Combine
        Q_combined = np.zeros(shape)
        for weight, mat in zip(weights, penalty_matrices):
            Q_combined += weight * mat
        
        return Q_combined
    
    @staticmethod
    def evaluate_constraint_violation(x: np.ndarray, constraint_coeffs: np.ndarray,
                                     target_value: float) -> float:
        """
        Evaluate constraint violation for equality constraint.
        
        Args:
            x: Binary solution vector
            constraint_coeffs: Constraint coefficients
            target_value: Target value
            
        Returns:
            Violation amount (0 if satisfied)
        """
        constraint_value = np.dot(constraint_coeffs, x)
        violation = constraint_value - target_value
        return float(violation)
    
    @staticmethod
    def check_constraint_satisfaction(x: np.ndarray, constraint_coeffs: np.ndarray,
                                     target_value: float, tolerance: float = 1e-6) -> bool:
        """
        Check if constraint is satisfied.
        
        Args:
            x: Binary solution vector
            constraint_coeffs: Constraint coefficients
            target_value: Target value
            tolerance: Numerical tolerance
            
        Returns:
            True if constraint is satisfied
        """
        violation = abs(ConstraintPenaltyEncoder.evaluate_constraint_violation(
            x, constraint_coeffs, target_value
        ))
        return violation <= tolerance
