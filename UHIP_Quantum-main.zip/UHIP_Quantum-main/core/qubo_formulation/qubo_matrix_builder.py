"""
QUBO Matrix Builder for UHI Green Space Layout Problems

This module implements the main QUBO matrix construction class that combines
physical UHI cooling terms with constraint penalty terms.

Mathematical Framework:
- QUBO objective: f(x) = x^T Q x where x ∈ {0,1}^n
- Q = Q_physical + Σ_i P_i * Q_constraint_i
- Q_physical: UHI cooling interactions and linear benefits
- Q_constraint: Quadratic penalty embedding of constraints

Reference: Section IV (Problem Formulation and QUBO Embedding) from mathematical documents
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from core.utils.math_helpers import ensure_symmetric, calculate_energy_from_qubo
from core.utils.matrix_operations import verify_qubo_matrix, compute_qubo_statistics
from core.qubo_formulation.constraint_penalty import ConstraintPenaltyEncoder


@dataclass
class QUBOBuildConfig:
    """Configuration for QUBO matrix construction."""
    n_variables: int
    auto_penalty_weight: bool = True
    penalty_weight: float = 10.0
    penalty_safety_factor: float = 2.0
    enforce_symmetry: bool = True
    verify_construction: bool = True


class QUBOMatrixBuilder:
    """
    Constructs QUBO matrices for UHI-Green-Layout problems.
    
    The builder combines:
    1. Physical objective terms (UHI cooling model)
    2. Constraint penalty terms (area, budget, equity constraints)
    3. Optional regularization terms
    
    Mathematical Basis:
    The complete QUBO formulation is:
        min f(x) = f_physical(x) + Σ P_i * penalty_i(x)
        
    where:
    - f_physical(x) = Σ α_i x_i + Σ β_ij x_i x_j (UHI cooling)
    - penalty_i(x) = (g_i(x))² for constraint g_i(x) = 0
    
    Theorem IV.1 (Exactness): If P_i > range(f_physical), then the optimal
    solution to the penalized problem is feasible and optimal for the
    constrained problem.
    
    Reference: Section IV.1 (Quadratic Penalty Method)
    """
    
    def __init__(self, config: QUBOBuildConfig):
        """
        Initialize QUBO matrix builder.
        
        Args:
            config: Configuration for matrix construction
        """
        self.config = config
        self.n = config.n_variables
        
        # Initialize matrices
        self.Q_physical = np.zeros((self.n, self.n))
        self.Q_total = np.zeros((self.n, self.n))
        
        # Track constraint penalties
        self.constraint_matrices = []
        self.penalty_weights = []
        self.constraint_metadata = []
        
        # Statistics
        self.statistics = {}
        
    def add_linear_terms(self, coefficients: np.ndarray):
        """
        Add linear terms to QUBO (appear on diagonal).
        
        For QUBO formulation: Σ c_i x_i contributes c_i to Q_ii
        This uses the property that x_i² = x_i for binary variables.
        
        Mathematical basis: f(x) = Σ c_i x_i = Σ c_i x_i² = x^T diag(c) x
        
        Args:
            coefficients: Linear coefficients c_i for each variable
            
        Raises:
            ValueError: If coefficient size doesn't match n_variables
        """
        if len(coefficients) != self.n:
            raise ValueError(f"Expected {self.n} coefficients, got {len(coefficients)}")
        
        np.fill_diagonal(self.Q_physical, np.diag(self.Q_physical) + coefficients)
    
    def add_quadratic_terms(self, interaction_matrix: np.ndarray):
        """
        Add quadratic interaction terms to QUBO.
        
        For symmetric matrix β: Σ_i Σ_j β_ij x_i x_j
        
        Mathematical note: Since x_i x_j = x_j x_i for binary variables,
        we enforce symmetry: Q_ij = Q_ji = (β_ij + β_ji)/2
        
        Args:
            interaction_matrix: Quadratic interaction coefficients β_ij
            
        Raises:
            ValueError: If matrix is not square or size mismatch
        """
        if interaction_matrix.shape != (self.n, self.n):
            raise ValueError(f"Expected {(self.n, self.n)} matrix, got {interaction_matrix.shape}")
        
        # Ensure symmetry
        beta_symmetric = ensure_symmetric(interaction_matrix)
        
        # Add to physical matrix
        self.Q_physical += beta_symmetric
    
    def add_physical_objective(self, linear_coeffs: np.ndarray, 
                               quadratic_coeffs: np.ndarray):
        """
        Add complete physical objective for UHI cooling.
        
        Physical model: ΔI_UHI(x) = Σ α_i x_i + Σ β_ij x_i x_j
        
        where:
        - α_i: Direct cooling benefit of greening cell i
        - β_ij: Interaction effect between cells i and j
        
        Mathematical properties:
        - β_ij typically negative (synergistic cooling)
        - β_ii = 0 (no self-interaction, absorbed in α_i)
        - Spatial decay: |β_ij| decreases with distance ||r_i - r_j||
        
        Args:
            linear_coeffs: α coefficients (length n)
            quadratic_coeffs: β matrix (n × n, symmetric)
            
        Reference: Section V.1 (UHI Cooling Model)
        """
        self.add_linear_terms(linear_coeffs)
        self.add_quadratic_terms(quadratic_coeffs)
    
    def add_equality_constraint(self, constraint_coeffs: np.ndarray, 
                               target_value: float,
                               penalty_weight: Optional[float] = None,
                               constraint_name: str = "equality_constraint"):
        """
        Add equality constraint: Σ c_i x_i = T
        
        Converted to quadratic penalty: P * (Σ c_i x_i - T)²
        
        Expansion:
        (Σ c_i x_i - T)² = Σ_i Σ_j c_i c_j x_i x_j - 2T Σ_i c_i x_i + T²
        
        The QUBO form x^T Q x absorbs the linear term into diagonal:
        - Q_ij += P * c_i * c_j  (for i ≠ j)
        - Q_ii += P * (c_i² - 2T c_i)
        
        The constant T² is dropped (doesn't affect optimization).
        
        Args:
            constraint_coeffs: Coefficients c_i
            target_value: Target value T
            penalty_weight: Penalty coefficient P (auto-computed if None)
            constraint_name: Name for tracking
            
        Reference: Section IV.2 (Constraint Quadratization)
        """
        if len(constraint_coeffs) != self.n:
            raise ValueError(f"Expected {self.n} coefficients, got {len(constraint_coeffs)}")
        
        # Compute penalty matrix
        Q_penalty = ConstraintPenaltyEncoder.equality_constraint_penalty(
            constraint_coeffs, target_value
        )
        
        # Determine penalty weight
        if penalty_weight is None:
            penalty_weight = self._compute_auto_penalty_weight()
        
        # Store for tracking
        self.constraint_matrices.append(Q_penalty)
        self.penalty_weights.append(penalty_weight)
        self.constraint_metadata.append({
            'type': 'equality',
            'name': constraint_name,
            'coeffs': constraint_coeffs,
            'target': target_value,
            'penalty_weight': penalty_weight
        })
        
        # Add to total QUBO
        self.Q_total = self.Q_physical.copy()
        for Q_c, P_c in zip(self.constraint_matrices, self.penalty_weights):
            self.Q_total += P_c * Q_c
    
    def add_inequality_constraint(self, constraint_coeffs: np.ndarray,
                                  max_value: float,
                                  penalty_weight: Optional[float] = None,
                                  constraint_name: str = "inequality_constraint"):
        """
        Add inequality constraint: Σ c_i x_i ≤ A_max
        
        Quadratic penalty approximation: P * (Σ c_i x_i - A_max)²
        
        Note: This is exact if optimal solution satisfies the constraint.
        For strict enforcement, use sufficiently large P (see Theorem IV.1).
        
        Alternative approaches for inequality (not implemented here):
        - Slack variables: Σ c_i x_i + s = A_max, s binary-encoded
        - Max penalty: P * max(0, Σ c_i x_i - A_max)² (requires reformulation)
        
        Args:
            constraint_coeffs: Coefficients c_i (typically all positive)
            max_value: Maximum allowed value A_max
            penalty_weight: Penalty coefficient P
            constraint_name: Name for tracking
            
        Reference: Section IV.1.2 (Inequality Constraints)
        """
        if len(constraint_coeffs) != self.n:
            raise ValueError(f"Expected {self.n} coefficients, got {len(constraint_coeffs)}")
        
        Q_penalty = ConstraintPenaltyEncoder.inequality_constraint_penalty_quadratic(
            constraint_coeffs, max_value
        )
        
        if penalty_weight is None:
            penalty_weight = self._compute_auto_penalty_weight()
        
        self.constraint_matrices.append(Q_penalty)
        self.penalty_weights.append(penalty_weight)
        self.constraint_metadata.append({
            'type': 'inequality',
            'name': constraint_name,
            'coeffs': constraint_coeffs,
            'max_value': max_value,
            'penalty_weight': penalty_weight
        })
        
        self.Q_total = self.Q_physical.copy()
        for Q_c, P_c in zip(self.constraint_matrices, self.penalty_weights):
            self.Q_total += P_c * Q_c
    
    def add_cardinality_constraint(self, target_count: int,
                                   penalty_weight: Optional[float] = None,
                                   variable_subset: Optional[List[int]] = None):
        """
        Add cardinality constraint: Σ x_i = k
        
        Special case of equality constraint with unit coefficients.
        Useful for "select exactly k items" constraints.
        
        Args:
            target_count: Desired count k
            penalty_weight: Penalty coefficient
            variable_subset: Indices of variables to include (None = all)
            
        Example:
            # Select exactly 10 cells for green space
            builder.add_cardinality_constraint(target_count=10)
        """
        if variable_subset is None:
            # Apply to all variables
            constraint_coeffs = np.ones(self.n)
            constraint_name = f"cardinality_all_{target_count}"
        else:
            # Apply to subset
            constraint_coeffs = np.zeros(self.n)
            constraint_coeffs[variable_subset] = 1.0
            constraint_name = f"cardinality_subset_{target_count}"
        
        self.add_equality_constraint(
            constraint_coeffs, 
            target_value=float(target_count),
            penalty_weight=penalty_weight,
            constraint_name=constraint_name
        )
    
    def add_budget_constraint(self, costs: np.ndarray, budget_max: float,
                             penalty_weight: Optional[float] = None):
        """
        Add budget constraint: Σ cost_i * x_i ≤ B_max
        
        Args:
            costs: Cost of greening each cell
            budget_max: Maximum budget
            penalty_weight: Penalty coefficient
            
        Example:
            # Budget constraint for UHI project
            costs = np.array([100, 150, 120, ...])  # per cell in k$
            builder.add_budget_constraint(costs, budget_max=5000)
        """
        self.add_inequality_constraint(
            costs, 
            budget_max, 
            penalty_weight,
            constraint_name="budget_constraint"
        )
    
    def add_area_constraint(self, areas: np.ndarray, area_max: float,
                           penalty_weight: Optional[float] = None):
        """
        Add area constraint: Σ area_i * x_i ≤ A_max
        
        Typical for UHI problems: total green space area limited.
        
        Args:
            areas: Area of each candidate cell (m²)
            area_max: Maximum total area (m²)
            penalty_weight: Penalty coefficient
            
        Example:
            # Maximum 30% of city area for green space
            cell_areas = np.full(n_cells, 2500)  # 50m × 50m cells
            area_max = 0.3 * total_city_area
            builder.add_area_constraint(cell_areas, area_max)
        """
        self.add_inequality_constraint(
            areas,
            area_max,
            penalty_weight,
            constraint_name="area_constraint"
        )
    
    def build(self) -> np.ndarray:
        """
        Finalize and return the complete QUBO matrix.
        
        Performs:
        1. Combines physical and penalty terms
        2. Enforces symmetry
        3. Verification checks
        4. Computes statistics
        
        Returns:
            Q: Complete QUBO matrix (n × n, symmetric)
            
        Raises:
            ValueError: If verification fails
        """
        # Combine all terms
        self.Q_total = self.Q_physical.copy()
        for Q_c, P_c in zip(self.constraint_matrices, self.penalty_weights):
            self.Q_total += P_c * Q_c
        
        # Enforce symmetry if requested
        if self.config.enforce_symmetry:
            self.Q_total = ensure_symmetric(self.Q_total)
        
        # Verification
        if self.config.verify_construction:
            is_valid, msg = verify_qubo_matrix(self.Q_total)
            if not is_valid:
                raise ValueError(f"QUBO matrix verification failed: {msg}")
        
        # Compute statistics
        self.statistics = compute_qubo_statistics(self.Q_total)
        self.statistics['n_constraints'] = len(self.constraint_matrices)
        self.statistics['penalty_weights'] = self.penalty_weights.copy()
        
        # Verify penalty sufficiency
        if self.constraint_matrices:
            self._verify_penalty_sufficiency()
        
        return self.Q_total
    
    def get_physical_matrix(self) -> np.ndarray:
        """Return the physical objective matrix only."""
        return self.Q_physical.copy()
    
    def get_penalty_matrices(self) -> List[np.ndarray]:
        """Return list of all constraint penalty matrices."""
        return [Q.copy() for Q in self.constraint_matrices]
    
    def get_statistics(self) -> Dict:
        """Return statistics about the constructed QUBO."""
        if not self.statistics:
            self.statistics = compute_qubo_statistics(self.Q_total)
        return self.statistics.copy()
    
    def get_constraint_metadata(self) -> List[Dict]:
        """Return metadata about all constraints."""
        return [m.copy() for m in self.constraint_metadata]
    
    def evaluate_solution(self, x: np.ndarray) -> Dict[str, float]:
        """
        Evaluate a solution and decompose energy terms.
        
        Args:
            x: Binary solution vector
            
        Returns:
            Dictionary with:
            - 'total_energy': Total QUBO energy
            - 'physical_energy': Physical objective value
            - 'penalty_energies': List of individual penalty contributions
            - 'constraint_violations': List of constraint violations
        """
        if len(x) != self.n:
            raise ValueError(f"Expected solution of length {self.n}, got {len(x)}")
        
        if not np.all(np.logical_or(x == 0, x == 1)):
            raise ValueError("Solution must be binary")
        
        # Total energy
        total_energy = calculate_energy_from_qubo(x, self.Q_total)
        
        # Physical energy
        physical_energy = calculate_energy_from_qubo(x, self.Q_physical)
        
        # Penalty energies
        penalty_energies = []
        constraint_violations = []
        
        for i, (Q_penalty, metadata) in enumerate(zip(self.constraint_matrices, 
                                                       self.constraint_metadata)):
            penalty_energy = calculate_energy_from_qubo(x, Q_penalty)
            penalty_energies.append(penalty_energy)
            
            # Calculate violation
            if metadata['type'] in ['equality', 'inequality']:
                violation = ConstraintPenaltyEncoder.evaluate_constraint_violation(
                    x, metadata['coeffs'], 
                    metadata.get('target', metadata.get('max_value', 0))
                )
                constraint_violations.append(violation)
        
        return {
            'total_energy': total_energy,
            'physical_energy': physical_energy,
            'penalty_energies': penalty_energies,
            'constraint_violations': constraint_violations,
            'weighted_penalty_sum': sum(P * E for P, E in 
                                       zip(self.penalty_weights, penalty_energies))
        }
    
    def _compute_auto_penalty_weight(self) -> float:
        """
        Automatically compute penalty weight using Theorem IV.1.
        
        Returns:
            Penalty weight P > range(f_physical)
        """
        if self.Q_physical.size == 0:
            return self.config.penalty_weight
        
        return ConstraintPenaltyEncoder.calculate_sufficient_penalty_weight(
            self.Q_physical,
            n_constraints=len(self.constraint_matrices) + 1,
            safety_factor=self.config.penalty_safety_factor
        )
    
    def _verify_penalty_sufficiency(self):
        """
        Verify that penalty weights satisfy Theorem IV.1.
        
        Logs warnings if penalties may be insufficient.
        """
        for i, (P, Q_penalty, metadata) in enumerate(zip(
            self.penalty_weights, self.constraint_matrices, self.constraint_metadata
        )):
            is_sufficient, msg = ConstraintPenaltyEncoder.verify_penalty_sufficiency(
                self.Q_physical, P, Q_penalty
            )
            
            if not is_sufficient:
                import warnings
                warnings.warn(
                    f"Penalty weight for constraint '{metadata['name']}' may be "
                    f"insufficient: {msg}. Consider increasing penalty_weight."
                )
    
    def reset(self):
        """Reset builder to initial state."""
        self.Q_physical = np.zeros((self.n, self.n))
        self.Q_total = np.zeros((self.n, self.n))
        self.constraint_matrices = []
        self.penalty_weights = []
        self.constraint_metadata = []
        self.statistics = {}
    
    def export_to_dict(self) -> Dict:
        """
        Export QUBO matrix to dictionary format.
        
        Useful for sparse storage and D-Wave Ocean SDK compatibility.
        
        Returns:
            Dictionary {(i, j): Q_ij} for i ≤ j
        """
        from core.utils.matrix_operations import sparse_qubo_to_dict
        return sparse_qubo_to_dict(self.Q_total)
    
    def __repr__(self) -> str:
        """String representation."""
        return (f"QUBOMatrixBuilder(n={self.n}, "
                f"n_constraints={len(self.constraint_matrices)}, "
                f"density={self.statistics.get('density', 'unknown')})")
