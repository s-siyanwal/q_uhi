"""
Spatial Modeling Module

Provides spatial data structures, heat diffusion modeling, and connectivity
analysis for the UHI-QUBO framework.

Components:
- UrbanGrid: Spatial grid representation with GIS support
- HeatDiffusionSolver: Physics-based heat equation solver
- ConnectivityAnalyzer: Graph-based connectivity analysis

Author: UHI-QUBO Research Team
Version: 1.0
"""

from core.spatial_modeling.urban_grid import (
    UrbanGrid,
    CellProperties,
    create_synthetic_grid
)

from core.spatial_modeling.heat_diffusion import (
    HeatDiffusionSolver,
    compute_steady_state_cooling
)

from core.spatial_modeling.connectivity_analyzer import (
    ConnectivityAnalyzer,
    analyze_green_network_coverage
)

__all__ = [
    # Urban grid
    'UrbanGrid',
    'CellProperties',
    'create_synthetic_grid',
    
    # Heat diffusion
    'HeatDiffusionSolver',
    'compute_steady_state_cooling',
    
    # Connectivity analysis
    'ConnectivityAnalyzer',
    'analyze_green_network_coverage',
]
