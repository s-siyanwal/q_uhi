# Spatial Modeling Module

This module provides spatial data structures, heat diffusion modeling, and connectivity analysis for the UHI-QUBO framework.

## Overview

The spatial modeling module enables realistic urban planning by:
- Representing urban areas as discretized grids with temperature and land use data
- Simulating heat diffusion using physics-based PDE solvers
- Analyzing green space network connectivity using graph theory
- Computing accessibility and coverage metrics

## Components

### 1. UrbanGrid (`urban_grid.py`)

Spatial grid representation of the urban environment.

**Key Features:**
- 2D/1D index conversion for QUBO compatibility
- Temperature field management
- Land use classification (candidate, building, road, water, existing green)
- GIS coordinate support (latitude/longitude)
- Prohibited location handling
- Distance calculations (Euclidean, Manhattan)
- Neighborhood queries (4-connected, 8-connected)
- Visualization methods

**Example:**
```python
from core.spatial_modeling import UrbanGrid, create_synthetic_grid

# Create a 20×20 grid (1 km × 1 km with 50m cells)
grid = UrbanGrid(n_rows=20, n_cols=20, cell_size=50.0)

# Or create synthetic grid for testing
grid = create_synthetic_grid(
    n_rows=20, n_cols=20, 
    cell_size=50.0,
    temp_range=(25.0, 35.0),
    candidate_fraction=0.4,
    random_seed=42
)

# Access cells
centroid = grid.get_centroid(42)  # Get position of cell 42
neighbors = grid.get_neighbors(42, connectivity=4)  # Get adjacent cells

# Set temperature field
import numpy as np
temp_field = np.random.uniform(28, 34, (20, 20))
grid.set_temperature_field(temp_field)

# Get candidate cells (available for greening)
candidates = grid.get_candidate_cells()
```

### 2. HeatDiffusionSolver (`heat_diffusion.py`)

Physics-based heat equation solver for temperature field evolution.

**Mathematical Model:**
```
∂T/∂t = α∇²T + S(x, y, t)
```

where:
- `T(x, y, t)`: Temperature field
- `α`: Thermal diffusivity (m²/s)
- `∇²T`: Laplacian operator
- `S`: Source/sink term (cooling from green spaces, heating from buildings)

**Key Features:**
- Finite difference discretization (5-point stencil)
- Explicit and implicit time integration
- Automatic stability analysis (CFL condition)
- Green space cooling source terms
- Building heating source terms
- Temperature evolution over time
- Integration with UrbanGrid

**Example:**
```python
from core.spatial_modeling import HeatDiffusionSolver

# Create solver
solver = HeatDiffusionSolver(
    grid, 
    alpha=1e-5,  # Thermal diffusivity
    method='implicit'  # 'explicit' or 'implicit'
)

# Set initial temperature
solver.set_initial_temperature(30.0)

# Add green space cooling
green_cells = [100, 101, 102, 110, 111, 112]
solver.add_green_space_cooling(green_cells, cooling_rate=2.0)  # °C/hour

# Add building heating
building_cells = [50, 51, 60, 61]
solver.add_heating_source(building_cells, heating_rate=0.5)  # °C/hour

# Simulate 2 hours
result = solver.evolve(t_final=7200, dt=60, save_every=60)

# Get final temperature field
T_final = result['final_temperature']
print(f"Final mean temperature: {T_final.mean():.2f}°C")
```

### 3. ConnectivityAnalyzer (`connectivity_analyzer.py`)

Graph-based connectivity analysis for green space networks.

**Key Features:**
- Grid-to-graph conversion using NetworkX
- Connected component detection
- Connectivity verification
- Distance calculations (Euclidean and graph-based shortest paths)
- Network metrics (degree, clustering, betweenness centrality)
- Bridge cell detection (articulation points)
- Coverage analysis (WHO 300m standard)
- Solution validation

**Example:**
```python
from core.spatial_modeling import ConnectivityAnalyzer, analyze_green_network_coverage

# Create analyzer
analyzer = ConnectivityAnalyzer(
    grid, 
    connectivity=4  # 4 or 8-connected
)

# Check if green spaces are connected
green_cells = [100, 101, 110, 111, 200, 201]
is_connected = analyzer.verify_connectivity(green_cells)
print(f"Green network connected: {is_connected}")

# Get connected components
components = analyzer.get_connected_components(green_cells)
print(f"Number of components: {len(components)}")
print(f"Component sizes: {[len(c) for c in components]}")

# Compute network metrics
metrics = analyzer.compute_connectivity_metrics(green_cells)
print(f"Average degree: {metrics['avg_degree']:.2f}")
print(f"Clustering coefficient: {metrics['avg_clustering']:.3f}")

# Analyze coverage (WHO recommends 300m access to green space)
coverage = analyze_green_network_coverage(
    grid, 
    green_cells, 
    service_distance=300.0
)
print(f"Population coverage: {coverage['coverage_fraction']:.1%}")
print(f"Average distance to green: {coverage['avg_distance_to_green']:.1f}m")

# Validate QUBO solution
solution = np.array([0, 1, 1, 0, 1, ...])  # Binary solution
candidate_indices = list(range(len(solution)))
validation = analyzer.validate_solution_connectivity(
    solution, 
    candidate_indices,
    require_connected=True
)
print(f"Solution valid: {validation['valid']}")
print(f"Number of components: {validation['n_components']}")
```

## Integration with UHI-QUBO Framework

The spatial modeling modules integrate seamlessly with the existing framework:

```python
from core.spatial_modeling import create_synthetic_grid, HeatDiffusionSolver, ConnectivityAnalyzer
from core.problem_modeling import UHIGreenLayoutProblem, UHIProblemConfig
from core.problem_modeling.cooling_kernels import GaussianCoolingKernel

# Step 1: Create urban grid
grid = create_synthetic_grid(30, 30, cell_size=50.0, candidate_fraction=0.4)

# Step 2: Setup QUBO problem
config = UHIProblemConfig(
    grid_rows=30, grid_cols=30, cell_size=50.0,
    cooling_kernel_type='gaussian',
    cooling_length_scale=100.0,
    cooling_amplitude=-2.0,
    area_budget_fraction=0.2
)
problem = UHIGreenLayoutProblem(config)
problem.setup_uniform_grid(candidate_fraction=0.4)
problem.setup_cooling_model()

# Step 3: Build and solve QUBO
Q, metadata = problem.build_qubo()
# ... solve Q using quantum/classical solver ...
solution = solver.solve(Q)
problem.set_solution(solution)

# Step 4: Analyze connectivity
analyzer = ConnectivityAnalyzer(grid, connectivity=4)
selected_cells = [problem.candidate_indices[i] 
                 for i in range(len(solution)) if solution[i] == 1]
metrics = analyzer.compute_connectivity_metrics(selected_cells)

# Step 5: Simulate heat diffusion
heat_solver = HeatDiffusionSolver(grid, alpha=1e-5, method='implicit')
heat_solver.set_initial_temperature(grid.get_temperature_field())
heat_solver.add_green_space_cooling(selected_cells, cooling_rate=2.0)
result = heat_solver.evolve(t_final=7200, dt=60)

# Step 6: Evaluate cooling benefit
T0 = grid.get_temperature_field().mean()
T_final = result['final_temperature'].mean()
print(f"Cooling achieved: {T0 - T_final:.2f}°C")
```

## Mathematical Details

### Heat Diffusion PDE

The 2D heat equation is discretized using finite differences:

**Spatial Discretization (5-point stencil):**
```
∇²T_{i,j} ≈ (T_{i+1,j} + T_{i-1,j} + T_{i,j+1} + T_{i,j-1} - 4T_{i,j}) / h²
```

**Time Integration:**
- **Explicit (Forward Euler):** `T^{n+1} = T^n + Δt(α∇²T^n + S)`
  - Simple but requires small Δt for stability
  - Stability condition: `Δt ≤ h²/(4α)`
  
- **Implicit (Backward Euler):** `(I - Δt·α·∇²)T^{n+1} = T^n + Δt·S`
  - Unconditionally stable
  - Requires solving linear system each timestep

### Graph Connectivity

The urban grid is converted to a graph `G = (V, E)`:
- **Vertices:** Grid cells
- **Edges:** Spatial adjacency (4 or 8-connected) or distance threshold
- **Edge weights:** Euclidean distances

**Connected Components:** Maximal sets of cells reachable via edges

**Network Metrics:**
- **Degree:** Number of neighboring cells
- **Clustering coefficient:** Fraction of neighbors that are also connected
- **Betweenness centrality:** Fraction of shortest paths passing through a cell
- **Diameter:** Longest shortest path in the network

## Performance Considerations

### UrbanGrid
- **Index conversions:** O(1) operations
- **Distance matrix:** O(N²) memory, computed lazily and cached
- **Neighbor queries:** O(1) for adjacency-based

### HeatDiffusionSolver
- **Laplacian matrix:** Sparse (5 non-zeros per row on average)
- **Explicit step:** O(N) time
- **Implicit step:** O(N) to O(N log N) time with sparse solvers
- **Memory:** O(N) for temperature field + O(N) for sparse matrix

### ConnectivityAnalyzer
- **Graph construction:** O(N) for adjacency, O(N²) for distance-based
- **Connected components:** O(N + E) using DFS/BFS
- **Shortest paths:** O(N log N + E) using Dijkstra
- **Network metrics:** O(N + E) to O(N²) depending on metric

## Testing

Run the test suite:
```bash
python scripts/test_spatial_modeling.py
```

Run the integration demo:
```bash
python examples/spatial_modeling_demo.py
```

## References

1. **Heat Diffusion:** Crank-Nicolson method, finite difference PDE solvers
2. **Graph Theory:** NetworkX library, connected components, network metrics
3. **Urban Planning:** WHO green space accessibility standards (300m)
4. **Spatial Analysis:** GIS coordinate systems, spatial indexing

## Authors

UHI-QUBO Research Team
