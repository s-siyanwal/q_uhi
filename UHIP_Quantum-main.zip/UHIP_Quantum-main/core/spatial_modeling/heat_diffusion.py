"""
Heat Diffusion Modeling

Implements physics-based heat diffusion simulation for urban environments.
Solves the heat equation using finite difference methods to model temperature
evolution and cooling effects from green infrastructure.

Mathematical Model:
    ∂T/∂t = α∇²T + S(x, y, t)
    
where:
    T(x, y, t): Temperature field
    α: Thermal diffusivity (m²/s)
    ∇²T: Laplacian (spatial second derivative)
    S: Source/sink term (cooling from green spaces)

Author: UHI-QUBO Research Team
Version: 1.0
"""

import numpy as np
from typing import Optional, Callable, Dict, Tuple, Union
from scipy.sparse import diags, csr_matrix
from scipy.sparse.linalg import spsolve

from core.spatial_modeling.urban_grid import UrbanGrid


class HeatDiffusionSolver:
    """
    Solves the 2D heat equation on an urban grid.
    
    Discretization:
    - Spatial: Finite difference on regular grid
    - Temporal: Explicit Euler or implicit Crank-Nicolson
    
    Heat Equation:
        ∂T/∂t = α∇²T + S
    
    Discrete Laplacian (5-point stencil):
        ∇²T_ij ≈ (T_{i+1,j} + T_{i-1,j} + T_{i,j+1} + T_{i,j-1} - 4T_{ij}) / h²
    
    Stability Condition (Explicit):
        Δt ≤ h² / (4α)  (CFL condition)
    
    Example:
        >>> grid = UrbanGrid(50, 50, cell_size=50.0)
        >>> solver = HeatDiffusionSolver(grid, alpha=1e-5)
        >>> solver.set_initial_temperature(30.0)
        >>> solver.add_green_space_cooling([100, 150], cooling_rate=2.0)
        >>> solver.evolve(t_final=3600, dt=10)  # 1 hour simulation
        >>> final_temp = solver.get_temperature_field()
    """
    
    def __init__(self, grid: UrbanGrid, alpha: float = 1e-5, 
                 method: str = 'explicit'):
        """
        Initialize heat diffusion solver.
        
        Args:
            grid: UrbanGrid instance
            alpha: Thermal diffusivity (m²/s), typical: 1e-6 to 1e-4
            method: 'explicit' (forward Euler) or 'implicit' (backward Euler)
        
        Raises:
            ValueError: If method is unknown
        """
        self.grid = grid
        self.alpha = alpha
        self.method = method
        
        if method not in ['explicit', 'implicit']:
            raise ValueError(f"Unknown method: {method}. Use 'explicit' or 'implicit'")
        
        # Temperature field (flattened)
        self.T = np.zeros(grid.N)
        
        # Source/sink term
        self.source = np.zeros(grid.N)
        
        # Time tracking
        self.time = 0.0
        
        # Build Laplacian matrix
        self._build_laplacian_matrix()
        
        # Determine stable time step
        self.dt_stable = self._compute_stable_timestep()
    
    def _build_laplacian_matrix(self):
        """
        Build discrete Laplacian operator matrix.
        
        Uses 5-point stencil for 2D Laplacian on regular grid.
        Implements Neumann boundary conditions (zero gradient).
        
        Matrix is sparse (5 non-zeros per row on average).
        """
        n = self.grid.N
        h = self.grid.cell_size
        
        # Diagonal and off-diagonal values
        diag_val = -4.0 / (h * h)
        off_diag = 1.0 / (h * h)
        
        # Build matrix in COO format
        row_indices = []
        col_indices = []
        data = []
        
        for k in range(n):
            i, j = self.grid.unflatten_index(k)
            
            # Diagonal element
            row_indices.append(k)
            col_indices.append(k)
            data.append(diag_val)
            
            # Neighbors (4-connected)
            # North (i+1, j)
            if i < self.grid.n_rows - 1:
                neighbor = self.grid.flatten_index(i + 1, j)
                row_indices.append(k)
                col_indices.append(neighbor)
                data.append(off_diag)
            
            # South (i-1, j)
            if i > 0:
                neighbor = self.grid.flatten_index(i - 1, j)
                row_indices.append(k)
                col_indices.append(neighbor)
                data.append(off_diag)
            
            # East (i, j+1)
            if j < self.grid.n_cols - 1:
                neighbor = self.grid.flatten_index(i, j + 1)
                row_indices.append(k)
                col_indices.append(neighbor)
                data.append(off_diag)
            
            # West (i, j-1)
            if j > 0:
                neighbor = self.grid.flatten_index(i, j - 1)
                row_indices.append(k)
                col_indices.append(neighbor)
                data.append(off_diag)
        
        from scipy.sparse import coo_matrix
        self.laplacian = coo_matrix(
            (data, (row_indices, col_indices)),
            shape=(n, n)
        ).tocsr()
    
    def _compute_stable_timestep(self) -> float:
        """
        Compute maximum stable time step for explicit method.
        
        CFL condition: Δt ≤ h²/(4α)
        
        Returns:
            Maximum stable time step (seconds)
        """
        h = self.grid.cell_size
        dt_max = h * h / (4.0 * self.alpha)
        # Use safety factor and cap at reasonable value
        return min(0.25 * dt_max, 60.0)  # Max 60 seconds
    
    def set_initial_temperature(self, T0: Union[float, np.ndarray]):
        """
        Set initial temperature field.
        
        Args:
            T0: Uniform temperature (float) or field array (n_rows, n_cols) or (N,)
        """
        if isinstance(T0, (int, float)):
            self.T = np.full(self.grid.N, float(T0))
        elif isinstance(T0, np.ndarray):
            if T0.shape == (self.grid.n_rows, self.grid.n_cols):
                self.T = T0.flatten()
            elif T0.shape == (self.grid.N,):
                self.T = T0.copy()
            else:
                raise ValueError(f"Temperature array must be ({self.grid.n_rows}, {self.grid.n_cols}) or ({self.grid.N},)")
        else:
            raise TypeError("T0 must be float or ndarray")
        
        self.time = 0.0
    
    def add_green_space_cooling(self, green_cell_indices: list, 
                               cooling_rate: float = 2.0):
        """
        Add cooling source terms at green space locations.
        
        Models evapotranspiration cooling as a negative source term.
        
        Args:
            green_cell_indices: List of cell indices with green spaces
            cooling_rate: Cooling power per cell (°C/hour)
        """
        # Convert to °C/s
        cooling_per_second = cooling_rate / 3600.0
        
        for k in green_cell_indices:
            if 0 <= k < self.grid.N:
                self.source[k] = -cooling_per_second  # Negative = cooling
    
    def add_heating_source(self, cell_indices: list, heating_rate: float):
        """
        Add heating source terms (e.g., buildings, pavement).
        
        Args:
            cell_indices: List of cell indices
            heating_rate: Heating power (°C/hour)
        """
        heating_per_second = heating_rate / 3600.0
        
        for k in cell_indices:
            if 0 <= k < self.grid.N:
                self.source[k] = heating_per_second
    
    def set_source_term(self, source_field: np.ndarray):
        """
        Set arbitrary source/sink field.
        
        Args:
            source_field: Source term (°C/s), shape (n_rows, n_cols) or (N,)
        """
        if source_field.shape == (self.grid.n_rows, self.grid.n_cols):
            self.source = source_field.flatten()
        elif source_field.shape == (self.grid.N,):
            self.source = source_field.copy()
        else:
            raise ValueError(f"Source field must be ({self.grid.n_rows}, {self.grid.n_cols}) or ({self.grid.N},)")
    
    def step(self, dt: float) -> np.ndarray:
        """
        Advance temperature field by one time step.
        
        Explicit method:
            T^{n+1} = T^n + dt * (α∇²T^n + S)
        
        Implicit method:
            (I - dt*α*∇²)T^{n+1} = T^n + dt*S
        
        Args:
            dt: Time step (seconds)
            
        Returns:
            Updated temperature field (flattened)
        """
        if self.method == 'explicit':
            # Check stability
            if dt > self.dt_stable:
                import warnings
                warnings.warn(
                    f"Time step dt={dt:.2e}s exceeds stability limit {self.dt_stable:.2e}s. "
                    "Solution may be unstable."
                )
            
            # T^{n+1} = T^n + dt*(α∇²T + S)
            laplacian_T = self.laplacian @ self.T
            dT_dt = self.alpha * laplacian_T + self.source
            self.T = self.T + dt * dT_dt
            
        elif self.method == 'implicit':
            # (I - dt*α*∇²)T^{n+1} = T^n + dt*S
            # Solve linear system: A*T^{n+1} = b
            
            from scipy.sparse import identity
            I = identity(self.grid.N, format='csr')
            A = I - dt * self.alpha * self.laplacian
            b = self.T + dt * self.source
            
            self.T = spsolve(A, b)
        
        self.time += dt
        return self.T
    
    def evolve(self, t_final: float, dt: Optional[float] = None,
              save_every: Optional[int] = None) -> Dict:
        """
        Evolve temperature field to final time.
        
        Args:
            t_final: Final simulation time (seconds)
            dt: Time step (None = use stable dt for explicit)
            save_every: Save temperature every N steps (None = save final only)
            
        Returns:
            Dictionary with:
                'times': Array of saved times
                'temperatures': List of temperature fields
                'final_temperature': Final temperature field
        """
        if dt is None:
            dt = self.dt_stable
        
        n_steps = int(np.ceil(t_final / dt))
        
        # Storage
        saved_times = []
        saved_temps = []
        
        if save_every is None:
            save_every = n_steps  # Only save final
        
        for step in range(n_steps):
            self.step(dt)
            
            if (step + 1) % save_every == 0 or step == n_steps - 1:
                saved_times.append(self.time)
                saved_temps.append(self.T.copy())
        
        return {
            'times': np.array(saved_times),
            'temperatures': saved_temps,
            'final_temperature': self.T.copy()
        }
    
    def get_temperature_field(self) -> np.ndarray:
        """
        Get current temperature field as 2D array.
        
        Returns:
            Temperature array of shape (n_rows, n_cols)
        """
        return self.T.reshape((self.grid.n_rows, self.grid.n_cols))
    
    def get_temperature_at_cell(self, k: int) -> float:
        """
        Get temperature at specific cell.
        
        Args:
            k: Cell index
            
        Returns:
            Temperature (°C)
        """
        return float(self.T[k])
    
    def compute_cooling_benefit(self, green_cell_indices: list,
                                t_simulation: float = 3600,
                                baseline_temp: Optional[np.ndarray] = None) -> float:
        """
        Compute total cooling benefit of green space configuration.
        
        Simulates temperature evolution with green spaces and computes
        average temperature reduction.
        
        Args:
            green_cell_indices: List of green space cell indices
            t_simulation: Simulation time (seconds), default 1 hour
            baseline_temp: Baseline temperature (None = use current)
            
        Returns:
            Average temperature reduction (°C)
        """
        # Save current state
        T_original = self.T.copy()
        source_original = self.source.copy()
        time_original = self.time
        
        # Set baseline
        if baseline_temp is not None:
            self.set_initial_temperature(baseline_temp)
        T_baseline = self.T.copy()
        
        # Simulate without green spaces
        self.source = np.zeros(self.grid.N)
        result_baseline = self.evolve(t_simulation)
        T_no_green = result_baseline['final_temperature']
        
        # Simulate with green spaces
        self.set_initial_temperature(T_baseline)
        self.add_green_space_cooling(green_cell_indices, cooling_rate=2.0)
        result_green = self.evolve(t_simulation)
        T_with_green = result_green['final_temperature']
        
        # Compute cooling benefit
        cooling_benefit = float(np.mean(T_no_green - T_with_green))
        
        # Restore state
        self.T = T_original
        self.source = source_original
        self.time = time_original
        
        return cooling_benefit
    
    def update_grid_temperature(self):
        """
        Update the UrbanGrid temperature field with current simulation state.
        """
        self.grid.set_temperature_field(self.get_temperature_field())
    
    def get_statistics(self) -> Dict:
        """
        Compute statistics of current temperature field.
        
        Returns:
            Dictionary with temperature statistics
        """
        T_2d = self.get_temperature_field()
        
        return {
            'mean': float(np.mean(self.T)),
            'std': float(np.std(self.T)),
            'min': float(np.min(self.T)),
            'max': float(np.max(self.T)),
            'median': float(np.median(self.T)),
            'range': float(np.max(self.T) - np.min(self.T)),
            'current_time': self.time
        }
    
    def __repr__(self) -> str:
        """String representation."""
        return (f"HeatDiffusionSolver(grid={self.grid.n_rows}×{self.grid.n_cols}, "
                f"α={self.alpha:.2e}, method='{self.method}', t={self.time:.1f}s)")


def compute_steady_state_cooling(grid: UrbanGrid, 
                                 green_cell_indices: list,
                                 cooling_amplitude: float = 2.0,
                                 length_scale: float = 100.0) -> np.ndarray:
    """
    Compute approximate steady-state cooling pattern from green spaces.
    
    Uses superposition of cooling kernels (faster than full PDE simulation).
    
    Mathematical model:
        ΔT(r) = Σ_i A * exp(-||r - r_i||² / (2σ²))
    
    where:
        r_i: Green space locations
        A: Cooling amplitude
        σ: Length scale
    
    Args:
        grid: UrbanGrid instance
        green_cell_indices: List of green space cell indices
        cooling_amplitude: Maximum cooling effect (°C)
        length_scale: Spatial extent of cooling (meters)
        
    Returns:
        Cooling field array of shape (n_rows, n_cols)
    """
    from core.problem_modeling.cooling_kernels import GaussianCoolingKernel
    
    # Create cooling kernel
    kernel = GaussianCoolingKernel(sigma=length_scale, amplitude=-cooling_amplitude)
    
    # Get all cell centroids
    centroids = grid.get_centroid_array()
    
    # Initialize cooling field
    cooling = np.zeros(grid.N)
    
    # Superpose cooling from each green space
    for k in green_cell_indices:
        green_pos = grid.get_centroid(k)
        
        for j in range(grid.N):
            cell_pos = centroids[j]
            cooling[j] += kernel(green_pos, cell_pos)
    
    return cooling.reshape((grid.n_rows, grid.n_cols))
