"""
Connectivity Analyzer

Graph-based connectivity analysis for green space networks.
Verifies spatial connectivity, computes connected components, 
and analyzes network properties for UHI optimization solutions.

Physical Motivation:
- Green spaces form connected networks that enhance ecosystem services
- Connectivity enables species movement and ecological function
- Distance between green patches affects cooling synergy

Mathematical Model:
- Urban grid converted to graph G = (V, E)
- Vertices: Grid cells
- Edges: Spatial adjacency or distance-based connections
- Analysis: Connected components, path lengths, network metrics

Author: UHI-QUBO Research Team
Version: 1.0
"""

import numpy as np
from typing import List, Set, Dict, Tuple, Optional
import networkx as nx

from core.spatial_modeling.urban_grid import UrbanGrid


class ConnectivityAnalyzer:
    """
    Analyzes spatial connectivity of green space networks.
    
    Converts urban grid to graph and performs network analysis:
    - Connected component detection
    - Shortest path distances
    - Network metrics (clustering, centrality)
    - Connectivity verification for solutions
    
    Graph Construction:
    - Nodes: Grid cells
    - Edges: Defined by adjacency (4 or 8-connected) or distance threshold
    
    Example:
        >>> grid = UrbanGrid(20, 20, cell_size=50.0)
        >>> analyzer = ConnectivityAnalyzer(grid, connectivity=4)
        >>> solution = [10, 11, 12, 30, 31]  # Green cells
        >>> is_connected = analyzer.verify_connectivity(solution)
        >>> components = analyzer.get_connected_components(solution)
    """
    
    def __init__(self, grid: UrbanGrid, connectivity: int = 4,
                 max_distance: Optional[float] = None):
        """
        Initialize connectivity analyzer.
        
        Args:
            grid: UrbanGrid instance
            connectivity: 4 (von Neumann) or 8 (Moore) neighborhood
            max_distance: Maximum distance for edge connection (None = adjacency only)
        
        Raises:
            ValueError: If connectivity is invalid
        """
        self.grid = grid
        self.connectivity = connectivity
        self.max_distance = max_distance
        
        if connectivity not in [4, 8]:
            raise ValueError("Connectivity must be 4 or 8")
        
        # Build grid graph
        self.graph = self._build_grid_graph()
    
    def _build_grid_graph(self) -> nx.Graph:
        """
        Build graph representation of urban grid.
        
        Returns:
            NetworkX graph with grid topology
        """
        G = nx.Graph()
        
        # Add all cells as nodes
        for k in range(self.grid.N):
            pos = self.grid.get_centroid(k)
            G.add_node(k, pos=pos)
        
        # Add edges based on connectivity
        if self.max_distance is None:
            # Adjacency-based edges
            for k in range(self.grid.N):
                neighbors = self.grid.get_neighbors(k, self.connectivity)
                for neighbor in neighbors:
                    if not G.has_edge(k, neighbor):
                        distance = self.grid.get_distance(k, neighbor)
                        G.add_edge(k, neighbor, weight=distance)
        else:
            # Distance-based edges
            for k in range(self.grid.N):
                for j in range(k + 1, self.grid.N):
                    distance = self.grid.get_distance(k, j)
                    if distance <= self.max_distance:
                        G.add_edge(k, j, weight=distance)
        
        return G
    
    def get_subgraph(self, cell_indices: List[int]) -> nx.Graph:
        """
        Extract subgraph induced by selected cells.
        
        Args:
            cell_indices: List of cell indices to include
            
        Returns:
            Subgraph containing only selected cells and their connections
        """
        return self.graph.subgraph(cell_indices).copy()
    
    def verify_connectivity(self, cell_indices: List[int]) -> bool:
        """
        Check if selected cells form a connected network.
        
        Args:
            cell_indices: List of selected cell indices
            
        Returns:
            True if all cells are in one connected component
        """
        if len(cell_indices) == 0:
            return True
        if len(cell_indices) == 1:
            return True
        
        subgraph = self.get_subgraph(cell_indices)
        return nx.is_connected(subgraph)
    
    def get_connected_components(self, cell_indices: List[int]) -> List[Set[int]]:
        """
        Find connected components in selected cells.
        
        Args:
            cell_indices: List of selected cell indices
            
        Returns:
            List of sets, each containing cell indices of one component
        """
        if len(cell_indices) == 0:
            return []
        
        subgraph = self.get_subgraph(cell_indices)
        components = list(nx.connected_components(subgraph))
        
        return components
    
    def count_components(self, cell_indices: List[int]) -> int:
        """
        Count number of connected components.
        
        Args:
            cell_indices: List of selected cell indices
            
        Returns:
            Number of connected components
        """
        return len(self.get_connected_components(cell_indices))
    
    def get_largest_component(self, cell_indices: List[int]) -> Set[int]:
        """
        Get largest connected component.
        
        Args:
            cell_indices: List of selected cell indices
            
        Returns:
            Set of cell indices in largest component
        """
        components = self.get_connected_components(cell_indices)
        
        if not components:
            return set()
        
        return max(components, key=len)
    
    def compute_distances(self, source_cells: List[int], 
                         target_cells: Optional[List[int]] = None,
                         metric: str = 'euclidean') -> np.ndarray:
        """
        Compute distances between cell sets.
        
        Args:
            source_cells: List of source cell indices
            target_cells: List of target cell indices (None = all cells)
            metric: 'euclidean' (straight line) or 'graph' (shortest path)
            
        Returns:
            Distance matrix of shape (len(source_cells), len(target_cells))
        """
        if target_cells is None:
            target_cells = list(range(self.grid.N))
        
        n_source = len(source_cells)
        n_target = len(target_cells)
        distances = np.zeros((n_source, n_target))
        
        if metric == 'euclidean':
            # Straight-line distances
            for i, s in enumerate(source_cells):
                for j, t in enumerate(target_cells):
                    distances[i, j] = self.grid.get_distance(s, t)
        
        elif metric == 'graph':
            # Shortest path distances on graph
            for i, s in enumerate(source_cells):
                # Compute shortest paths from source
                try:
                    lengths = nx.single_source_dijkstra_path_length(
                        self.graph, s, weight='weight'
                    )
                    for j, t in enumerate(target_cells):
                        distances[i, j] = lengths.get(t, np.inf)
                except nx.NetworkXError:
                    distances[i, :] = np.inf
        
        else:
            raise ValueError(f"Unknown metric: {metric}")
        
        return distances
    
    def find_minimum_spanning_tree(self, cell_indices: List[int]) -> nx.Graph:
        """
        Find minimum spanning tree connecting selected cells.
        
        Useful for minimizing total connection cost while maintaining connectivity.
        
        Args:
            cell_indices: List of cell indices to connect
            
        Returns:
            Minimum spanning tree as NetworkX graph
        """
        if len(cell_indices) < 2:
            return nx.Graph()
        
        subgraph = self.get_subgraph(cell_indices)
        
        if not nx.is_connected(subgraph):
            raise ValueError("Cannot construct spanning tree: cells are not connected")
        
        mst = nx.minimum_spanning_tree(subgraph, weight='weight')
        return mst
    
    def compute_average_distance_to_green(self, green_cells: List[int],
                                         population_cells: Optional[List[int]] = None) -> float:
        """
        Compute average distance from population centers to nearest green space.
        
        Equity metric: measures green space accessibility.
        
        Args:
            green_cells: List of green space cell indices
            population_cells: List of populated cell indices (None = all cells)
            
        Returns:
            Average distance (meters)
        """
        if len(green_cells) == 0:
            return np.inf
        
        if population_cells is None:
            population_cells = list(range(self.grid.N))
        
        if len(population_cells) == 0:
            return 0.0
        
        # Compute distance matrix
        distances = self.compute_distances(population_cells, green_cells, metric='euclidean')
        
        # Minimum distance to any green space
        min_distances = np.min(distances, axis=1)
        
        # Average over population
        return float(np.mean(min_distances))
    
    def compute_connectivity_metrics(self, cell_indices: List[int]) -> Dict:
        """
        Compute comprehensive connectivity metrics for cell selection.
        
        Args:
            cell_indices: List of selected cell indices
            
        Returns:
            Dictionary with connectivity metrics:
                - is_connected: Boolean
                - n_components: Number of components
                - component_sizes: List of component sizes
                - avg_clustering: Average clustering coefficient
                - diameter: Graph diameter (longest shortest path)
                - avg_degree: Average node degree
        """
        if len(cell_indices) == 0:
            return {
                'is_connected': True,
                'n_components': 0,
                'component_sizes': [],
                'avg_clustering': 0.0,
                'diameter': 0.0,
                'avg_degree': 0.0
            }
        
        subgraph = self.get_subgraph(cell_indices)
        
        # Connected components
        components = list(nx.connected_components(subgraph))
        is_connected = len(components) == 1
        component_sizes = [len(c) for c in components]
        
        # Clustering coefficient
        try:
            avg_clustering = nx.average_clustering(subgraph)
        except (ZeroDivisionError, nx.NetworkXError):
            avg_clustering = 0.0
        
        # Diameter (only for connected graphs)
        if is_connected and len(cell_indices) > 1:
            try:
                diameter = nx.diameter(subgraph, weight='weight')
            except nx.NetworkXError:
                diameter = 0.0
        else:
            diameter = 0.0
        
        # Average degree
        if len(cell_indices) > 0:
            degrees = [subgraph.degree(node) for node in subgraph.nodes()]
            avg_degree = np.mean(degrees)
        else:
            avg_degree = 0.0
        
        return {
            'is_connected': is_connected,
            'n_components': len(components),
            'component_sizes': component_sizes,
            'avg_clustering': float(avg_clustering),
            'diameter': float(diameter),
            'avg_degree': float(avg_degree)
        }
    
    def find_bridge_cells(self, cell_indices: List[int]) -> Set[int]:
        """
        Find bridge cells (articulation points) in green network.
        
        Bridge cells are critical: their removal disconnects the network.
        
        Args:
            cell_indices: List of selected cell indices
            
        Returns:
            Set of bridge cell indices
        """
        if len(cell_indices) < 3:
            return set()
        
        subgraph = self.get_subgraph(cell_indices)
        
        if not nx.is_connected(subgraph):
            return set()
        
        articulation_points = set(nx.articulation_points(subgraph))
        return articulation_points
    
    def compute_betweenness_centrality(self, cell_indices: List[int]) -> Dict[int, float]:
        """
        Compute betweenness centrality for cells.
        
        Measures how often a cell lies on shortest paths between other cells.
        High betweenness = important connector in network.
        
        Args:
            cell_indices: List of selected cell indices
            
        Returns:
            Dictionary mapping cell index to betweenness centrality
        """
        if len(cell_indices) < 2:
            return {k: 0.0 for k in cell_indices}
        
        subgraph = self.get_subgraph(cell_indices)
        
        centrality = nx.betweenness_centrality(subgraph, weight='weight')
        
        return centrality
    
    def validate_solution_connectivity(self, solution: np.ndarray,
                                      candidate_indices: List[int],
                                      require_connected: bool = False) -> Dict:
        """
        Validate connectivity properties of a QUBO solution.
        
        Args:
            solution: Binary solution array
            candidate_indices: List of candidate cell indices
            require_connected: Whether to enforce connectivity constraint
            
        Returns:
            Dictionary with validation results and metrics
        """
        # Extract selected cells
        selected = [candidate_indices[i] for i in range(len(solution)) if solution[i] == 1]
        
        if len(selected) == 0:
            return {
                'valid': True,
                'n_selected': 0,
                'is_connected': True,
                'n_components': 0,
                'satisfies_connectivity': True
            }
        
        # Compute connectivity metrics
        metrics = self.compute_connectivity_metrics(selected)
        
        # Validation
        satisfies_connectivity = metrics['is_connected'] or not require_connected
        
        return {
            'valid': satisfies_connectivity,
            'n_selected': len(selected),
            'selected_cells': selected,
            'is_connected': metrics['is_connected'],
            'n_components': metrics['n_components'],
            'component_sizes': metrics['component_sizes'],
            'satisfies_connectivity': satisfies_connectivity,
            'connectivity_metrics': metrics
        }
    
    def visualize_network(self, cell_indices: Optional[List[int]] = None,
                         ax=None, node_color: str = 'green',
                         edge_color: str = 'gray', node_size: int = 50):
        """
        Visualize green space network on grid.
        
        Args:
            cell_indices: List of cells to visualize (None = all)
            ax: Matplotlib axes (created if None)
            node_color: Color for nodes
            edge_color: Color for edges
            node_size: Size of nodes
            
        Returns:
            Matplotlib axes
        """
        import matplotlib.pyplot as plt
        
        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 8))
        
        # Select subgraph
        if cell_indices is not None:
            G = self.get_subgraph(cell_indices)
        else:
            G = self.graph
        
        # Get positions from grid
        pos = {node: self.grid.get_centroid(node) for node in G.nodes()}
        
        # Draw network
        nx.draw_networkx_nodes(G, pos, ax=ax, node_color=node_color,
                              node_size=node_size, alpha=0.7)
        nx.draw_networkx_edges(G, pos, ax=ax, edge_color=edge_color,
                              alpha=0.3, width=1)
        
        ax.set_xlabel('X (m)')
        ax.set_ylabel('Y (m)')
        ax.set_title('Green Space Network')
        ax.set_aspect('equal')
        
        return ax
    
    def __repr__(self) -> str:
        """String representation."""
        return (f"ConnectivityAnalyzer(grid={self.grid.n_rows}×{self.grid.n_cols}, "
                f"connectivity={self.connectivity}, nodes={self.graph.number_of_nodes()}, "
                f"edges={self.graph.number_of_edges()})")


def analyze_green_network_coverage(grid: UrbanGrid,
                                   green_cells: List[int],
                                   service_distance: float = 300.0) -> Dict:
    """
    Analyze green space coverage and service area.
    
    Computes which cells are within service distance of green spaces.
    WHO recommends 300m access to green space for urban health.
    
    Args:
        grid: UrbanGrid instance
        green_cells: List of green space cell indices
        service_distance: Service radius (meters), default 300m
        
    Returns:
        Dictionary with coverage metrics:
            - coverage_fraction: Fraction of cells within service distance
            - covered_cells: List of covered cell indices
            - uncovered_cells: List of uncovered cell indices
            - avg_distance_to_green: Average distance to nearest green
    """
    if len(green_cells) == 0:
        return {
            'coverage_fraction': 0.0,
            'covered_cells': [],
            'uncovered_cells': list(range(grid.N)),
            'avg_distance_to_green': np.inf
        }
    
    # Compute distance from each cell to nearest green space
    all_cells = list(range(grid.N))
    covered = []
    uncovered = []
    distances = []
    
    for cell in all_cells:
        # Distance to nearest green space
        min_dist = min(grid.get_distance(cell, g) for g in green_cells)
        distances.append(min_dist)
        
        if min_dist <= service_distance:
            covered.append(cell)
        else:
            uncovered.append(cell)
    
    coverage_fraction = len(covered) / grid.N if grid.N > 0 else 0.0
    avg_distance = float(np.mean(distances))
    
    return {
        'coverage_fraction': coverage_fraction,
        'covered_cells': covered,
        'uncovered_cells': uncovered,
        'avg_distance_to_green': avg_distance,
        'service_distance': service_distance
    }
