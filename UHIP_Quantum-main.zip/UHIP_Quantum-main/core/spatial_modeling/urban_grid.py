"""
Urban Grid Data Structure

Represents discretized urban space with temperature and land use data.
Provides spatial indexing, GIS integration, and temperature field management
for the UHI-QUBO optimization framework.

Author: UHI-QUBO Research Team
Version: 1.0
"""

import numpy as np
from typing import Tuple, List, Optional, Dict, Set
from dataclasses import dataclass
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap


@dataclass
class CellProperties:
    """Properties of a single grid cell."""
    index: int  # Flattened index
    row: int  # 2D row index
    col: int  # 2D column index
    centroid_x: float  # X coordinate (meters or degrees)
    centroid_y: float  # Y coordinate (meters or degrees)
    temperature: float  # Current temperature (°C)
    land_use: str  # Land use category
    cooling_capacity: float  # Potential cooling (°C)
    population: int  # Population count
    is_prohibited: bool  # Cannot place green space
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization."""
        return {
            'index': self.index,
            'row': self.row,
            'col': self.col,
            'centroid': (self.centroid_x, self.centroid_y),
            'temperature': self.temperature,
            'land_use': self.land_use,
            'cooling_capacity': self.cooling_capacity,
            'population': self.population,
            'is_prohibited': self.is_prohibited
        }


class UrbanGrid:
    """
    Spatial grid representing urban environment.
    
    Manages geometric relationships, temperature data, and spatial attributes 
    for UHI optimization. Provides 2D/1D indexing, distance calculations, and
    temperature field operations.
    
    Coordinate System:
    - Origin at southwest corner
    - X-axis points east, Y-axis points north
    - Regular rectangular cells
    
    Mathematical Model:
    - Grid domain Ω discretized into n_rows × n_cols cells
    - Each cell k has centroid r_k = (x_k, y_k)
    - Flattened index: k = row * n_cols + col
    
    Example:
        >>> grid = UrbanGrid(n_rows=10, n_cols=10, cell_size=50.0)
        >>> grid.set_temperature_field(np.random.uniform(25, 35, (10, 10)))
        >>> distance = grid.get_distance(0, 99)  # Distance between corners
    """
    
    def __init__(
        self,
        n_rows: int,
        n_cols: int,
        cell_size: float,
        origin: Tuple[float, float] = (0.0, 0.0),
        crs: str = "EPSG:32633"  # UTM Zone 33N default
    ):
        """
        Initialize urban grid.
        
        Args:
            n_rows: Number of rows
            n_cols: Number of columns
            cell_size: Cell dimension (meters)
            origin: Southwest corner coordinates (x, y)
            crs: Coordinate reference system (e.g., "EPSG:32633" for UTM)
            
        Raises:
            ValueError: If dimensions are invalid
        """
        if n_rows < 1 or n_cols < 1:
            raise ValueError("Grid dimensions must be positive")
        if cell_size <= 0:
            raise ValueError("Cell size must be positive")
        
        self.n_rows = n_rows
        self.n_cols = n_cols
        self.N = n_rows * n_cols
        self.cell_size = cell_size
        self.origin = origin
        self.crs = crs
        
        # Initialize cell data
        self.cells: List[CellProperties] = self._initialize_cells()
        
        # Spatial data arrays (n_rows × n_cols)
        self.temperature = np.zeros((n_rows, n_cols))
        self.land_use = np.full((n_rows, n_cols), "unknown", dtype=object)
        self.cooling_capacity = np.ones((n_rows, n_cols))
        self.population = np.zeros((n_rows, n_cols), dtype=int)
        self.prohibited = np.zeros((n_rows, n_cols), dtype=bool)
        
        # Distance matrix (computed lazily)
        self._distance_matrix: Optional[np.ndarray] = None
        self._centroid_array: Optional[np.ndarray] = None
    
    def _initialize_cells(self) -> List[CellProperties]:
        """Create cell property objects for all grid cells."""
        cells = []
        
        for i in range(self.n_rows):
            for j in range(self.n_cols):
                # Compute centroid
                x = self.origin[0] + (j + 0.5) * self.cell_size
                y = self.origin[1] + (i + 0.5) * self.cell_size
                
                # Flattened index
                k = self.flatten_index(i, j)
                
                cell = CellProperties(
                    index=k,
                    row=i,
                    col=j,
                    centroid_x=x,
                    centroid_y=y,
                    temperature=0.0,
                    land_use="unknown",
                    cooling_capacity=1.0,
                    population=0,
                    is_prohibited=False
                )
                
                cells.append(cell)
        
        return cells
    
    def flatten_index(self, row: int, col: int) -> int:
        """
        Convert 2D grid index to 1D flattened index.
        
        Formula: k = row * n_cols + col
        
        Args:
            row: Row index (0 to n_rows-1)
            col: Column index (0 to n_cols-1)
            
        Returns:
            Flattened index k (0 to N-1)
        """
        if not (0 <= row < self.n_rows and 0 <= col < self.n_cols):
            raise IndexError(f"Index ({row}, {col}) out of bounds")
        return row * self.n_cols + col
    
    def unflatten_index(self, k: int) -> Tuple[int, int]:
        """
        Convert 1D flattened index to 2D grid index.
        
        Formula: row = k // n_cols, col = k % n_cols
        
        Args:
            k: Flattened index (0 to N-1)
            
        Returns:
            (row, col) tuple
        """
        if not (0 <= k < self.N):
            raise IndexError(f"Index {k} out of bounds [0, {self.N})")
        row = k // self.n_cols
        col = k % self.n_cols
        return row, col
    
    def get_centroid(self, k: int) -> np.ndarray:
        """
        Get centroid coordinates of cell k.
        
        Args:
            k: Flattened cell index
            
        Returns:
            Array [x, y] in grid coordinate system
        """
        if not (0 <= k < self.N):
            raise IndexError(f"Index {k} out of bounds")
        return np.array([self.cells[k].centroid_x, self.cells[k].centroid_y])
    
    def get_centroid_array(self) -> np.ndarray:
        """
        Get array of all cell centroids.
        
        Returns:
            Array of shape (N, 2) with [x, y] coordinates
        """
        if self._centroid_array is None:
            self._centroid_array = np.array([
                [cell.centroid_x, cell.centroid_y] for cell in self.cells
            ])
        return self._centroid_array
    
    def get_distance(self, k1: int, k2: int, metric: str = 'euclidean') -> float:
        """
        Compute distance between two cells.
        
        Args:
            k1: First cell index
            k2: Second cell index
            metric: Distance metric ('euclidean' or 'manhattan')
            
        Returns:
            Distance in meters
        """
        c1 = self.get_centroid(k1)
        c2 = self.get_centroid(k2)
        
        if metric == 'euclidean':
            return float(np.linalg.norm(c1 - c2))
        elif metric == 'manhattan':
            return float(np.sum(np.abs(c1 - c2)))
        else:
            raise ValueError(f"Unknown metric: {metric}")
    
    def get_distance_matrix(self, metric: str = 'euclidean') -> np.ndarray:
        """
        Compute pairwise distance matrix for all cells.
        
        Args:
            metric: Distance metric
            
        Returns:
            Distance matrix of shape (N, N)
        """
        if self._distance_matrix is None:
            from scipy.spatial.distance import cdist
            centroids = self.get_centroid_array()
            self._distance_matrix = cdist(centroids, centroids, metric=metric)
        
        return self._distance_matrix
    
    def get_neighbors(self, k: int, connectivity: int = 4) -> List[int]:
        """
        Get neighboring cell indices.
        
        Args:
            k: Cell index
            connectivity: 4 (von Neumann) or 8 (Moore) neighborhood
            
        Returns:
            List of neighbor indices
        """
        row, col = self.unflatten_index(k)
        neighbors = []
        
        # Von Neumann neighborhood (4-connected)
        offsets_4 = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        # Moore neighborhood (8-connected)
        offsets_8 = [(-1, -1), (-1, 0), (-1, 1), (0, -1), 
                     (0, 1), (1, -1), (1, 0), (1, 1)]
        
        offsets = offsets_4 if connectivity == 4 else offsets_8
        
        for dr, dc in offsets:
            r, c = row + dr, col + dc
            if 0 <= r < self.n_rows and 0 <= c < self.n_cols:
                neighbors.append(self.flatten_index(r, c))
        
        return neighbors
    
    def set_temperature_field(self, temp_field: np.ndarray):
        """
        Set temperature field for all cells.
        
        Args:
            temp_field: Temperature array of shape (n_rows, n_cols)
        """
        if temp_field.shape != (self.n_rows, self.n_cols):
            raise ValueError(f"Temperature field must have shape ({self.n_rows}, {self.n_cols})")
        
        self.temperature = temp_field.copy()
        
        # Update cell properties
        for k in range(self.N):
            row, col = self.unflatten_index(k)
            self.cells[k].temperature = float(temp_field[row, col])
    
    def get_temperature_field(self) -> np.ndarray:
        """
        Get current temperature field.
        
        Returns:
            Temperature array of shape (n_rows, n_cols)
        """
        return self.temperature.copy()
    
    def set_land_use(self, land_use_map: np.ndarray):
        """
        Set land use classification for all cells.
        
        Args:
            land_use_map: String array of shape (n_rows, n_cols)
        """
        if land_use_map.shape != (self.n_rows, self.n_cols):
            raise ValueError(f"Land use map must have shape ({self.n_rows}, {self.n_cols})")
        
        self.land_use = land_use_map.copy()
        
        # Update cell properties and prohibited status
        for k in range(self.N):
            row, col = self.unflatten_index(k)
            land_use = str(land_use_map[row, col])
            self.cells[k].land_use = land_use
            
            # Mark prohibited cells (buildings, roads, water)
            if land_use in ['building', 'road', 'water', 'existing_green']:
                self.cells[k].is_prohibited = True
                self.prohibited[row, col] = True
    
    def set_prohibited_cells(self, prohibited_indices: Set[int]):
        """
        Explicitly mark cells as prohibited for green space allocation.
        
        Args:
            prohibited_indices: Set of cell indices to prohibit
        """
        for k in prohibited_indices:
            if 0 <= k < self.N:
                row, col = self.unflatten_index(k)
                self.cells[k].is_prohibited = True
                self.prohibited[row, col] = True
    
    def get_candidate_cells(self) -> List[int]:
        """
        Get list of candidate cell indices (not prohibited).
        
        Returns:
            List of candidate cell indices
        """
        return [k for k in range(self.N) if not self.cells[k].is_prohibited]
    
    def get_lat_lon_bounds(self, lat_origin: float = 40.0, 
                          lon_origin: float = -74.0) -> Dict[str, float]:
        """
        Get geographic bounding box (for GIS integration).
        
        Simple linear approximation for small areas.
        For accurate conversions, use pyproj.
        
        Args:
            lat_origin: Latitude of grid origin
            lon_origin: Longitude of grid origin
            
        Returns:
            Dictionary with 'lat_min', 'lat_max', 'lon_min', 'lon_max'
        """
        # Approximate conversion: 1 degree lat ≈ 111 km
        # 1 degree lon ≈ 111 km * cos(lat)
        meters_per_deg_lat = 111000.0
        meters_per_deg_lon = 111000.0 * np.cos(np.radians(lat_origin))
        
        width = self.n_cols * self.cell_size
        height = self.n_rows * self.cell_size
        
        return {
            'lat_min': lat_origin,
            'lat_max': lat_origin + height / meters_per_deg_lat,
            'lon_min': lon_origin,
            'lon_max': lon_origin + width / meters_per_deg_lon
        }
    
    def visualize_temperature(self, ax=None, cmap: str = 'hot', 
                            colorbar: bool = True, title: str = 'Temperature Field') -> plt.Axes:
        """
        Visualize temperature field as heatmap.
        
        Args:
            ax: Matplotlib axes (created if None)
            cmap: Colormap name
            colorbar: Whether to show colorbar
            title: Plot title
            
        Returns:
            Matplotlib axes object
        """
        if ax is None:
            fig, ax = plt.subplots(figsize=(8, 6))
        
        im = ax.imshow(self.temperature, cmap=cmap, origin='lower',
                      extent=[self.origin[0], 
                             self.origin[0] + self.n_cols * self.cell_size,
                             self.origin[1],
                             self.origin[1] + self.n_rows * self.cell_size])
        
        ax.set_xlabel('X (m)')
        ax.set_ylabel('Y (m)')
        ax.set_title(title)
        
        if colorbar:
            cbar = plt.colorbar(im, ax=ax)
            cbar.set_label('Temperature (°C)')
        
        return ax
    
    def visualize_land_use(self, ax=None, title: str = 'Land Use') -> plt.Axes:
        """
        Visualize land use classification.
        
        Args:
            ax: Matplotlib axes (created if None)
            title: Plot title
            
        Returns:
            Matplotlib axes object
        """
        if ax is None:
            fig, ax = plt.subplots(figsize=(8, 6))
        
        # Create categorical colormap
        land_use_codes = {
            'unknown': 0,
            'candidate': 1,
            'building': 2,
            'road': 3,
            'water': 4,
            'existing_green': 5
        }
        
        # Map land use to integers
        coded_map = np.zeros((self.n_rows, self.n_cols))
        for i in range(self.n_rows):
            for j in range(self.n_cols):
                coded_map[i, j] = land_use_codes.get(str(self.land_use[i, j]), 0)
        
        cmap = LinearSegmentedColormap.from_list(
            'land_use',
            ['gray', 'lightgreen', 'brown', 'black', 'blue', 'darkgreen']
        )
        
        im = ax.imshow(coded_map, cmap=cmap, origin='lower',
                      extent=[self.origin[0],
                             self.origin[0] + self.n_cols * self.cell_size,
                             self.origin[1],
                             self.origin[1] + self.n_rows * self.cell_size])
        
        ax.set_xlabel('X (m)')
        ax.set_ylabel('Y (m)')
        ax.set_title(title)
        
        return ax
    
    def export_metadata(self) -> Dict:
        """
        Export grid metadata for serialization.
        
        Returns:
            Dictionary with grid properties
        """
        return {
            'n_rows': self.n_rows,
            'n_cols': self.n_cols,
            'N': self.N,
            'cell_size': self.cell_size,
            'origin': self.origin,
            'crs': self.crs,
            'extent': {
                'x_min': self.origin[0],
                'x_max': self.origin[0] + self.n_cols * self.cell_size,
                'y_min': self.origin[1],
                'y_max': self.origin[1] + self.n_rows * self.cell_size
            }
        }
    
    def __repr__(self) -> str:
        """String representation."""
        return (f"UrbanGrid(rows={self.n_rows}, cols={self.n_cols}, "
                f"cells={self.N}, size={self.cell_size}m)")


def create_synthetic_grid(n_rows: int = 10, n_cols: int = 10,
                         cell_size: float = 50.0,
                         temp_range: Tuple[float, float] = (25.0, 35.0),
                         candidate_fraction: float = 0.5,
                         random_seed: Optional[int] = None) -> UrbanGrid:
    """
    Create synthetic urban grid for testing.
    
    Generates realistic temperature gradients and random land use distribution.
    
    Args:
        n_rows: Number of grid rows
        n_cols: Number of grid columns
        cell_size: Cell dimension (meters)
        temp_range: Temperature range (min, max) in °C
        candidate_fraction: Fraction of cells available for greening
        random_seed: Random seed for reproducibility
        
    Returns:
        Configured UrbanGrid instance
        
    Example:
        >>> grid = create_synthetic_grid(20, 20, random_seed=42)
        >>> print(f"Candidates: {len(grid.get_candidate_cells())}")
    """
    rng = np.random.default_rng(random_seed)
    
    # Create grid
    grid = UrbanGrid(n_rows, n_cols, cell_size)
    
    # Generate temperature field with spatial correlation
    # Create a "heat island" pattern (higher in center)
    x = np.linspace(-1, 1, n_cols)
    y = np.linspace(-1, 1, n_rows)
    X, Y = np.meshgrid(x, y)
    
    # Radial temperature gradient
    R = np.sqrt(X**2 + Y**2)
    temp_base = temp_range[0] + (temp_range[1] - temp_range[0]) * (1 - R / np.max(R))
    
    # Add random noise
    noise = rng.normal(0, 0.5, (n_rows, n_cols))
    temperature = temp_base + noise
    
    grid.set_temperature_field(temperature)
    
    # Generate land use pattern
    land_use_codes = ['candidate', 'building', 'road', 'existing_green']
    land_use_probs = [candidate_fraction, 0.3, 0.1, 0.1]
    land_use_probs = np.array(land_use_probs)
    land_use_probs = land_use_probs / land_use_probs.sum()  # Normalize
    
    land_use = rng.choice(land_use_codes, size=(n_rows, n_cols), p=land_use_probs)
    grid.set_land_use(land_use)
    
    # Set population (higher in center)
    population = (1000 * (1 - R / np.max(R)) + rng.uniform(0, 100, (n_rows, n_cols))).astype(int)
    grid.population = population
    
    return grid
