"""
Solver Integration Module

Provides unified interface for all QUBO solvers in the UHI-QUBO framework.
"""

from core.solver_integration.solver_interface import (
    SolverInterface,
    SolutionResult,
    SimulatedAnnealingSolver,
    TabuSearchSolver,
    GeneticAlgorithmSolver,
    SimulatedQuantumAnnealingSolver,
    create_solver
)

__all__ = [
    'SolverInterface',
    'SolutionResult',
    'SimulatedAnnealingSolver',
    'TabuSearchSolver',
    'GeneticAlgorithmSolver',
    'SimulatedQuantumAnnealingSolver',
    'create_solver'
]
