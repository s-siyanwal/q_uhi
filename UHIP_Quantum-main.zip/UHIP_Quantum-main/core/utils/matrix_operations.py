"""
Matrix Operations for UHI-QUBO Framework
Specialized matrix operations for QUBO problems
"""

import numpy as np
from scipy import sparse
from typing import Tuple, Optional


def create_symmetric_qubo_matrix(n: int, density: float = 1.0, 
                                 rng: Optional[np.random.Generator] = None) -> np.ndarray:
    """
    Create a random symmetric QUBO matrix.
    
    Args:
        n: Matrix dimension
        density: Fraction of non-zero off-diagonal elements
        rng: Random number generator
        
    Returns:
        Symmetric n x n matrix
    """
    if rng is None:
        rng = np.random.default_rng()
    
    Q = np.zeros((n, n))
    
    # Diagonal elements
    Q[np.diag_indices(n)] = rng.standard_normal(n)
    
    # Off-diagonal elements (upper triangle)
    mask = rng.random((n, n)) < density
    mask = np.triu(mask, k=1)  # Only upper triangle
    
    upper_values = rng.standard_normal((n, n))
    Q[mask] = upper_values[mask]
    
    # Make symmetric
    Q = Q + Q.T
    
    return Q


def verify_qubo_matrix(Q: np.ndarray, tol: float = 1e-10) -> Tuple[bool, str]:
    """
    Verify that a matrix is a valid QUBO matrix.
    
    Mathematical verification:
    - Q must be square
    - Q must be symmetric (Q = Q^T)
    
    Reference: Definition II.1 (QUBO formulation)
    
    Args:
        Q: Matrix to verify
        tol: Tolerance for symmetry check
        
    Returns:
        (is_valid, error_message)
    """
    # Check if square
    if Q.ndim != 2:
        return False, "Matrix must be 2-dimensional"
    
    if Q.shape[0] != Q.shape[1]:
        return False, f"Matrix must be square, got shape {Q.shape}"
    
    # Check symmetry
    if not np.allclose(Q, Q.T, atol=tol):
        max_asymmetry = np.max(np.abs(Q - Q.T))
        return False, f"Matrix is not symmetric, max asymmetry = {max_asymmetry}"
    
    return True, "Valid QUBO matrix"


def add_penalty_to_qubo(Q: np.ndarray, constraint_matrix: np.ndarray, 
                        penalty_weight: float) -> np.ndarray:
    """
    Add penalty terms to QUBO matrix for constraint enforcement.
    
    Mathematical basis: Q_total = Q_original + P * Q_penalty
    
    Args:
        Q: Original QUBO matrix
        constraint_matrix: Penalty term matrix (must be symmetric)
        penalty_weight: Penalty coefficient P
        
    Returns:
        Modified QUBO matrix
        
    Raises:
        ValueError: If matrices have incompatible shapes
    """
    if Q.shape != constraint_matrix.shape:
        raise ValueError(f"Shape mismatch: Q is {Q.shape}, constraint_matrix is {constraint_matrix.shape}")
    
    # Verify constraint_matrix is symmetric
    if not np.allclose(constraint_matrix, constraint_matrix.T):
        constraint_matrix = (constraint_matrix + constraint_matrix.T) / 2
    
    return Q + penalty_weight * constraint_matrix


def extract_diagonal_and_interactions(Q: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    Extract diagonal and off-diagonal parts of QUBO matrix.
    
    Useful for separate analysis of linear and quadratic terms:
    E(x) = Σ_i h_i x_i + Σ_{i<j} J_ij x_i x_j
    
    Args:
        Q: QUBO matrix
        
    Returns:
        (h, J) where h is diagonal, J is strictly upper triangular
    """
    h = np.diag(Q).copy()
    J = np.triu(Q, k=1).copy()
    
    return h, J


def qubo_to_upper_triangular(Q: np.ndarray) -> np.ndarray:
    """
    Convert symmetric QUBO to upper triangular form.
    
    Combines diagonal and off-diagonal contributions:
    - Diagonal stays as is
    - Off-diagonal Q_ij + Q_ji → 2*Q_ij in upper triangle
    
    Args:
        Q: Symmetric QUBO matrix
        
    Returns:
        Upper triangular matrix
    """
    Q_upper = np.triu(Q.copy())
    
    # Add contributions from lower triangle to upper
    for i in range(Q.shape[0]):
        for j in range(i+1, Q.shape[1]):
            Q_upper[i, j] = Q[i, j] + Q[j, i]
    
    return Q_upper


def sparse_qubo_to_dict(Q: np.ndarray, threshold: float = 1e-12) -> dict:
    """
    Convert QUBO matrix to dictionary representation.
    
    Format: {(i, j): Q_ij} for non-zero elements
    Useful for sparse storage and D-Wave compatibility
    
    Args:
        Q: QUBO matrix
        threshold: Threshold for considering values as zero
        
    Returns:
        Dictionary of non-zero elements
    """
    qubo_dict = {}
    
    for i in range(Q.shape[0]):
        for j in range(i, Q.shape[1]):
            if abs(Q[i, j]) > threshold:
                qubo_dict[(i, j)] = Q[i, j]
    
    return qubo_dict


def dict_to_qubo_matrix(qubo_dict: dict, n: Optional[int] = None) -> np.ndarray:
    """
    Convert dictionary QUBO representation to matrix.
    
    Args:
        qubo_dict: Dictionary {(i, j): value}
        n: Matrix size (if None, inferred from max index)
        
    Returns:
        QUBO matrix
    """
    if n is None:
        max_index = max(max(i, j) for i, j in qubo_dict.keys())
        n = max_index + 1
    
    Q = np.zeros((n, n))
    
    for (i, j), value in qubo_dict.items():
        Q[i, j] = value
        if i != j:
            Q[j, i] = value  # Ensure symmetry
    
    return Q


def estimate_qubo_energy_range(Q: np.ndarray) -> Tuple[float, float]:
    """
    Estimate the range of possible energies for a QUBO problem.
    
    Uses eigenvalue analysis for rough bounds:
    - E_min_approx ≈ sum of negative eigenvalues
    - E_max_approx ≈ sum of positive eigenvalues
    
    Args:
        Q: QUBO matrix
        
    Returns:
        (min_energy_estimate, max_energy_estimate)
    """
    eigenvalues = np.linalg.eigvalsh(Q)
    
    e_min = np.sum(eigenvalues[eigenvalues < 0])
    e_max = np.sum(eigenvalues[eigenvalues > 0])
    
    return e_min, e_max


def compute_qubo_statistics(Q: np.ndarray) -> dict:
    """
    Compute various statistics about a QUBO matrix.
    
    Args:
        Q: QUBO matrix
        
    Returns:
        Dictionary of statistics
    """
    stats = {
        'size': Q.shape[0],
        'is_symmetric': np.allclose(Q, Q.T),
        'num_nonzero': np.count_nonzero(Q),
        'density': np.count_nonzero(Q) / Q.size,
        'min_value': np.min(Q),
        'max_value': np.max(Q),
        'mean_value': np.mean(Q),
        'frobenius_norm': np.linalg.norm(Q, 'fro'),
        'spectral_norm': np.linalg.norm(Q, 2),
        'condition_number': np.linalg.cond(Q),
        'trace': np.trace(Q),
    }
    
    eigenvalues = np.linalg.eigvalsh(Q)
    stats['min_eigenvalue'] = np.min(eigenvalues)
    stats['max_eigenvalue'] = np.max(eigenvalues)
    stats['eigenvalue_spread'] = stats['max_eigenvalue'] - stats['min_eigenvalue']
    
    return stats
