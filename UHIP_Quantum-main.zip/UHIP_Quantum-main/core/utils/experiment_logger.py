"""
Experiment Logging and Tracking for UHI-QUBO Framework
"""

import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List
import numpy as np


class ExperimentLogger:
    """
    Comprehensive logging for UHI-QUBO experiments.
    
    Tracks:
    - Problem configuration
    - Solver parameters
    - Solution trajectories
    - Performance metrics
    - Validation results
    """
    
    def __init__(self, experiment_name: str, base_dir: str = "data/results"):
        """
        Initialize experiment logger.
        
        Args:
            experiment_name: Name of the experiment
            base_dir: Base directory for storing results
        """
        self.experiment_name = experiment_name
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.exp_id = f"{experiment_name}_{self.timestamp}"
        
        # Create experiment directory
        self.exp_dir = Path(base_dir) / self.exp_id
        self.exp_dir.mkdir(parents=True, exist_ok=True)
        
        # Subdirectories
        self.figures_dir = self.exp_dir / "figures"
        self.figures_dir.mkdir(exist_ok=True)
        
        # Initialize logger
        self.logger = self._setup_logger()
        
        # Storage for metrics
        self.metrics = {
            'energy_history': [],
            'temperature_history': [],
            'acceptance_rate_history': [],
            'best_solution_history': [],
            'iteration_times': [],
        }
        
        # Metadata
        self.metadata = {
            'experiment_name': experiment_name,
            'timestamp': self.timestamp,
            'exp_id': self.exp_id,
        }
        
        self.logger.info(f"Experiment logger initialized: {self.exp_id}")
    
    def _setup_logger(self) -> logging.Logger:
        """Set up Python logger for console and file output."""
        logger = logging.getLogger(self.exp_id)
        logger.setLevel(logging.DEBUG)
        
        # File handler
        fh = logging.FileHandler(self.exp_dir / "experiment.log")
        fh.setLevel(logging.DEBUG)
        
        # Console handler
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        
        logger.addHandler(fh)
        logger.addHandler(ch)
        
        return logger
    
    def log_problem_config(self, problem_config: Dict[str, Any]):
        """Log problem configuration."""
        self.metadata['problem_config'] = problem_config
        self.logger.info(f"Problem configuration: {problem_config}")
        
        with open(self.exp_dir / "problem_config.json", 'w') as f:
            json.dump(problem_config, f, indent=2, default=str)
    
    def log_solver_config(self, solver_config: Dict[str, Any]):
        """Log solver configuration."""
        self.metadata['solver_config'] = solver_config
        self.logger.info(f"Solver configuration: {solver_config}")
        
        with open(self.exp_dir / "solver_config.json", 'w') as f:
            json.dump(solver_config, f, indent=2, default=str)
    
    def log_qubo_matrix(self, Q: np.ndarray):
        """Save QUBO matrix."""
        np.save(self.exp_dir / "qubo_matrix.npy", Q)
        
        # Also save statistics
        from core.utils.matrix_operations import compute_qubo_statistics
        stats = compute_qubo_statistics(Q)
        
        with open(self.exp_dir / "qubo_statistics.json", 'w') as f:
            json.dump(stats, f, indent=2, default=str)
        
        self.logger.info(f"QUBO matrix saved: shape {Q.shape}, density {stats['density']:.4f}")
    
    def log_iteration(self, iteration: int, energy: float, temperature: Optional[float] = None,
                     accepted: Optional[bool] = None, best_energy: Optional[float] = None):
        """
        Log a single iteration.
        
        Args:
            iteration: Iteration number
            energy: Current energy
            temperature: Current temperature (if applicable)
            accepted: Whether move was accepted (if applicable)
            best_energy: Best energy so far
        """
        self.metrics['energy_history'].append(energy)
        
        if temperature is not None:
            self.metrics['temperature_history'].append(temperature)
        
        if best_energy is not None:
            self.metrics['best_solution_history'].append(best_energy)
        
        # Log periodically
        if iteration % 100 == 0 or iteration < 10:
            log_msg = f"Iteration {iteration}: E={energy:.4f}"
            if temperature is not None:
                log_msg += f", T={temperature:.4f}"
            if best_energy is not None:
                log_msg += f", Best={best_energy:.4f}"
            self.logger.debug(log_msg)
    
    def log_solution(self, solution: np.ndarray, energy: float, 
                    is_feasible: bool, metadata: Optional[Dict] = None):
        """
        Log a solution.
        
        Args:
            solution: Binary solution vector
            energy: Energy of solution
            is_feasible: Whether solution satisfies constraints
            metadata: Additional metadata
        """
        solution_data = {
            'solution': solution.tolist(),
            'energy': float(energy),
            'is_feasible': is_feasible,
            'num_ones': int(np.sum(solution)),
            'timestamp': datetime.now().isoformat(),
        }
        
        if metadata:
            solution_data.update(metadata)
        
        with open(self.exp_dir / "final_solution.json", 'w') as f:
            json.dump(solution_data, f, indent=2)
        
        np.save(self.exp_dir / "final_solution.npy", solution)
        
        self.logger.info(f"Final solution: E={energy:.4f}, feasible={is_feasible}, "
                        f"num_ones={np.sum(solution)}")
    
    def log_performance_metrics(self, metrics: Dict[str, Any]):
        """Log performance metrics."""
        self.metadata['performance_metrics'] = metrics
        
        with open(self.exp_dir / "performance_metrics.json", 'w') as f:
            json.dump(metrics, f, indent=2, default=str)
        
        self.logger.info(f"Performance metrics: {metrics}")
    
    def save_convergence_data(self):
        """Save convergence data to CSV."""
        import pandas as pd
        
        df_data = {'iteration': list(range(len(self.metrics['energy_history'])))}
        
        if self.metrics['energy_history']:
            df_data['energy'] = self.metrics['energy_history']
        
        if self.metrics['temperature_history']:
            df_data['temperature'] = self.metrics['temperature_history']
        
        if self.metrics['best_solution_history']:
            df_data['best_energy'] = self.metrics['best_solution_history']
        
        df = pd.DataFrame(df_data)
        df.to_csv(self.exp_dir / "convergence.csv", index=False)
        
        self.logger.info("Convergence data saved to CSV")
    
    def finalize(self):
        """Finalize experiment and save all metadata."""
        self.save_convergence_data()
        
        # Save complete metadata
        with open(self.exp_dir / "metadata.json", 'w') as f:
            json.dump(self.metadata, f, indent=2, default=str)
        
        self.logger.info(f"Experiment finalized: {self.exp_dir}")
        
        # Close handlers
        for handler in self.logger.handlers[:]:
            handler.close()
            self.logger.removeHandler(handler)
    
    def get_experiment_dir(self) -> Path:
        """Get experiment directory path."""
        return self.exp_dir
    
    def get_figures_dir(self) -> Path:
        """Get figures directory path."""
        return self.figures_dir
