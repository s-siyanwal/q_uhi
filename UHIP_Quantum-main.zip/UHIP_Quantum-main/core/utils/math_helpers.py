"""
Mathematical Helper Functions for UHI-QUBO Framework
Provides basic mathematical operations and utilities
"""

import numpy as np
from typing import Tuple, Optional
from scipy.special import expit


def ensure_symmetric(matrix: np.ndarray, tol: float = 1e-10) -> np.ndarray:
    """
    Ensure a matrix is symmetric by averaging with its transpose.
    
    Args:
        matrix: Input matrix
        tol: Tolerance for symmetry check
        
    Returns:
        Symmetric matrix
        
    Raises:
        ValueError: If matrix is not square
    """
    if matrix.shape[0] != matrix.shape[1]:
        raise ValueError("Matrix must be square")
    
    # Check if already symmetric
    if np.allclose(matrix, matrix.T, atol=tol):
        return matrix
    
    # Make symmetric
    return (matrix + matrix.T) / 2


def sigmoid(x: np.ndarray, scale: float = 1.0) -> np.ndarray:
    """
    Sigmoid function for probabilistic calculations.
    
    Args:
        x: Input values
        scale: Scaling factor
        
    Returns:
        Sigmoid transformed values
    """
    return expit(x / scale)


def metropolis_acceptance_probability(delta_energy: float, temperature: float) -> float:
    """
    Calculate Metropolis acceptance probability.
    
    Mathematical basis: P_accept = min(1, exp(-ΔE/T))
    
    Args:
        delta_energy: Energy change (E_new - E_old)
        temperature: Current temperature
        
    Returns:
        Acceptance probability in [0, 1]
        
    Note:
        When temperature = 0 and delta_energy = 0 (undefined form 0/0),
        we return 1.0 following the limit lim_{T→0} exp(-0/T) = 1.
    """
    if delta_energy <= 0:
        return 1.0
    if temperature <= 0:
        # At T=0, only accept improvements (delta_energy < 0)
        # If we reach here, delta_energy > 0, so reject
        return 0.0
    return np.exp(-delta_energy / temperature)


def cooling_schedule_exponential(initial_temp: float, alpha: float, iteration: int) -> float:
    """
    Exponential cooling schedule for simulated annealing.
    
    T(t) = T_0 * alpha^t
    
    Args:
        initial_temp: Initial temperature
        alpha: Cooling rate (typically 0.85-0.99)
        iteration: Current iteration
        
    Returns:
        Temperature at iteration
    """
    return initial_temp * (alpha ** iteration)


def cooling_schedule_logarithmic(initial_temp: float, iteration: int) -> float:
    """
    Logarithmic cooling schedule.
    
    T(t) = T_0 / log(1 + t)
    
    Args:
        initial_temp: Initial temperature
        iteration: Current iteration
        
    Returns:
        Temperature at iteration
    """
    return initial_temp / np.log(2 + iteration)


def calculate_energy_from_qubo(x: np.ndarray, Q: np.ndarray) -> float:
    """
    Calculate energy E = x^T Q x for QUBO problem.
    
    Mathematical basis: QUBO objective function
    Reference: Definition II.1
    
    Args:
        x: Binary vector
        Q: QUBO matrix (symmetric)
        
    Returns:
        Energy value
        
    Raises:
        ValueError: If dimensions don't match or x is not binary
    """
    if x.shape[0] != Q.shape[0]:
        raise ValueError(f"Dimension mismatch: x has {x.shape[0]} elements, Q is {Q.shape[0]}x{Q.shape[1]}")
    
    if not np.all(np.logical_or(x == 0, x == 1)):
        raise ValueError("x must be a binary vector")
    
    return float(x.T @ Q @ x)


def calculate_delta_energy_single_flip(x: np.ndarray, Q: np.ndarray, flip_index: int) -> float:
    """
    Calculate energy change for flipping a single bit.
    
    Efficient computation using:
    ΔE = (2x_i - 1) * (2 * Σ_j Q_ij x_j)
    
    Args:
        x: Current binary vector
        Q: QUBO matrix
        flip_index: Index of bit to flip
        
    Returns:
        Energy change ΔE
    """
    # Current value at flip_index
    current_val = x[flip_index]
    
    # Calculate contribution from all terms involving x_i
    # E = sum_i sum_j Q_ij x_i x_j
    # When flipping x_i: ΔE = (1-x_i)(sum_j Q_ij x_j) - x_i(sum_j Q_ij x_j)
    # = (1-2x_i)(sum_j Q_ij x_j)
    contribution = Q[flip_index, :] @ x + Q[:, flip_index] @ x - Q[flip_index, flip_index] * current_val
    delta_e = (1 - 2 * current_val) * contribution
    
    return float(delta_e)


def hamming_distance(x1: np.ndarray, x2: np.ndarray) -> int:
    """
    Calculate Hamming distance between two binary vectors.
    
    Args:
        x1: First binary vector
        x2: Second binary vector
        
    Returns:
        Number of differing bits
    """
    return int(np.sum(x1 != x2))


def generate_random_binary_vector(n: int, sparsity: Optional[float] = None, 
                                  rng: Optional[np.random.Generator] = None) -> np.ndarray:
    """
    Generate a random binary vector.
    
    Args:
        n: Vector length
        sparsity: Fraction of 1s (if None, use 0.5)
        rng: Random number generator
        
    Returns:
        Random binary vector
    """
    if rng is None:
        rng = np.random.default_rng()
    
    if sparsity is None:
        return rng.integers(0, 2, size=n)
    else:
        p = sparsity
        return (rng.random(n) < p).astype(int)
