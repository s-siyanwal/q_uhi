"""
Backend Interface for Quantum Circuit Execution

Provides unified interface for executing quantum circuits on different backends:
- Qiskit Aer simulators (statevector, qasm)
- Abstract interface for other backends (IBM Quantum, etc.)

Features:
- Shot-based sampling
- Result extraction and post-processing
- Measurement statistics
- Backend configuration management

Reference: Section 09 (Quantum Circuit Implementation) from framework documents
"""

import numpy as np
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
from abc import ABC, abstractmethod

try:
    from qiskit import QuantumCircuit, transpile
    from qiskit_aer import AerSimulator
    from qiskit.result import Result as QiskitResult
    from qiskit.providers import Backend
except ImportError:
    raise ImportError("Qiskit and Qiskit Aer not installed. Run: pip install qiskit qiskit-aer")


@dataclass
class MeasurementResult:
    """
    Container for quantum measurement results.
    
    Attributes:
        counts: Dictionary of bitstring outcomes and their counts
        shots: Total number of shots
        quasi_probabilities: Normalized probabilities for each outcome
        most_frequent: Most frequently measured bitstring
        expectation_value: Optional expectation value ⟨H⟩
        metadata: Additional information
    """
    counts: Dict[str, int]
    shots: int
    quasi_probabilities: Dict[str, float]
    most_frequent: str
    expectation_value: Optional[float] = None
    metadata: Dict[str, Any] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'counts': self.counts,
            'shots': self.shots,
            'quasi_probabilities': self.quasi_probabilities,
            'most_frequent': self.most_frequent,
            'expectation_value': self.expectation_value,
            'metadata': self.metadata or {}
        }


class QuantumBackend(ABC):
    """
    Abstract base class for quantum backends.
    
    Provides unified interface for executing quantum circuits
    on different simulators and hardware.
    """
    
    @abstractmethod
    def execute(
        self, 
        circuit: QuantumCircuit, 
        shots: int = 1024,
        **kwargs
    ) -> MeasurementResult:
        """
        Execute quantum circuit and return measurement results.
        
        Args:
            circuit: Quantum circuit to execute
            shots: Number of measurement shots
            **kwargs: Backend-specific options
            
        Returns:
            MeasurementResult with outcome statistics
        """
        pass
    
    @abstractmethod
    def get_backend_info(self) -> Dict[str, Any]:
        """
        Get backend information and capabilities.
        
        Returns:
            Dictionary with backend metadata
        """
        pass


class QiskitSimulatorBackend(QuantumBackend):
    """
    Qiskit Aer simulator backend.
    
    Supports multiple simulation methods:
    - statevector: Exact statevector simulation (no noise)
    - qasm: Shot-based simulation with optional noise
    - stabilizer: Efficient Clifford circuit simulation
    
    Features:
    - Configurable shot count
    - Optional noise models
    - Measurement error mitigation
    - Parallel execution
    
    Usage:
        >>> backend = QiskitSimulatorBackend(method='qasm', shots=1024)
        >>> result = backend.execute(circuit)
        >>> print(result.counts)
    """
    
    def __init__(
        self,
        method: str = 'automatic',
        shots: int = 1024,
        seed_simulator: Optional[int] = None,
        optimization_level: int = 1,
        noise_model: Optional[Any] = None
    ):
        """
        Initialize Qiskit Aer backend.
        
        Args:
            method: Simulation method ('automatic', 'statevector', 'stabilizer', 'density_matrix')
            shots: Default number of shots
            seed_simulator: Random seed for reproducibility
            optimization_level: Transpiler optimization level (0-3)
            noise_model: Optional noise model for realistic simulation
        """
        self.method = method
        self.default_shots = shots
        self.seed_simulator = seed_simulator
        self.optimization_level = optimization_level
        self.noise_model = noise_model
        
        # Initialize Aer simulator
        self.simulator = AerSimulator(method=method)
    
    def execute(
        self,
        circuit: QuantumCircuit,
        shots: Optional[int] = None,
        add_measurements: bool = True,
        **kwargs
    ) -> MeasurementResult:
        """
        Execute circuit on Qiskit Aer simulator.
        
        Args:
            circuit: Quantum circuit to execute
            shots: Number of shots (uses default if None)
            add_measurements: Auto-add measurements if not present
            **kwargs: Additional execution options
            
        Returns:
            MeasurementResult with measurement statistics
        """
        if shots is None:
            shots = self.default_shots
        
        # Add measurements if needed
        if add_measurements and circuit.num_clbits == 0:
            circuit = circuit.copy()
            circuit.measure_all()
        
        # Transpile circuit for backend
        transpiled_circuit = transpile(
            circuit,
            self.simulator,
            optimization_level=self.optimization_level,
            seed_transpiler=self.seed_simulator
        )
        
        # Execute with options
        job = self.simulator.run(
            transpiled_circuit,
            shots=shots,
            seed_simulator=self.seed_simulator,
            noise_model=self.noise_model,
            **kwargs
        )
        
        # Get results
        result = job.result()
        counts = result.get_counts()
        
        # Process results
        return self._process_results(counts, shots, result)
    
    def _process_results(
        self,
        counts: Dict[str, int],
        shots: int,
        qiskit_result: QiskitResult
    ) -> MeasurementResult:
        """
        Process raw Qiskit results into MeasurementResult.
        
        Args:
            counts: Raw measurement counts
            shots: Number of shots
            qiskit_result: Raw Qiskit result object
            
        Returns:
            Processed MeasurementResult
        """
        # Normalize to probabilities
        quasi_probs = {
            bitstring: count / shots
            for bitstring, count in counts.items()
        }
        
        # Find most frequent outcome
        most_frequent = max(counts.items(), key=lambda x: x[1])[0]
        
        # Extract metadata
        metadata = {
            'success': qiskit_result.success,
            'simulation_method': self.method,
            'time_taken': qiskit_result.time_taken,
        }
        
        return MeasurementResult(
            counts=counts,
            shots=shots,
            quasi_probabilities=quasi_probs,
            most_frequent=most_frequent,
            metadata=metadata
        )
    
    def sample_bitstrings(
        self,
        circuit: QuantumCircuit,
        n_samples: int = 1
    ) -> List[str]:
        """
        Sample bitstrings from circuit measurement distribution.
        
        Args:
            circuit: Quantum circuit
            n_samples: Number of samples to draw
            
        Returns:
            List of bitstring samples
        """
        result = self.execute(circuit, shots=n_samples)
        
        # Convert counts to samples
        samples = []
        for bitstring, count in result.counts.items():
            samples.extend([bitstring] * count)
        
        return samples[:n_samples]
    
    def compute_expectation(
        self,
        circuit: QuantumCircuit,
        pauli_string: str,
        shots: int = 1024
    ) -> float:
        """
        Compute expectation value of Pauli operator.
        
        ⟨P⟩ = Σ_x (-1)^{parity(x)} P(x)
        
        Args:
            circuit: Quantum circuit (without measurements)
            pauli_string: Pauli operator string (e.g., 'ZZI', 'XIY')
            shots: Number of measurement shots
            
        Returns:
            Expectation value
        """
        n_qubits = circuit.num_qubits
        
        if len(pauli_string) != n_qubits:
            raise ValueError(f"Pauli string length {len(pauli_string)} != n_qubits {n_qubits}")
        
        # Add measurement basis rotations
        meas_circuit = circuit.copy()
        meas_circuit.barrier()
        
        for i, pauli in enumerate(pauli_string):
            if pauli == 'X':
                meas_circuit.h(i)
            elif pauli == 'Y':
                meas_circuit.sdg(i)
                meas_circuit.h(i)
            elif pauli == 'I':
                continue
            # Z measurement is default
        
        # Execute
        result = self.execute(meas_circuit, shots=shots)
        
        # Compute expectation value
        expectation = 0.0
        for bitstring, prob in result.quasi_probabilities.items():
            # Compute parity for non-identity Paulis
            parity = 0
            for i, pauli in enumerate(pauli_string):
                if pauli != 'I':
                    # Qiskit uses little-endian bitstring ordering
                    bit = int(bitstring[-(i+1)])
                    parity ^= bit
            
            # Add contribution: (-1)^parity * probability
            sign = 1 if parity == 0 else -1
            expectation += sign * prob
        
        return expectation
    
    def get_backend_info(self) -> Dict[str, Any]:
        """
        Get simulator backend information.
        
        Returns:
            Backend metadata
        """
        return {
            'name': 'QiskitAerSimulator',
            'method': self.method,
            'default_shots': self.default_shots,
            'seed_simulator': self.seed_simulator,
            'optimization_level': self.optimization_level,
            'has_noise_model': self.noise_model is not None,
            'max_qubits': 30,  # Typical Aer limit depends on memory
            'simulator_type': 'classical_simulation'
        }


class BackendManager:
    """
    Manager for multiple quantum backends.
    
    Provides centralized access to different backends and
    automatic backend selection based on circuit properties.
    
    Features:
    - Backend registration and retrieval
    - Automatic backend selection
    - Result caching (optional)
    - Performance monitoring
    
    Usage:
        >>> manager = BackendManager()
        >>> manager.register_backend('aer_qasm', QiskitSimulatorBackend())
        >>> result = manager.execute(circuit, backend_name='aer_qasm')
    """
    
    def __init__(self):
        """Initialize backend manager."""
        self.backends: Dict[str, QuantumBackend] = {}
        self.default_backend: Optional[str] = None
    
    def register_backend(
        self,
        name: str,
        backend: QuantumBackend,
        set_default: bool = False
    ):
        """
        Register a quantum backend.
        
        Args:
            name: Backend identifier
            backend: QuantumBackend instance
            set_default: Set as default backend
        """
        self.backends[name] = backend
        
        if set_default or self.default_backend is None:
            self.default_backend = name
    
    def get_backend(self, name: Optional[str] = None) -> QuantumBackend:
        """
        Get backend by name.
        
        Args:
            name: Backend name (uses default if None)
            
        Returns:
            QuantumBackend instance
            
        Raises:
            ValueError: If backend not found
        """
        if name is None:
            name = self.default_backend
        
        if name is None:
            raise ValueError("No default backend set")
        
        if name not in self.backends:
            raise ValueError(f"Backend '{name}' not registered. Available: {list(self.backends.keys())}")
        
        return self.backends[name]
    
    def execute(
        self,
        circuit: QuantumCircuit,
        backend_name: Optional[str] = None,
        shots: int = 1024,
        **kwargs
    ) -> MeasurementResult:
        """
        Execute circuit on specified backend.
        
        Args:
            circuit: Quantum circuit
            backend_name: Backend to use (default if None)
            shots: Number of shots
            **kwargs: Backend-specific options
            
        Returns:
            MeasurementResult
        """
        backend = self.get_backend(backend_name)
        return backend.execute(circuit, shots=shots, **kwargs)
    
    def list_backends(self) -> List[str]:
        """
        List available backends.
        
        Returns:
            List of backend names
        """
        return list(self.backends.keys())
    
    def get_backend_info(self, name: Optional[str] = None) -> Dict[str, Any]:
        """
        Get information about a backend.
        
        Args:
            name: Backend name (default if None)
            
        Returns:
            Backend information dictionary
        """
        backend = self.get_backend(name)
        return backend.get_backend_info()


def create_default_backend_manager() -> BackendManager:
    """
    Create BackendManager with standard Qiskit simulators.
    
    Registers:
    - 'aer': Automatic simulator (default, shot-based)
    - 'statevector': Statevector simulator (exact)
    
    Returns:
        Configured BackendManager
        
    Example:
        >>> manager = create_default_backend_manager()
        >>> result = manager.execute(circuit, backend_name='aer')
    """
    manager = BackendManager()
    
    # Register automatic simulator (default)
    aer_backend = QiskitSimulatorBackend(
        method='automatic',
        shots=1024
    )
    manager.register_backend('aer', aer_backend, set_default=True)
    
    # Register statevector simulator
    statevector_backend = QiskitSimulatorBackend(
        method='statevector',
        shots=1
    )
    manager.register_backend('statevector', statevector_backend)
    
    return manager


__all__ = [
    'QuantumBackend',
    'QiskitSimulatorBackend',
    'BackendManager',
    'MeasurementResult',
    'create_default_backend_manager'
]
