"""
Noise Mitigation and Error Correction for Quantum Circuits

Implements error mitigation techniques for near-term quantum devices:
- Zero-noise extrapolation
- Measurement error mitigation
- Readout error correction
- Probabilistic error cancellation

These techniques reduce errors without requiring full quantum error correction,
making them suitable for NISQ (Noisy Intermediate-Scale Quantum) devices.

Reference: Section 09 (Quantum Circuit Implementation) from framework documents
           Temme et al., "Error Mitigation for Short-Depth Quantum Circuits" (2017)
"""

import numpy as np
from typing import Dict, List, Optional, Tuple, Callable, Any
from dataclasses import dataclass

try:
    from qiskit import QuantumCircuit, transpile
    from qiskit.result import Result as QiskitResult
except ImportError:
    raise ImportError("Qiskit not installed. Run: pip install qiskit")


@dataclass
class MitigationResult:
    """
    Result after error mitigation.
    
    Attributes:
        mitigated_expectation: Error-mitigated expectation value
        raw_expectation: Unmitigated expectation value
        error_reduction: Estimated error reduction
        mitigation_overhead: Computational overhead factor
        metadata: Additional information
    """
    mitigated_expectation: float
    raw_expectation: float
    error_reduction: float
    mitigation_overhead: float
    metadata: Dict[str, Any]


class ZeroNoiseExtrapolation:
    """
    Zero-Noise Extrapolation (ZNE) for error mitigation.
    
    ZNE works by:
    1. Running circuits at different noise levels (noise scaling)
    2. Measuring expectation values at each noise level
    3. Extrapolating to zero-noise limit
    
    Mathematical Framework:
    For observable O with true expectation ⟨O⟩_ideal and noisy ⟨O⟩(λ):
    
    ⟨O⟩(λ) ≈ ⟨O⟩_ideal + c₁λ + c₂λ² + ...
    
    By measuring at multiple λ values, we extrapolate to λ=0.
    
    Noise Scaling Methods:
    - unitary_folding: Replace U → U U† U (increases gate count)
    - pulse_stretching: Increase gate duration (hardware-dependent)
    
    Extrapolation Models:
    - linear: E(λ) = a + bλ
    - exponential: E(λ) = a + b exp(cλ)
    - polynomial: E(λ) = Σ aᵢλⁱ
    
    Reference: Temme et al. (2017), Li & Benjamin (2017)
    """
    
    def __init__(
        self,
        scale_factors: Optional[List[float]] = None,
        extrapolation_model: str = 'linear'
    ):
        """
        Initialize ZNE mitigator.
        
        Args:
            scale_factors: Noise scaling factors (default: [1, 2, 3])
            extrapolation_model: Model for extrapolation ('linear', 'exponential', 'polynomial')
        """
        self.scale_factors = scale_factors or [1.0, 2.0, 3.0]
        self.extrapolation_model = extrapolation_model
    
    def apply_unitary_folding(
        self,
        circuit: QuantumCircuit,
        scale_factor: float
    ) -> QuantumCircuit:
        """
        Scale noise by folding circuit.
        
        For scale factor s = 2k+1 (odd integer):
        U → U (U† U)^k
        
        This increases the circuit depth and noise proportionally.
        
        Args:
            circuit: Original circuit
            scale_factor: Noise scaling (must be odd integer ≥ 1)
            
        Returns:
            Folded circuit with increased noise
        """
        # Convert to integer and validate
        scale_int = int(scale_factor)
        if scale_int < 1 or scale_int != scale_factor or scale_int % 2 == 0:
            raise ValueError(f"Scale factor must be odd integer ≥ 1, got {scale_factor}")
        
        if scale_int == 1:
            return circuit.copy()
        
        # Create folded circuit: U (U† U)^k
        folded = circuit.copy()
        
        num_folds = (scale_int - 1) // 2
        for _ in range(num_folds):
            # Add U† U
            folded.compose(circuit.inverse(), inplace=True)
            folded.compose(circuit, inplace=True)
        
        return folded
    
    def extrapolate_to_zero_noise(
        self,
        scale_factors: List[float],
        expectation_values: List[float]
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Extrapolate expectation values to zero-noise limit.
        
        Args:
            scale_factors: Noise scale factors
            expectation_values: Measured expectation values
            
        Returns:
            (zero_noise_value, fit_metadata)
        """
        if len(scale_factors) != len(expectation_values):
            raise ValueError("Scale factors and expectation values must have same length")
        
        scale_factors = np.array(scale_factors)
        expectation_values = np.array(expectation_values)
        
        if self.extrapolation_model == 'linear':
            # Linear fit: E(λ) = a + bλ
            # Extrapolate to λ=0: E(0) = a
            coeffs = np.polyfit(scale_factors, expectation_values, deg=1)
            zero_noise = coeffs[1]  # Intercept
            
            metadata = {
                'model': 'linear',
                'coefficients': coeffs.tolist(),
                'fit_quality': self._compute_r_squared(scale_factors, expectation_values, coeffs)
            }
        
        elif self.extrapolation_model == 'exponential':
            # Exponential fit: E(λ) = a + b exp(cλ)
            # Use log transformation for fitting
            from scipy.optimize import curve_fit
            
            def exp_model(x, a, b, c):
                return a + b * np.exp(c * x)
            
            try:
                popt, _ = curve_fit(exp_model, scale_factors, expectation_values)
                zero_noise = popt[0] + popt[1]  # E(0) = a + b
                
                metadata = {
                    'model': 'exponential',
                    'coefficients': popt.tolist(),
                    'fit_quality': self._compute_r_squared(
                        scale_factors, expectation_values,
                        lambda x: exp_model(x, *popt)
                    )
                }
            except:
                # Fallback to linear if exponential fit fails
                return self.extrapolate_to_zero_noise(
                    scale_factors.tolist(),
                    expectation_values.tolist()
                )
        
        elif self.extrapolation_model == 'polynomial':
            # Polynomial fit: E(λ) = Σ aᵢλⁱ
            deg = min(len(scale_factors) - 1, 3)
            coeffs = np.polyfit(scale_factors, expectation_values, deg=deg)
            zero_noise = coeffs[-1]  # Constant term
            
            metadata = {
                'model': f'polynomial_deg{deg}',
                'coefficients': coeffs.tolist(),
                'fit_quality': self._compute_r_squared(scale_factors, expectation_values, coeffs)
            }
        
        else:
            raise ValueError(f"Unknown extrapolation model: {self.extrapolation_model}")
        
        return float(zero_noise), metadata
    
    def _compute_r_squared(
        self,
        x: np.ndarray,
        y: np.ndarray,
        model: Any
    ) -> float:
        """
        Compute R² goodness-of-fit.
        
        Args:
            x: Independent variable
            y: Dependent variable (data)
            model: Fitted model (coefficients or function)
            
        Returns:
            R² value
        """
        if callable(model):
            y_pred = model(x)
        else:
            # Polynomial coefficients
            y_pred = np.polyval(model, x)
        
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        
        if ss_tot < 1e-10:
            return 1.0
        
        return float(1 - ss_res / ss_tot)
    
    def mitigate(
        self,
        circuit: QuantumCircuit,
        execute_fn: Callable[[QuantumCircuit], float]
    ) -> MitigationResult:
        """
        Apply ZNE to mitigate errors.
        
        Args:
            circuit: Original circuit
            execute_fn: Function that executes circuit and returns expectation value
            
        Returns:
            MitigationResult with mitigated expectation
        """
        # Measure at different noise scales
        scaled_expectations = []
        
        for scale in self.scale_factors:
            if scale == 1.0:
                # No folding needed
                exp_val = execute_fn(circuit)
            else:
                # Apply unitary folding
                scale_int = int(round(scale))
                if scale_int % 2 == 0:
                    scale_int += 1
                
                folded_circuit = self.apply_unitary_folding(circuit, scale_int)
                exp_val = execute_fn(folded_circuit)
            
            scaled_expectations.append(exp_val)
        
        # Extrapolate to zero noise
        mitigated_exp, fit_metadata = self.extrapolate_to_zero_noise(
            self.scale_factors,
            scaled_expectations
        )
        
        raw_exp = scaled_expectations[0]  # Unmitigated (scale=1)
        
        return MitigationResult(
            mitigated_expectation=mitigated_exp,
            raw_expectation=raw_exp,
            error_reduction=abs(mitigated_exp - raw_exp),
            mitigation_overhead=len(self.scale_factors),
            metadata={
                'scale_factors': self.scale_factors,
                'scaled_expectations': scaled_expectations,
                'extrapolation': fit_metadata
            }
        )


class MeasurementErrorMitigation:
    """
    Measurement (readout) error mitigation.
    
    Measurement errors occur when:
    - |0⟩ is misread as |1⟩ (probability p01)
    - |1⟩ is misread as |0⟩ (probability p10)
    
    Mitigation Strategy:
    1. Calibrate: Measure error rates by preparing |0⟩ and |1⟩
    2. Build calibration matrix M
    3. Invert: Apply M⁻¹ to measured probabilities
    
    Calibration Matrix (for n qubits):
    M[i,j] = P(measure state i | prepared state j)
    
    For 1 qubit:
    M = [[1-p01, p10],
         [p01, 1-p10]]
    
    Corrected probabilities: p_corrected = M⁻¹ p_measured
    
    Reference: Nachman et al., "Unfolding quantum computer readout noise" (2020)
    """
    
    def __init__(self):
        """Initialize measurement error mitigator."""
        self.calibration_matrix: Optional[np.ndarray] = None
        self.n_qubits: Optional[int] = None
    
    def calibrate(
        self,
        execute_fn: Callable[[QuantumCircuit], Dict[str, float]],
        n_qubits: int,
        shots: int = 1024
    ):
        """
        Calibrate measurement errors.
        
        Prepares all computational basis states and measures readout errors.
        
        Args:
            execute_fn: Function to execute circuit and return probability dict
            n_qubits: Number of qubits
            shots: Number of measurement shots per state
        """
        self.n_qubits = n_qubits
        n_states = 2 ** n_qubits
        
        # Initialize calibration matrix
        calibration_matrix = np.zeros((n_states, n_states))
        
        # Prepare each computational basis state
        for state_idx in range(n_states):
            # Create circuit preparing |state_idx⟩
            qc = QuantumCircuit(n_qubits)
            
            # Encode state_idx in binary
            bitstring = format(state_idx, f'0{n_qubits}b')
            for i, bit in enumerate(bitstring):
                if bit == '1':
                    qc.x(i)
            
            # Measure
            probs = execute_fn(qc)
            
            # Fill column of calibration matrix
            for measured_state, prob in probs.items():
                measured_idx = int(measured_state, 2)
                calibration_matrix[measured_idx, state_idx] = prob
        
        self.calibration_matrix = calibration_matrix
    
    def mitigate_counts(
        self,
        counts: Dict[str, int]
    ) -> Dict[str, float]:
        """
        Apply readout error mitigation to measurement counts.
        
        Args:
            counts: Raw measurement counts
            
        Returns:
            Mitigated probability distribution
        """
        if self.calibration_matrix is None:
            raise ValueError("Must calibrate before mitigating")
        
        # Convert counts to probability vector
        total_shots = sum(counts.values())
        n_states = 2 ** self.n_qubits
        
        measured_probs = np.zeros(n_states)
        for bitstring, count in counts.items():
            idx = int(bitstring, 2)
            measured_probs[idx] = count / total_shots
        
        # Apply inverse calibration matrix
        try:
            inv_calib = np.linalg.inv(self.calibration_matrix)
            mitigated_probs = inv_calib @ measured_probs
            
            # Clip negative probabilities (can occur due to numerical errors)
            mitigated_probs = np.clip(mitigated_probs, 0, 1)
            
            # Renormalize
            mitigated_probs /= np.sum(mitigated_probs)
        
        except np.linalg.LinAlgError:
            # Fallback to least-squares if matrix is singular
            mitigated_probs, _, _, _ = np.linalg.lstsq(
                self.calibration_matrix,
                measured_probs,
                rcond=None
            )
            mitigated_probs = np.clip(mitigated_probs, 0, 1)
            mitigated_probs /= np.sum(mitigated_probs)
        
        # Convert back to dictionary
        mitigated_counts = {}
        for idx in range(n_states):
            if mitigated_probs[idx] > 1e-10:
                bitstring = format(idx, f'0{self.n_qubits}b')
                mitigated_counts[bitstring] = float(mitigated_probs[idx])
        
        return mitigated_counts
    
    def mitigate_expectation(
        self,
        counts: Dict[str, int],
        observable_fn: Callable[[str], float]
    ) -> float:
        """
        Compute error-mitigated expectation value.
        
        ⟨O⟩ = Σ_x p(x) O(x)
        
        Args:
            counts: Raw measurement counts
            observable_fn: Function mapping bitstring to observable value
            
        Returns:
            Mitigated expectation value
        """
        mitigated_probs = self.mitigate_counts(counts)
        
        expectation = sum(
            prob * observable_fn(bitstring)
            for bitstring, prob in mitigated_probs.items()
        )
        
        return expectation


class ReadoutErrorCorrection:
    """
    Simple readout error correction for independent qubit errors.
    
    Assumes independent single-qubit readout errors (tensor product model).
    This is more scalable than full calibration matrix but less accurate.
    
    For each qubit i:
    - p0i: Probability of measuring 1 when state is 0
    - p1i: Probability of measuring 0 when state is 1
    """
    
    def __init__(self):
        """Initialize readout error corrector."""
        self.error_rates: Optional[List[Tuple[float, float]]] = None
    
    def calibrate_single_qubit_errors(
        self,
        execute_fn: Callable[[QuantumCircuit], Dict[str, int]],
        n_qubits: int
    ):
        """
        Calibrate single-qubit readout errors.
        
        Args:
            execute_fn: Function to execute circuit and return counts
            n_qubits: Number of qubits
        """
        error_rates = []
        
        for qubit in range(n_qubits):
            # Prepare |0⟩
            qc0 = QuantumCircuit(n_qubits)
            counts0 = execute_fn(qc0)
            
            # Compute p01: P(measure 1 | prepared 0)
            total = sum(counts0.values())
            error_0to1 = sum(
                count for bitstring, count in counts0.items()
                if bitstring[-(qubit+1)] == '1'
            ) / total
            
            # Prepare |1⟩
            qc1 = QuantumCircuit(n_qubits)
            qc1.x(qubit)
            counts1 = execute_fn(qc1)
            
            # Compute p10: P(measure 0 | prepared 1)
            total = sum(counts1.values())
            error_1to0 = sum(
                count for bitstring, count in counts1.items()
                if bitstring[-(qubit+1)] == '0'
            ) / total
            
            error_rates.append((error_0to1, error_1to0))
        
        self.error_rates = error_rates
    
    def correct_bitstring_probability(
        self,
        bitstring: str,
        measured_prob: float
    ) -> float:
        """
        Correct probability of a single bitstring.
        
        Args:
            bitstring: Measured bitstring
            measured_prob: Measured probability
            
        Returns:
            Corrected probability (approximate)
        """
        if self.error_rates is None:
            raise ValueError("Must calibrate before correcting")
        
        # Simple correction: divide by product of error rates
        correction_factor = 1.0
        
        for i, bit in enumerate(bitstring):
            p01, p10 = self.error_rates[i]
            
            if bit == '0':
                # Probability of correctly measuring 0
                correction_factor *= (1 - p01)
            else:
                # Probability of correctly measuring 1
                correction_factor *= (1 - p10)
        
        if correction_factor < 1e-10:
            return 0.0
        
        return measured_prob / correction_factor


__all__ = [
    'ZeroNoiseExtrapolation',
    'MeasurementErrorMitigation',
    'ReadoutErrorCorrection',
    'MitigationResult'
]
