"""
Quantum Circuit Module for UHI-QUBO Framework

Implements quantum circuit algorithms for solving QUBO problems:
- QAOA (Quantum Approximate Optimization Algorithm)
- VQE (Variational Quantum Eigensolver)
- Backend interfaces for circuit execution
- Gate decomposition and optimization
- Error mitigation techniques

File 09 Implementation - Quantum Circuit Components
"""

from core.quantum_circuits.qaoa_builder import (
    QAOACircuitBuilder,
    QAOAResult,
    optimize_qaoa
)

from core.quantum_circuits.vqe_ansatz import (
    VQESolver,
    VQEResult,
    solve_vqe
)

from core.quantum_circuits.backend_interface import (
    QuantumBackend,
    QiskitSimulatorBackend,
    BackendManager,
    MeasurementResult,
    create_default_backend_manager
)

from core.quantum_circuits.gate_decomposition import (
    CircuitOptimizer,
    GateDecomposer,
    optimize_for_hardware
)

from core.quantum_circuits.noise_mitigation import (
    ZeroNoiseExtrapolation,
    MeasurementErrorMitigation,
    ReadoutErrorCorrection,
    MitigationResult
)

__all__ = [
    # QAOA
    'QAOACircuitBuilder',
    'QAOAResult',
    'optimize_qaoa',
    
    # VQE
    'VQESolver',
    'VQEResult',
    'solve_vqe',
    
    # Backend
    'QuantumBackend',
    'QiskitSimulatorBackend',
    'BackendManager',
    'MeasurementResult',
    'create_default_backend_manager',
    
    # Optimization
    'CircuitOptimizer',
    'GateDecomposer',
    'optimize_for_hardware',
    
    # Error Mitigation
    'ZeroNoiseExtrapolation',
    'MeasurementErrorMitigation',
    'ReadoutErrorCorrection',
    'MitigationResult'
]
