"""
Gate Decomposition and Circuit Optimization

Provides utilities for circuit transpilation, gate decomposition,
and optimization passes for quantum circuits.

Features:
- Circuit transpilation for different backends
- Gate decomposition to native gate sets
- Optimization passes (gate cancellation, commutation, etc.)
- Depth and gate count reduction
- Custom gate synthesis

Reference: Section 09 (Quantum Circuit Implementation) from framework documents
"""

import numpy as np
from typing import List, Dict, Any, Optional, Tuple

try:
    from qiskit import QuantumCircuit, transpile
    from qiskit.transpiler import PassManager, CouplingMap
    from qiskit.circuit.library import RZGate, RYGate, RXGate, CXGate, HGate
    from qiskit.quantum_info import Operator
except ImportError:
    raise ImportError("Qiskit not installed. Run: pip install qiskit")


class CircuitOptimizer:
    """
    Circuit optimization and gate decomposition utilities.
    
    Provides methods for:
    - Transpiling circuits to native gate sets
    - Reducing circuit depth and gate count
    - Decomposing multi-qubit gates
    - Applying optimization passes
    
    Optimization Strategies:
    1. Gate cancellation: Remove adjacent inverse gates
    2. Gate commutation: Reorder commuting gates for better optimization
    3. Single-qubit consolidation: Merge adjacent single-qubit gates
    4. Two-qubit reduction: Minimize CNOT gates
    
    Usage:
        >>> optimizer = CircuitOptimizer()
        >>> optimized = optimizer.optimize_circuit(circuit, level=3)
        >>> print(f"Depth reduction: {circuit.depth()} -> {optimized.depth()}")
    """
    
    def __init__(self, seed: Optional[int] = None):
        """
        Initialize circuit optimizer.
        
        Args:
            seed: Random seed for transpilation
        """
        self.seed = seed
    
    def optimize_circuit(
        self,
        circuit: QuantumCircuit,
        optimization_level: int = 1,
        basis_gates: Optional[List[str]] = None,
        coupling_map: Optional[List[Tuple[int, int]]] = None
    ) -> QuantumCircuit:
        """
        Optimize quantum circuit using Qiskit transpiler.
        
        Optimization Levels:
        - 0: No optimization, just translation
        - 1: Light optimization (gate cancellation)
        - 2: Medium optimization (commutation + cancellation)
        - 3: Heavy optimization (all passes, may increase runtime)
        
        Args:
            circuit: Input quantum circuit
            optimization_level: Optimization level (0-3)
            basis_gates: Target gate set (default: ['rx', 'ry', 'rz', 'cx'])
            coupling_map: Qubit connectivity constraints
            
        Returns:
            Optimized circuit
        """
        if basis_gates is None:
            basis_gates = ['rx', 'ry', 'rz', 'cx', 'h']
        
        # Use Qiskit transpiler
        optimized = transpile(
            circuit,
            optimization_level=optimization_level,
            basis_gates=basis_gates,
            coupling_map=coupling_map,
            seed_transpiler=self.seed
        )
        
        return optimized
    
    def decompose_to_basis(
        self,
        circuit: QuantumCircuit,
        basis_gates: List[str]
    ) -> QuantumCircuit:
        """
        Decompose circuit to specified basis gate set.
        
        Common basis sets:
        - IBM: ['id', 'rz', 'sx', 'x', 'cx']
        - Rigetti: ['rx', 'rz', 'cz']
        - Universal: ['rx', 'ry', 'rz', 'cx']
        
        Args:
            circuit: Input circuit
            basis_gates: Target basis gates
            
        Returns:
            Decomposed circuit
        """
        # Use transpiler for decomposition
        decomposed = transpile(
            circuit,
            basis_gates=basis_gates,
            optimization_level=0,  # No optimization, just decomposition
            seed_transpiler=self.seed
        )
        
        return decomposed
    
    def cancel_inverse_gates(self, circuit: QuantumCircuit) -> QuantumCircuit:
        """
        Remove adjacent inverse gate pairs.
        
        Examples:
        - X-X → I
        - H-H → I
        - CNOT-CNOT → I
        - RZ(θ)-RZ(-θ) → I
        
        Args:
            circuit: Input circuit
            
        Returns:
            Circuit with cancellations applied
        """
        # Use transpiler with optimization
        optimized = transpile(
            circuit,
            optimization_level=3,
            seed_transpiler=self.seed
        )
        return optimized
    
    def consolidate_single_qubit_gates(
        self,
        circuit: QuantumCircuit
    ) -> QuantumCircuit:
        """
        Merge consecutive single-qubit gates into minimal sequences.
        
        Any sequence of single-qubit gates can be implemented with
        at most 3 rotations: RZ(α) RY(β) RZ(γ)
        
        Args:
            circuit: Input circuit
            
        Returns:
            Circuit with consolidated single-qubit gates
        """
        # Use transpiler optimization
        optimized = transpile(
            circuit,
            optimization_level=3,
            seed_transpiler=self.seed
        )
        return optimized
    
    def reduce_two_qubit_gates(
        self,
        circuit: QuantumCircuit
    ) -> QuantumCircuit:
        """
        Minimize number of two-qubit gates (e.g., CNOT).
        
        Strategies:
        - Gate commutation
        - Block consolidation
        - Basis translation
        
        Args:
            circuit: Input circuit
            
        Returns:
            Circuit with reduced two-qubit gates
        """
        # Use transpiler optimization
        optimized = transpile(
            circuit,
            optimization_level=3,
            seed_transpiler=self.seed
        )
        return optimized
    
    def get_circuit_statistics(
        self,
        circuit: QuantumCircuit
    ) -> Dict[str, Any]:
        """
        Analyze circuit statistics.
        
        Returns:
            Dictionary with circuit metrics:
            - depth: Circuit depth
            - size: Total gate count
            - gate_counts: Count per gate type
            - cx_count: Number of CNOT gates
            - single_qubit_gates: Count of single-qubit gates
            - two_qubit_gates: Count of two-qubit gates
        """
        gate_counts = circuit.count_ops()
        
        # Count gate types
        single_qubit_gates = sum(
            count for gate, count in gate_counts.items()
            if gate in ['h', 'x', 'y', 'z', 'rx', 'ry', 'rz', 's', 't', 'sdg', 'tdg', 'sx', 'id']
        )
        
        two_qubit_gates = sum(
            count for gate, count in gate_counts.items()
            if gate in ['cx', 'cy', 'cz', 'ch', 'swap', 'iswap', 'cswap']
        )
        
        return {
            'depth': circuit.depth(),
            'size': circuit.size(),
            'num_qubits': circuit.num_qubits,
            'gate_counts': gate_counts,
            'total_gates': sum(gate_counts.values()),
            'cx_count': gate_counts.get('cx', 0),
            'single_qubit_gates': single_qubit_gates,
            'two_qubit_gates': two_qubit_gates,
            'width': circuit.width()
        }
    
    def compare_circuits(
        self,
        circuit1: QuantumCircuit,
        circuit2: QuantumCircuit
    ) -> Dict[str, Any]:
        """
        Compare two circuits (e.g., before/after optimization).
        
        Args:
            circuit1: First circuit (typically original)
            circuit2: Second circuit (typically optimized)
            
        Returns:
            Comparison statistics
        """
        stats1 = self.get_circuit_statistics(circuit1)
        stats2 = self.get_circuit_statistics(circuit2)
        
        return {
            'original': stats1,
            'optimized': stats2,
            'depth_reduction': stats1['depth'] - stats2['depth'],
            'depth_reduction_pct': 100 * (1 - stats2['depth'] / max(stats1['depth'], 1)),
            'gate_reduction': stats1['total_gates'] - stats2['total_gates'],
            'gate_reduction_pct': 100 * (1 - stats2['total_gates'] / max(stats1['total_gates'], 1)),
            'cx_reduction': stats1['cx_count'] - stats2['cx_count'],
            'cx_reduction_pct': 100 * (1 - stats2['cx_count'] / max(stats1['cx_count'], 1))
        }


class GateDecomposer:
    """
    Utilities for decomposing gates into basic operations.
    
    Provides decompositions for:
    - Multi-controlled gates
    - Arbitrary rotations
    - Special unitaries
    
    Mathematical Background:
    Any single-qubit gate U ∈ SU(2) can be decomposed as:
    U = e^{iα} RZ(β) RY(γ) RZ(δ)
    
    Any two-qubit gate can be decomposed using at most 3 CNOTs.
    """
    
    @staticmethod
    def decompose_toffoli(
        qc: Optional[QuantumCircuit] = None
    ) -> QuantumCircuit:
        """
        Decompose Toffoli (CCX) gate into elementary gates.
        
        Toffoli can be implemented with 6 CNOTs and several single-qubit gates.
        
        Args:
            qc: Quantum circuit to add gates to (creates new if None)
            
        Returns:
            Circuit with Toffoli decomposition
        """
        if qc is None:
            qc = QuantumCircuit(3)
        
        # Standard Toffoli decomposition
        qc.h(2)
        qc.cx(1, 2)
        qc.tdg(2)
        qc.cx(0, 2)
        qc.t(2)
        qc.cx(1, 2)
        qc.tdg(2)
        qc.cx(0, 2)
        qc.t(1)
        qc.t(2)
        qc.cx(0, 1)
        qc.h(2)
        qc.t(0)
        qc.tdg(1)
        qc.cx(0, 1)
        
        return qc
    
    @staticmethod
    def decompose_controlled_ry(
        theta: float,
        qc: Optional[QuantumCircuit] = None
    ) -> QuantumCircuit:
        """
        Decompose controlled-RY gate.
        
        CRY(θ) can be implemented using RY and CNOT gates.
        
        Args:
            theta: Rotation angle
            qc: Circuit to add to (creates new if None)
            
        Returns:
            Circuit with CRY decomposition
        """
        if qc is None:
            qc = QuantumCircuit(2)
        
        # CRY decomposition
        qc.ry(theta / 2, 1)
        qc.cx(0, 1)
        qc.ry(-theta / 2, 1)
        qc.cx(0, 1)
        
        return qc
    
    @staticmethod
    def decompose_arbitrary_single_qubit(
        unitary: np.ndarray
    ) -> Tuple[float, float, float, float]:
        """
        Decompose arbitrary single-qubit unitary into Euler angles.
        
        U = e^{iα} RZ(β) RY(γ) RZ(δ)
        
        Args:
            unitary: 2×2 unitary matrix
            
        Returns:
            (alpha, beta, gamma, delta): Euler angles
        """
        # Use Qiskit's quantum_info
        from qiskit.quantum_info import Operator
        from qiskit.synthesis import OneQubitEulerDecomposer
        
        decomposer = OneQubitEulerDecomposer('ZYZ')
        angles = decomposer.angles(Operator(unitary))
        
        # angles = (theta, phi, lambda, phase)
        # corresponds to: e^{i*phase} RZ(phi) RY(theta) RZ(lambda)
        return angles[3], angles[1], angles[0], angles[2]


def optimize_for_hardware(
    circuit: QuantumCircuit,
    backend_name: str = 'ibm',
    optimization_level: int = 3
) -> QuantumCircuit:
    """
    Optimize circuit for specific hardware platform.
    
    Args:
        circuit: Input circuit
        backend_name: Target platform ('ibm', 'rigetti', 'ionq', etc.)
        optimization_level: Optimization level (0-3)
        
    Returns:
        Hardware-optimized circuit
    """
    # Define basis gates for different platforms
    basis_gates_map = {
        'ibm': ['id', 'rz', 'sx', 'x', 'cx'],
        'rigetti': ['rx', 'rz', 'cz'],
        'ionq': ['rx', 'ry', 'rz', 'xx'],
        'universal': ['rx', 'ry', 'rz', 'cx']
    }
    
    basis_gates = basis_gates_map.get(backend_name.lower(), basis_gates_map['universal'])
    
    optimizer = CircuitOptimizer()
    optimized = optimizer.optimize_circuit(
        circuit,
        optimization_level=optimization_level,
        basis_gates=basis_gates
    )
    
    return optimized


__all__ = [
    'CircuitOptimizer',
    'GateDecomposer',
    'optimize_for_hardware'
]
