"""
QAOA Circuit Builder for UHI-QUBO Framework

Implements Quantum Approximate Optimization Algorithm (QAOA) for solving
QUBO problems via quantum circuits.

Mathematical Framework:
=======================
QAOA Circuit: |ψ(γ, β)⟩ = U_M(β_p) U_P(γ_p) ... U_M(β_1) U_P(γ_1) |+⟩^n

Problem Hamiltonian: H_P = Σ h_i Z_i + Σ_{i<j} J_ij Z_i Z_j
Mixer Hamiltonian: H_M = Σ X_i

Evolution Operators:
- U_P(γ) = exp(-i γ H_P): Problem evolution
- U_M(β) = exp(-i β H_M): Mixer evolution

Expectation Value: ⟨H_P⟩ = ⟨ψ(γ, β)| H_P |ψ(γ, β)⟩

The parameters (γ, β) are optimized classically to minimize ⟨H_P⟩.

Reference: Farhi et al., "A Quantum Approximate Optimization Algorithm" (2014)
           Section 09 (Quantum Circuit Implementation) from framework documents
"""

import numpy as np
from typing import List, Tuple, Optional, Dict, Any, Callable
from dataclasses import dataclass
from scipy.optimize import minimize

try:
    from qiskit import QuantumCircuit, QuantumRegister
    from qiskit.circuit import Parameter, ParameterVector
    from qiskit.quantum_info import SparsePauliOp, Pauli
    # Use StatevectorEstimator from qiskit_aer for computing expectation values
    from qiskit_aer.primitives import Estimator
except ImportError:
    raise ImportError("Qiskit not installed. Run: pip install qiskit qiskit-aer")

from core.qubo_formulation.ising_converter import IsingConverter, IsingModel


@dataclass
class QAOAResult:
    """
    Result container for QAOA optimization.
    
    Attributes:
        optimal_parameters: Optimized (γ, β) parameters
        optimal_energy: Minimum expectation value ⟨H_P⟩
        circuit: QAOA quantum circuit
        convergence_history: Energy values during optimization
        execution_counts: Number of function evaluations
        success: Whether optimization converged
        metadata: Additional information (circuit depth, gate count, etc.)
    """
    optimal_parameters: np.ndarray
    optimal_energy: float
    circuit: QuantumCircuit
    convergence_history: List[float]
    execution_counts: int
    success: bool
    metadata: Dict[str, Any]


class QAOACircuitBuilder:
    """
    QAOA Circuit Builder for QUBO problems.
    
    Constructs and optimizes QAOA circuits to solve QUBO via quantum computing.
    
    Features:
    - Automatic QUBO to Ising conversion
    - Parameterized circuit construction
    - Classical optimization of variational parameters
    - Circuit analysis (depth, gate count)
    - Multiple optimization methods (COBYLA, SPSA, L-BFGS-B)
    
    Mathematical Details:
    ====================
    Given QUBO matrix Q, we:
    1. Convert to Ising: H = -Σ h_i σ_i^z - Σ_{i<j} J_ij σ_i^z σ_j^z
    2. Build QAOA circuit with p layers
    3. Optimize parameters to minimize ⟨H⟩
    
    Circuit Structure (per layer):
    - Initialize: H⊗n |0⟩ = |+⟩^n (equal superposition)
    - Problem evolution: U_P(γ) = ∏_i e^{-iγh_i Z_i} ∏_{i<j} e^{-iγJ_ij Z_i Z_j}
    - Mixer evolution: U_M(β) = ∏_i e^{-iβ X_i}
    
    Usage:
        >>> builder = QAOACircuitBuilder(p=2)
        >>> result = builder.optimize_qaoa(Q, method='COBYLA')
        >>> print(f"Optimal energy: {result.optimal_energy}")
    """
    
    def __init__(self, p: int = 1, seed: Optional[int] = None):
        """
        Initialize QAOA builder.
        
        Args:
            p: Number of QAOA layers (circuit depth parameter)
            seed: Random seed for reproducibility
        """
        self.p = p
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        
        # Optimization tracking
        self.iteration_count = 0
        self.energy_history: List[float] = []
    
    def build_qaoa_circuit(
        self, 
        ising: IsingModel, 
        gamma: Optional[np.ndarray] = None,
        beta: Optional[np.ndarray] = None
    ) -> QuantumCircuit:
        """
        Construct QAOA circuit for Ising Hamiltonian.
        
        Circuit layers (repeated p times):
        1. Problem Hamiltonian evolution U_P(γ)
        2. Mixer Hamiltonian evolution U_M(β)
        
        Args:
            ising: Ising model with h, J parameters
            gamma: Problem evolution angles (length p), parameterized if None
            beta: Mixer evolution angles (length p), parameterized if None
            
        Returns:
            Parameterized or bound QAOA circuit
        """
        n = ising.n
        qc = QuantumCircuit(n)
        
        # Create parameters if not provided
        use_parameters = (gamma is None) or (beta is None)
        if use_parameters:
            gamma_params = ParameterVector('γ', self.p)
            beta_params = ParameterVector('β', self.p)
        else:
            gamma_params = gamma
            beta_params = beta
        
        # Initial state: |+⟩^n (equal superposition)
        for i in range(n):
            qc.h(i)
        
        # QAOA layers
        for layer in range(self.p):
            # Problem Hamiltonian evolution: U_P(γ)
            self._apply_problem_hamiltonian(qc, ising, gamma_params[layer])
            
            # Mixer Hamiltonian evolution: U_M(β)
            self._apply_mixer_hamiltonian(qc, n, beta_params[layer])
        
        return qc
    
    def _apply_problem_hamiltonian(
        self, 
        qc: QuantumCircuit, 
        ising: IsingModel, 
        gamma: float
    ):
        """
        Apply problem Hamiltonian evolution: exp(-iγ H_P).
        
        H_P = -Σ h_i Z_i - Σ_{i<j} J_ij Z_i Z_j
        
        Implementation:
        - Single-qubit: RZ(2γh_i) for each linear term
        - Two-qubit: CNOT-RZ(2γJ_ij)-CNOT for each coupling
        
        Args:
            qc: Quantum circuit to modify
            ising: Ising model
            gamma: Evolution angle
        """
        n = ising.n
        
        # Linear terms: -h_i Z_i → RZ(2γh_i)
        for i in range(n):
            if abs(ising.h[i]) > 1e-10:
                # e^{-iγ(-h_i)Z_i} = e^{iγh_i Z_i} = RZ(2γh_i)
                qc.rz(2 * gamma * ising.h[i], i)
        
        # Coupling terms: -J_ij Z_i Z_j → CNOT-RZ(2γJ_ij)-CNOT
        for i in range(n):
            for j in range(i + 1, n):
                if abs(ising.J[i, j]) > 1e-10:
                    # e^{-iγ(-J_ij)Z_i Z_j} = e^{iγJ_ij Z_i Z_j}
                    # Decomposition: CNOT(i,j) RZ(2γJ_ij,j) CNOT(i,j)
                    qc.cx(i, j)
                    qc.rz(2 * gamma * ising.J[i, j], j)
                    qc.cx(i, j)
    
    def _apply_mixer_hamiltonian(
        self, 
        qc: QuantumCircuit, 
        n: int, 
        beta: float
    ):
        """
        Apply mixer Hamiltonian evolution: exp(-iβ H_M).
        
        H_M = Σ X_i
        
        Implementation: RX(2β) on each qubit
        e^{-iβ X_i} = RX(2β)
        
        Args:
            qc: Quantum circuit to modify
            n: Number of qubits
            beta: Evolution angle
        """
        for i in range(n):
            qc.rx(2 * beta, i)
    
    def create_cost_hamiltonian(self, ising: IsingModel) -> SparsePauliOp:
        """
        Create Qiskit Hamiltonian operator from Ising model.
        
        H = -Σ h_i Z_i - Σ_{i<j} J_ij Z_i Z_j
        
        Args:
            ising: Ising model
            
        Returns:
            SparsePauliOp representing the Hamiltonian
        """
        n = ising.n
        pauli_list = []
        coeffs = []
        
        # Linear terms: -h_i Z_i
        for i in range(n):
            if abs(ising.h[i]) > 1e-10:
                pauli_str = 'I' * (n - i - 1) + 'Z' + 'I' * i
                pauli_list.append(pauli_str)
                coeffs.append(-ising.h[i])
        
        # Coupling terms: -J_ij Z_i Z_j
        for i in range(n):
            for j in range(i + 1, n):
                if abs(ising.J[i, j]) > 1e-10:
                    # Build Pauli string with Z at positions i and j
                    pauli_str = ['I'] * n
                    pauli_str[n - i - 1] = 'Z'
                    pauli_str[n - j - 1] = 'Z'
                    pauli_list.append(''.join(pauli_str))
                    coeffs.append(-ising.J[i, j])
        
        # Create SparsePauliOp
        if len(pauli_list) == 0:
            # Empty Hamiltonian
            pauli_list = ['I' * n]
            coeffs = [0.0]
        
        return SparsePauliOp(pauli_list, coeffs=coeffs)
    
    def optimize_qaoa_parameters(
        self,
        Q: np.ndarray,
        method: str = 'COBYLA',
        initial_params: Optional[np.ndarray] = None,
        maxiter: int = 100,
        tol: float = 1e-6,
        verbose: bool = False
    ) -> QAOAResult:
        """
        Optimize QAOA parameters to minimize ⟨H_P⟩.
        
        Classical optimization loop:
        1. Choose (γ, β) parameters
        2. Build circuit and compute ⟨H⟩
        3. Update parameters to minimize ⟨H⟩
        4. Repeat until convergence
        
        Args:
            Q: QUBO matrix
            method: Optimization method ('COBYLA', 'L-BFGS-B', 'SLSQP')
            initial_params: Initial (γ, β) values (random if None)
            maxiter: Maximum optimization iterations
            tol: Convergence tolerance
            verbose: Print optimization progress
            
        Returns:
            QAOAResult with optimal parameters and circuit
        """
        # Convert QUBO to Ising
        ising = IsingConverter.qubo_to_ising(Q)
        
        # Create cost Hamiltonian
        hamiltonian = self.create_cost_hamiltonian(ising)
        
        # Build parameterized circuit
        param_circuit = self.build_qaoa_circuit(ising)
        
        # Initialize parameters
        if initial_params is None:
            # Random initialization in [0, π]
            initial_params = self.rng.uniform(0, np.pi, 2 * self.p)
        else:
            if len(initial_params) != 2 * self.p:
                raise ValueError(f"Expected {2*self.p} parameters, got {len(initial_params)}")
        
        # Reset tracking
        self.iteration_count = 0
        self.energy_history = []
        
        # Create estimator for expectation value computation
        estimator = Estimator()
        
        def objective_function(params: np.ndarray) -> float:
            """
            Compute expectation value ⟨ψ(γ,β)| H |ψ(γ,β)⟩.
            
            Args:
                params: Concatenated [γ_1, ..., γ_p, β_1, ..., β_p]
                
            Returns:
                Expectation value (energy to minimize)
            """
            self.iteration_count += 1
            
            # Bind parameters to circuit
            gamma_vals = params[:self.p]
            beta_vals = params[self.p:]
            
            # Create parameter dictionary
            param_dict = {}
            for i in range(self.p):
                param_dict[param_circuit.parameters[i]] = gamma_vals[i]
                param_dict[param_circuit.parameters[self.p + i]] = beta_vals[i]
            
            bound_circuit = param_circuit.assign_parameters(param_dict)
            
            # Compute expectation value
            job = estimator.run(bound_circuit, hamiltonian)
            result = job.result()
            energy = result.values[0]
            
            # Add offset to get true energy
            energy += ising.offset
            
            self.energy_history.append(float(energy))
            
            if verbose and self.iteration_count % 10 == 0:
                print(f"Iteration {self.iteration_count}: Energy = {energy:.6f}")
            
            return energy
        
        # Optimize
        opt_result = minimize(
            objective_function,
            initial_params,
            method=method,
            options={'maxiter': maxiter},
            tol=tol
        )
        
        # Extract optimal parameters
        optimal_params = opt_result.x
        gamma_opt = optimal_params[:self.p]
        beta_opt = optimal_params[self.p:]
        
        # Build final circuit with optimal parameters
        optimal_circuit = self.build_qaoa_circuit(ising, gamma_opt, beta_opt)
        
        # Circuit analysis
        circuit_depth = optimal_circuit.depth()
        gate_count = sum(optimal_circuit.count_ops().values())
        
        # Create result
        result = QAOAResult(
            optimal_parameters=optimal_params,
            optimal_energy=opt_result.fun,
            circuit=optimal_circuit,
            convergence_history=self.energy_history,
            execution_counts=self.iteration_count,
            success=opt_result.success,
            metadata={
                'p': self.p,
                'n_qubits': ising.n,
                'circuit_depth': circuit_depth,
                'gate_count': gate_count,
                'optimization_method': method,
                'optimization_message': opt_result.message,
                'gamma': gamma_opt.tolist(),
                'beta': beta_opt.tolist(),
                'offset': ising.offset
            }
        )
        
        return result
    
    def get_circuit_statistics(self, circuit: QuantumCircuit) -> Dict[str, Any]:
        """
        Analyze circuit properties.
        
        Args:
            circuit: Quantum circuit to analyze
            
        Returns:
            Dictionary with circuit statistics
        """
        gate_counts = circuit.count_ops()
        
        return {
            'num_qubits': circuit.num_qubits,
            'depth': circuit.depth(),
            'size': circuit.size(),
            'gate_counts': gate_counts,
            'total_gates': sum(gate_counts.values()),
            'cx_gates': gate_counts.get('cx', 0),
            'single_qubit_gates': sum(
                count for gate, count in gate_counts.items() 
                if gate in ['h', 'x', 'y', 'z', 'rx', 'ry', 'rz', 's', 't']
            ),
            'width': circuit.width(),
        }
    
    def estimate_runtime(self, circuit: QuantumCircuit, gate_time_ns: float = 100.0) -> float:
        """
        Estimate circuit execution time on quantum hardware.
        
        Rough estimation based on circuit depth and gate times.
        
        Args:
            circuit: Quantum circuit
            gate_time_ns: Average gate execution time in nanoseconds
            
        Returns:
            Estimated runtime in microseconds
        """
        depth = circuit.depth()
        return depth * gate_time_ns / 1000.0  # Convert to microseconds


def optimize_qaoa(
    Q: np.ndarray,
    p: int = 1,
    method: str = 'COBYLA',
    maxiter: int = 100,
    seed: Optional[int] = None,
    verbose: bool = False
) -> QAOAResult:
    """
    Convenience function to optimize QAOA for a QUBO problem.
    
    Args:
        Q: QUBO matrix
        p: Number of QAOA layers
        method: Optimization method
        maxiter: Maximum iterations
        seed: Random seed
        verbose: Print progress
        
    Returns:
        QAOAResult with optimal circuit and parameters
        
    Example:
        >>> Q = np.array([[1, -1], [-1, 2]])
        >>> result = optimize_qaoa(Q, p=2, method='COBYLA')
        >>> print(f"Optimal energy: {result.optimal_energy}")
    """
    builder = QAOACircuitBuilder(p=p, seed=seed)
    return builder.optimize_qaoa_parameters(
        Q, method=method, maxiter=maxiter, verbose=verbose
    )


__all__ = [
    'QAOACircuitBuilder',
    'QAOAResult',
    'optimize_qaoa'
]
