"""
VQE (Variational Quantum Eigensolver) Ansatz for UHI-QUBO Framework

Implements VQE algorithm with multiple ansatz templates for solving QUBO problems.

Mathematical Framework:
=======================
VQE finds the ground state of a Hamiltonian H using a parameterized quantum circuit:

|ψ(θ)⟩ = U(θ) |0⟩

where U(θ) is a variational ansatz with parameters θ.

The energy is minimized classically:
E(θ) = ⟨ψ(θ)| H |ψ(θ)⟩

Ansatz Types:
1. Hardware Efficient: Alternating rotation and entanglement layers
2. RealAmplitudes: RY rotations + CX entanglement
3. EfficientSU2: Full SU(2) rotations + CX entanglement

Reference: Peruzzo et al., "A variational eigenvalue solver on a photonic quantum processor" (2014)
           Section 09 (Quantum Circuit Implementation) from framework documents
"""

import numpy as np
from typing import List, Tuple, Optional, Dict, Any, Literal
from dataclasses import dataclass
from scipy.optimize import minimize

try:
    from qiskit import QuantumCircuit
    from qiskit.circuit import ParameterVector
    from qiskit.quantum_info import SparsePauliOp
    # Use Estimator from qiskit_aer for computing expectation values
    from qiskit_aer.primitives import Estimator
except ImportError:
    raise ImportError("Qiskit not installed. Run: pip install qiskit qiskit-aer")

from core.qubo_formulation.ising_converter import IsingConverter, IsingModel


@dataclass
class VQEResult:
    """
    Result container for VQE optimization.
    
    Attributes:
        optimal_parameters: Optimized variational parameters θ
        optimal_energy: Minimum expectation value ⟨H⟩
        circuit: VQE quantum circuit with optimal parameters
        convergence_history: Energy trajectory during optimization
        execution_counts: Number of objective function evaluations
        success: Whether optimization converged
        metadata: Additional information (ansatz type, depth, etc.)
    """
    optimal_parameters: np.ndarray
    optimal_energy: float
    circuit: QuantumCircuit
    convergence_history: List[float]
    execution_counts: int
    success: bool
    metadata: Dict[str, Any]


class VQESolver:
    """
    Variational Quantum Eigensolver for QUBO problems.
    
    VQE is a hybrid quantum-classical algorithm that finds the ground state
    of a Hamiltonian by optimizing a parameterized quantum circuit.
    
    Algorithm:
    1. Prepare parameterized state |ψ(θ)⟩
    2. Measure expectation value ⟨H⟩
    3. Classically optimize θ to minimize ⟨H⟩
    4. Repeat until convergence
    
    Ansatz Types:
    - hardware_efficient: Minimal ansatz for near-term devices
    - RealAmplitudes: RY rotations with linear entanglement
    - EfficientSU2: Full single-qubit rotations with circular entanglement
    
    Mathematical Details:
    ====================
    Given QUBO Q, convert to Ising H = Σ_i h_i Z_i + Σ_{i<j} J_ij Z_i Z_j
    
    Energy functional: E(θ) = ⟨ψ(θ)| H |ψ(θ)⟩
    
    Optimization: θ* = argmin_θ E(θ)
    
    Usage:
        >>> solver = VQESolver(ansatz_type='RealAmplitudes', depth=2)
        >>> result = solver.solve(Q, method='COBYLA')
        >>> print(f"Ground state energy: {result.optimal_energy}")
    """
    
    def __init__(
        self,
        ansatz_type: Literal['hardware_efficient', 'RealAmplitudes', 'EfficientSU2'] = 'RealAmplitudes',
        depth: int = 1,
        entanglement: Literal['linear', 'circular', 'full'] = 'linear',
        seed: Optional[int] = None
    ):
        """
        Initialize VQE solver.
        
        Args:
            ansatz_type: Type of variational ansatz
            depth: Number of repetitions of the ansatz layers
            entanglement: Entanglement pattern ('linear', 'circular', 'full')
            seed: Random seed for reproducibility
        """
        self.ansatz_type = ansatz_type
        self.depth = depth
        self.entanglement = entanglement
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        
        # Optimization tracking
        self.iteration_count = 0
        self.energy_history: List[float] = []
    
    def build_ansatz(self, n_qubits: int) -> Tuple[QuantumCircuit, int]:
        """
        Build variational ansatz circuit.
        
        Args:
            n_qubits: Number of qubits
            
        Returns:
            (circuit, n_parameters): Parameterized circuit and parameter count
        """
        if self.ansatz_type == 'hardware_efficient':
            return self._build_hardware_efficient(n_qubits)
        elif self.ansatz_type == 'RealAmplitudes':
            return self._build_real_amplitudes(n_qubits)
        elif self.ansatz_type == 'EfficientSU2':
            return self._build_efficient_su2(n_qubits)
        else:
            raise ValueError(f"Unknown ansatz type: {self.ansatz_type}")
    
    def _build_hardware_efficient(self, n_qubits: int) -> Tuple[QuantumCircuit, int]:
        """
        Hardware-efficient ansatz.
        
        Structure (per layer):
        - RY rotation on each qubit
        - Entangling layer (CX gates)
        
        Args:
            n_qubits: Number of qubits
            
        Returns:
            (circuit, n_parameters)
        """
        qc = QuantumCircuit(n_qubits)
        
        # Count parameters
        n_params = (self.depth + 1) * n_qubits  # RY layers
        params = ParameterVector('θ', n_params)
        
        param_idx = 0
        
        # Initial rotation layer
        for i in range(n_qubits):
            qc.ry(params[param_idx], i)
            param_idx += 1
        
        # Repeated layers
        for d in range(self.depth):
            # Entangling layer
            self._add_entanglement(qc, n_qubits)
            
            # Rotation layer
            for i in range(n_qubits):
                qc.ry(params[param_idx], i)
                param_idx += 1
        
        return qc, n_params
    
    def _build_real_amplitudes(self, n_qubits: int) -> Tuple[QuantumCircuit, int]:
        """
        RealAmplitudes ansatz.
        
        Structure (per layer):
        - RY rotations on all qubits
        - Linear entanglement (CX between adjacent qubits)
        
        Args:
            n_qubits: Number of qubits
            
        Returns:
            (circuit, n_parameters)
        """
        qc = QuantumCircuit(n_qubits)
        
        # Count parameters: (depth + 1) rotation layers
        n_params = (self.depth + 1) * n_qubits
        params = ParameterVector('θ', n_params)
        
        param_idx = 0
        
        # Initial rotation layer
        for i in range(n_qubits):
            qc.ry(params[param_idx], i)
            param_idx += 1
        
        # Repeated layers
        for d in range(self.depth):
            # Entangling layer
            self._add_entanglement(qc, n_qubits)
            
            # Rotation layer
            for i in range(n_qubits):
                qc.ry(params[param_idx], i)
                param_idx += 1
        
        return qc, n_params
    
    def _build_efficient_su2(self, n_qubits: int) -> Tuple[QuantumCircuit, int]:
        """
        EfficientSU2 ansatz.
        
        Structure (per layer):
        - Full SU(2) rotations: RY-RZ on each qubit
        - Entangling layer (CX gates)
        
        Args:
            n_qubits: Number of qubits
            
        Returns:
            (circuit, n_parameters)
        """
        qc = QuantumCircuit(n_qubits)
        
        # Count parameters: (depth + 1) layers × 2 rotations per qubit
        n_params = (self.depth + 1) * 2 * n_qubits
        params = ParameterVector('θ', n_params)
        
        param_idx = 0
        
        # Initial rotation layer
        for i in range(n_qubits):
            qc.ry(params[param_idx], i)
            param_idx += 1
            qc.rz(params[param_idx], i)
            param_idx += 1
        
        # Repeated layers
        for d in range(self.depth):
            # Entangling layer
            self._add_entanglement(qc, n_qubits)
            
            # Rotation layer
            for i in range(n_qubits):
                qc.ry(params[param_idx], i)
                param_idx += 1
                qc.rz(params[param_idx], i)
                param_idx += 1
        
        return qc, n_params
    
    def _add_entanglement(self, qc: QuantumCircuit, n_qubits: int):
        """
        Add entanglement layer to circuit.
        
        Args:
            qc: Quantum circuit to modify
            n_qubits: Number of qubits
        """
        if self.entanglement == 'linear':
            # Linear chain: 0-1, 1-2, ..., (n-2)-(n-1)
            for i in range(n_qubits - 1):
                qc.cx(i, i + 1)
        
        elif self.entanglement == 'circular':
            # Circular: linear + (n-1)-0
            for i in range(n_qubits - 1):
                qc.cx(i, i + 1)
            if n_qubits > 1:
                qc.cx(n_qubits - 1, 0)
        
        elif self.entanglement == 'full':
            # All-to-all (expensive for large n)
            for i in range(n_qubits):
                for j in range(i + 1, n_qubits):
                    qc.cx(i, j)
        
        else:
            raise ValueError(f"Unknown entanglement: {self.entanglement}")
    
    def _create_hamiltonian(self, ising: IsingModel) -> SparsePauliOp:
        """
        Create Qiskit Hamiltonian from Ising model.
        
        Args:
            ising: Ising model
            
        Returns:
            SparsePauliOp Hamiltonian
        """
        n = ising.n
        pauli_list = []
        coeffs = []
        
        # Linear terms: -h_i Z_i
        for i in range(n):
            if abs(ising.h[i]) > 1e-10:
                pauli_str = 'I' * (n - i - 1) + 'Z' + 'I' * i
                pauli_list.append(pauli_str)
                coeffs.append(-ising.h[i])
        
        # Coupling terms: -J_ij Z_i Z_j
        for i in range(n):
            for j in range(i + 1, n):
                if abs(ising.J[i, j]) > 1e-10:
                    pauli_str = ['I'] * n
                    pauli_str[n - i - 1] = 'Z'
                    pauli_str[n - j - 1] = 'Z'
                    pauli_list.append(''.join(pauli_str))
                    coeffs.append(-ising.J[i, j])
        
        if len(pauli_list) == 0:
            pauli_list = ['I' * n]
            coeffs = [0.0]
        
        return SparsePauliOp(pauli_list, coeffs=coeffs)
    
    def solve(
        self,
        Q: np.ndarray,
        method: str = 'COBYLA',
        initial_params: Optional[np.ndarray] = None,
        maxiter: int = 100,
        tol: float = 1e-6,
        verbose: bool = False
    ) -> VQEResult:
        """
        Solve QUBO using VQE.
        
        Args:
            Q: QUBO matrix
            method: Optimization method ('COBYLA', 'L-BFGS-B', 'SLSQP')
            initial_params: Initial parameter values (random if None)
            maxiter: Maximum optimization iterations
            tol: Convergence tolerance
            verbose: Print optimization progress
            
        Returns:
            VQEResult with optimal parameters and energy
        """
        # Convert QUBO to Ising
        ising = IsingConverter.qubo_to_ising(Q)
        n_qubits = ising.n
        
        # Build ansatz
        ansatz, n_params = self.build_ansatz(n_qubits)
        
        # Create Hamiltonian
        hamiltonian = self._create_hamiltonian(ising)
        
        # Initialize parameters
        if initial_params is None:
            # Random initialization in [-π, π]
            initial_params = self.rng.uniform(-np.pi, np.pi, n_params)
        else:
            if len(initial_params) != n_params:
                raise ValueError(f"Expected {n_params} parameters, got {len(initial_params)}")
        
        # Reset tracking
        self.iteration_count = 0
        self.energy_history = []
        
        # Create estimator
        estimator = Estimator()
        
        def objective_function(params: np.ndarray) -> float:
            """
            Compute expectation value ⟨ψ(θ)| H |ψ(θ)⟩.
            
            Args:
                params: Variational parameters
                
            Returns:
                Expectation value (energy)
            """
            self.iteration_count += 1
            
            # Bind parameters
            param_dict = {ansatz.parameters[i]: params[i] for i in range(n_params)}
            bound_circuit = ansatz.assign_parameters(param_dict)
            
            # Compute expectation value
            job = estimator.run(bound_circuit, hamiltonian)
            result = job.result()
            energy = result.values[0]
            
            # Add offset
            energy += ising.offset
            
            self.energy_history.append(float(energy))
            
            if verbose and self.iteration_count % 10 == 0:
                print(f"Iteration {self.iteration_count}: Energy = {energy:.6f}")
            
            return energy
        
        # Optimize
        opt_result = minimize(
            objective_function,
            initial_params,
            method=method,
            options={'maxiter': maxiter},
            tol=tol
        )
        
        # Build final circuit with optimal parameters
        optimal_params = opt_result.x
        param_dict = {ansatz.parameters[i]: optimal_params[i] for i in range(n_params)}
        optimal_circuit = ansatz.assign_parameters(param_dict)
        
        # Circuit statistics
        gate_counts = optimal_circuit.count_ops()
        
        # Create result
        result = VQEResult(
            optimal_parameters=optimal_params,
            optimal_energy=opt_result.fun,
            circuit=optimal_circuit,
            convergence_history=self.energy_history,
            execution_counts=self.iteration_count,
            success=opt_result.success,
            metadata={
                'ansatz_type': self.ansatz_type,
                'depth': self.depth,
                'entanglement': self.entanglement,
                'n_qubits': n_qubits,
                'n_parameters': n_params,
                'circuit_depth': optimal_circuit.depth(),
                'gate_counts': gate_counts,
                'total_gates': sum(gate_counts.values()),
                'optimization_method': method,
                'optimization_message': opt_result.message,
                'offset': ising.offset
            }
        )
        
        return result
    
    def estimate_energy(
        self,
        Q: np.ndarray,
        params: np.ndarray
    ) -> float:
        """
        Estimate energy for given parameters without optimization.
        
        Args:
            Q: QUBO matrix
            params: Variational parameters
            
        Returns:
            Energy expectation value
        """
        # Convert to Ising
        ising = IsingConverter.qubo_to_ising(Q)
        
        # Build ansatz
        ansatz, n_params = self.build_ansatz(ising.n)
        
        if len(params) != n_params:
            raise ValueError(f"Expected {n_params} parameters, got {len(params)}")
        
        # Bind parameters
        param_dict = {ansatz.parameters[i]: params[i] for i in range(n_params)}
        bound_circuit = ansatz.assign_parameters(param_dict)
        
        # Create Hamiltonian
        hamiltonian = self._create_hamiltonian(ising)
        
        # Compute expectation value
        estimator = Estimator()
        job = estimator.run(bound_circuit, hamiltonian)
        result = job.result()
        energy = result.values[0] + ising.offset
        
        return float(energy)


def solve_vqe(
    Q: np.ndarray,
    ansatz_type: str = 'RealAmplitudes',
    depth: int = 1,
    method: str = 'COBYLA',
    maxiter: int = 100,
    seed: Optional[int] = None,
    verbose: bool = False
) -> VQEResult:
    """
    Convenience function to solve QUBO using VQE.
    
    Args:
        Q: QUBO matrix
        ansatz_type: Type of ansatz ('hardware_efficient', 'RealAmplitudes', 'EfficientSU2')
        depth: Ansatz depth
        method: Optimization method
        maxiter: Maximum iterations
        seed: Random seed
        verbose: Print progress
        
    Returns:
        VQEResult with optimal parameters and energy
        
    Example:
        >>> Q = np.array([[1, -1], [-1, 2]])
        >>> result = solve_vqe(Q, ansatz_type='RealAmplitudes', depth=2)
        >>> print(f"Optimal energy: {result.optimal_energy}")
    """
    solver = VQESolver(
        ansatz_type=ansatz_type,
        depth=depth,
        seed=seed
    )
    return solver.solve(Q, method=method, maxiter=maxiter, verbose=verbose)


__all__ = [
    'VQESolver',
    'VQEResult',
    'solve_vqe'
]
