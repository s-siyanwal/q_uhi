#!/usr/bin/env python3
"""
Comprehensive Demo: Spatial Modeling Integration
"""

import numpy as np
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.spatial_modeling import (
    UrbanGrid, create_synthetic_grid,
    HeatDiffusionSolver,
    ConnectivityAnalyzer, analyze_green_network_coverage
)
from core.problem_modeling import UHIGreenLayoutProblem, UHIProblemConfig

print("=" * 70)
print("UHI-QUBO Spatial Modeling Integration Demo")
print("=" * 70)

# Step 1: Create grid
print("\n[Step 1] Creating urban grid...")
grid = create_synthetic_grid(30, 30, cell_size=50.0, candidate_fraction=0.4, random_seed=42)
print(f"   Grid: {grid}")
print(f"   Candidates: {len(grid.get_candidate_cells())}/{grid.N}")

# Step 2: Setup QUBO problem using uniform grid method
print("\n[Step 2] Setting up optimization problem...")
config = UHIProblemConfig(
    grid_rows=30, grid_cols=30, cell_size=50.0,
    cooling_kernel_type='gaussian', cooling_length_scale=100.0,
    cooling_amplitude=-2.0, area_budget_fraction=0.2
)
problem = UHIGreenLayoutProblem(config)
problem.setup_uniform_grid(candidate_fraction=0.4, random_seed=42)
problem.setup_cooling_model()
Q, metadata = problem.build_qubo()
print(f"   QUBO: {Q.shape}, candidates={problem.n_candidates}")

# Step 3: Solve (greedy demo solver)
print("\n[Step 3] Solving...")
n_select = int(problem.n_candidates * 0.15)
diag = np.diag(Q)
solution = np.zeros(problem.n_candidates, dtype=int)
solution[np.argsort(diag)[:n_select]] = 1
problem.set_solution(solution)
stats = problem.get_solution_statistics()
print(f"   Selected: {stats['n_green_cells']} cells ({stats['total_area_m2']/1e4:.2f} ha)")

# Step 4: Analyze connectivity
print("\n[Step 4] Analyzing connectivity...")
analyzer = ConnectivityAnalyzer(grid, connectivity=4)
selected = [problem.candidate_indices[i] for i, x in enumerate(solution) if x == 1]
metrics = analyzer.compute_connectivity_metrics(selected)
coverage = analyze_green_network_coverage(grid, selected, service_distance=300.0)
print(f"   Connected: {metrics['is_connected']}, Components: {metrics['n_components']}")
print(f"   Coverage (300m): {coverage['coverage_fraction']:.1%}")

# Step 5: Simulate heat diffusion
print("\n[Step 5] Simulating heat diffusion...")
solver = HeatDiffusionSolver(grid, alpha=1e-5, method='implicit')
T0 = grid.get_temperature_field()
solver.set_initial_temperature(T0)
solver.add_green_space_cooling(selected, cooling_rate=2.0)
result = solver.evolve(t_final=7200, dt=60)
T_final = result['final_temperature'].reshape((30, 30))
print(f"   Cooling: {T0.mean() - T_final.mean():.2f}°C average reduction")

print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)
print(f"Problem: {grid.n_rows}×{grid.n_cols} grid, {problem.n_candidates} candidates")
print(f"Solution: {stats['n_green_cells']} greens, {stats['total_area_m2']/1e4:.2f} ha")
print(f"Network: {metrics['n_components']} component(s), coverage {coverage['coverage_fraction']:.1%}")
print(f"Cooling: {T0.mean() - T_final.mean():.2f}°C average, {(T0-T_final).max():.2f}°C max")
print("=" * 70)
print("Demo completed successfully! ✓")
