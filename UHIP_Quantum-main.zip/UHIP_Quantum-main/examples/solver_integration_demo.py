"""
Demonstration of Unified Solver Integration Interface

This example shows how to use the unified solver interface to solve
QUBO problems with different algorithms and compare their results.

The unified interface provides:
1. Consistent API across all solvers
2. Standardized result format
3. Verification checkpoints for SA (SC-1, SC-2, SC-3)
4. Easy solver comparison

Author: UHI-QUBO Research Framework
"""

import numpy as np
import time
from typing import List, Dict, Any

from core.solver_integration import (
    create_solver,
    SolutionResult,
    SimulatedAnnealingSolver,
    TabuSearchSolver,
    GeneticAlgorithmSolver,
    SimulatedQuantumAnnealingSolver
)


def create_test_qubo(n: int = 10, density: float = 0.3, seed: int = 42) -> np.ndarray:
    """
    Create a random symmetric QUBO matrix for testing.
    
    Args:
        n: Problem dimension
        density: Sparsity of the matrix
        seed: Random seed
        
    Returns:
        Symmetric QUBO matrix
    """
    rng = np.random.default_rng(seed)
    
    # Create random sparse matrix
    Q = np.zeros((n, n))
    num_entries = int(n * n * density)
    
    for _ in range(num_entries):
        i = rng.integers(0, n)
        j = rng.integers(0, n)
        value = rng.uniform(-10, 10)
        Q[i, j] = value
    
    # Symmetrize
    Q = (Q + Q.T) / 2
    
    return Q


def solve_with_all_solvers(Q: np.ndarray, seed: int = 42) -> Dict[str, SolutionResult]:
    """
    Solve QUBO problem with all available solvers.
    
    Args:
        Q: QUBO matrix
        seed: Random seed for reproducibility
        
    Returns:
        Dictionary mapping solver names to results
    """
    results = {}
    
    print(f"Problem size: {Q.shape[0]} variables")
    print("=" * 70)
    
    # Simulated Annealing with verification
    print("\n1. Simulated Annealing")
    print("-" * 70)
    sa_solver = SimulatedAnnealingSolver(seed=seed)
    sa_result = sa_solver.solve(
        Q,
        max_iterations=5000,
        initial_temperature=100.0,
        final_temperature=0.01,
        cooling_schedule='exponential',
        cooling_rate=0.95,
        verify_checkpoints=True,
        verbose=False
    )
    results['Simulated Annealing'] = sa_result
    print(f"Energy: {sa_result.energy:.6f}")
    print(f"Time: {sa_result.execution_time:.3f}s")
    if sa_result.verification_results:
        all_passed = sa_result.verification_results.get('all_checkpoints_passed', False)
        print(f"Verification: {'✓ All checkpoints passed' if all_passed else '✗ Some checks failed'}")
    
    # Tabu Search
    print("\n2. Tabu Search")
    print("-" * 70)
    ts_solver = TabuSearchSolver(seed=seed)
    ts_result = ts_solver.solve(
        Q,
        max_iterations=5000,
        tabu_tenure=10,
        adaptive_tabu=True,
        aspiration_enabled=True,
        verbose=False
    )
    results['Tabu Search'] = ts_result
    print(f"Energy: {ts_result.energy:.6f}")
    print(f"Time: {ts_result.execution_time:.3f}s")
    
    # Genetic Algorithm
    print("\n3. Genetic Algorithm")
    print("-" * 70)
    ga_solver = GeneticAlgorithmSolver(seed=seed)
    ga_result = ga_solver.solve(
        Q,
        population_size=100,
        max_generations=100,
        crossover_rate=0.8,
        mutation_rate=0.01,
        elitism_count=5,
        verbose=False
    )
    results['Genetic Algorithm'] = ga_result
    print(f"Energy: {ga_result.energy:.6f}")
    print(f"Time: {ga_result.execution_time:.3f}s")
    
    # Simulated Quantum Annealing
    print("\n4. Simulated Quantum Annealing")
    print("-" * 70)
    sqa_solver = SimulatedQuantumAnnealingSolver(seed=seed)
    sqa_result = sqa_solver.solve(
        Q,
        num_trotter_replicas=10,
        num_sweeps=500,
        sweeps_per_step=10,
        gamma_initial=2.0,
        gamma_final=0.01,
        temp_initial=0.5,
        temp_final=0.01,
        verbose=False
    )
    results['Simulated Quantum Annealing'] = sqa_result
    print(f"Energy: {sqa_result.energy:.6f}")
    print(f"Time: {sqa_result.execution_time:.3f}s")
    
    return results


def compare_results(results: Dict[str, SolutionResult]):
    """
    Compare and display results from different solvers.
    
    Args:
        results: Dictionary of solver results
    """
    print("\n" + "=" * 70)
    print("COMPARISON SUMMARY")
    print("=" * 70)
    
    # Find best result
    best_energy = min(r.energy for r in results.values())
    best_solvers = [name for name, r in results.items() if abs(r.energy - best_energy) < 1e-6]
    
    print(f"\nBest energy found: {best_energy:.6f}")
    print(f"Best solver(s): {', '.join(best_solvers)}")
    
    # Detailed comparison table
    print("\nDetailed Results:")
    print("-" * 70)
    print(f"{'Solver':<30} {'Energy':<15} {'Time (s)':<12} {'Iterations':<12}")
    print("-" * 70)
    
    for name, result in results.items():
        iterations = result.convergence_data.get('iterations', 'N/A')
        # Use text marker for better terminal compatibility
        marker = "[BEST]" if name in best_solvers else "      "
        print(f"{marker} {name:<28} {result.energy:<15.6f} {result.execution_time:<12.3f} {iterations:<12}")
    
    print("-" * 70)
    
    # Convergence analysis
    print("\nConvergence Analysis:")
    print("-" * 70)
    for name, result in results.items():
        energy_history = result.convergence_data.get('energy_history', [])
        if len(energy_history) > 1:
            improvement = energy_history[0] - energy_history[-1]
            print(f"{name}:")
            print(f"  Initial energy: {energy_history[0]:.6f}")
            print(f"  Final energy: {energy_history[-1]:.6f}")
            print(f"  Total improvement: {improvement:.6f}")


def demonstrate_factory_pattern():
    """Demonstrate the factory pattern for creating solvers."""
    print("\n" + "=" * 70)
    print("FACTORY PATTERN DEMONSTRATION")
    print("=" * 70)
    
    # Small test problem
    Q = np.array([
        [2.0, -1.0, 0.0],
        [-1.0, 3.0, -1.0],
        [0.0, -1.0, 2.0]
    ])
    
    # Create solvers using factory
    solver_types = ['sa', 'ts', 'ga', 'sqa']
    
    print("\nCreating solvers using factory pattern:")
    for solver_type in solver_types:
        solver = create_solver(solver_type, seed=42)
        print(f"  ✓ Created: {solver.__class__.__name__}")
        
        # Quick solve
        if solver_type == 'sa':
            result = solver.solve(Q, max_iterations=100, verbose=False)
        elif solver_type == 'ts':
            result = solver.solve(Q, max_iterations=100, verbose=False)
        elif solver_type == 'ga':
            result = solver.solve(Q, population_size=20, max_generations=10, verbose=False)
        elif solver_type == 'sqa':
            result = solver.solve(Q, num_trotter_replicas=4, num_sweeps=50, verbose=False)
        
        print(f"    Energy: {result.energy:.4f}, Time: {result.execution_time:.3f}s")


def demonstrate_verification_checkpoints():
    """Demonstrate SA verification checkpoints."""
    print("\n" + "=" * 70)
    print("VERIFICATION CHECKPOINTS DEMONSTRATION (SA)")
    print("=" * 70)
    
    # Test problem
    Q = np.array([
        [1.0, -2.0, 1.0, 0.0],
        [-2.0, 2.0, -1.0, 0.5],
        [1.0, -1.0, 3.0, -1.0],
        [0.0, 0.5, -1.0, 1.0]
    ])
    
    solver = SimulatedAnnealingSolver(seed=42)
    result = solver.solve(
        Q,
        max_iterations=2000,
        initial_temperature=50.0,
        final_temperature=0.1,
        cooling_schedule='exponential',
        verify_checkpoints=True,
        verbose=False
    )
    
    print(f"\nSolution: {result.solution}")
    print(f"Energy: {result.energy:.6f}")
    
    if result.verification_results:
        print("\nCheckpoint Results:")
        
        # SC-1
        sc1 = result.verification_results.get('SC-1_metropolis_criterion', {})
        print(f"\n  SC-1 (Metropolis Criterion): {'✓ PASSED' if sc1.get('passed') else '✗ FAILED'}")
        print(f"    Acceptance rate: {sc1.get('final_acceptance_rate', 0):.4f}")
        
        # SC-2
        sc2 = result.verification_results.get('SC-2_energy_monotonicity', {})
        print(f"\n  SC-2 (Energy Monotonicity): {'✓ PASSED' if sc2.get('passed') else '✗ FAILED'}")
        print(f"    Monotonic: {sc2.get('is_monotonic', False)}")
        print(f"    Improvements: {sc2.get('num_improvements', 0)}")
        
        # SC-3
        sc3 = result.verification_results.get('SC-3_temperature_schedule', {})
        print(f"\n  SC-3 (Temperature Schedule): {'✓ PASSED' if sc3.get('passed') else '✗ FAILED'}")
        print(f"    Schedule type: {sc3.get('schedule_type', 'unknown')}")
        print(f"    T_initial: {sc3.get('initial_temperature', 0):.2f}")
        print(f"    T_final: {sc3.get('final_temperature', 0):.2f}")
        print(f"    Decreasing: {sc3.get('is_decreasing', False)}")


def main():
    """Main demonstration function."""
    print("\n" + "=" * 70)
    print("UNIFIED SOLVER INTEGRATION INTERFACE DEMONSTRATION")
    print("=" * 70)
    
    # 1. Factory pattern
    demonstrate_factory_pattern()
    
    # 2. Verification checkpoints
    demonstrate_verification_checkpoints()
    
    # 3. Solve with all solvers and compare
    print("\n" + "=" * 70)
    print("SOLVING WITH ALL SOLVERS")
    print("=" * 70)
    
    # Create test problem
    Q = create_test_qubo(n=15, density=0.3, seed=42)
    
    # Solve with all solvers
    results = solve_with_all_solvers(Q, seed=42)
    
    # Compare results
    compare_results(results)
    
    print("\n" + "=" * 70)
    print("DEMONSTRATION COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    main()
