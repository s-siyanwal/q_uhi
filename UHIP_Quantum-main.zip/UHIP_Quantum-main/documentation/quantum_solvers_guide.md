# Quantum-Inspired Solver Modules Documentation

## Overview

This package implements **Simulated Quantum Annealing (SQA)** for solving QUBO problems using quantum-inspired optimization. The implementation is based on rigorous mathematical formulations from quantum annealing theory and path integral Monte Carlo methods.

## Modules

### 1. `trotter_expansion.py`

Implements the Suzuki-Trotter decomposition for mapping quantum systems to classical replicated systems.

#### Mathematical Foundation

The quantum Ising Hamiltonian:
```
H(t) = H_classical + H_quantum
H_classical = -Σ_{i<j} J_ij s_i s_j - Σ_i h_i s_i
H_quantum = -Γ(t) Σ_i σ_i^x
```

is approximated via Suzuki-Trotter expansion:
```
e^{-βH} ≈ [e^{-βH_cl/M} e^{-βH_q/M}]^M
```

This creates M replicas with effective coupling:
```
J_τ = -(1/(2β)) ln[tanh(βΓ/M)]
```

#### Key Classes

- **`TrotterExpansion`**: Main class for Trotter decomposition
  - `compute_coupling_strength(beta, gamma)`: Compute J_τ
  - `initialize_replicas(n)`: Create M×n replica system
  - `compute_effective_energy(replicas, h, J, J_tau)`: Full energy
  - `compute_replica_delta_energy(...)`: Fast single-flip energy change
  - `replicas_to_binary(replicas)`: Extract solution via majority voting

- **`TrotterParameters`**: Parameter container

#### Usage Example

```python
from core.solvers.quantum import TrotterExpansion

trotter = TrotterExpansion(num_trotter_replicas=10)

# Compute coupling for β=2, Γ=1.5
J_tau = trotter.compute_coupling_strength(beta=2.0, gamma=1.5)

# Initialize 10 replicas for 20-variable problem
replicas = trotter.initialize_replicas(n=20)

# Compute energy
energy = trotter.compute_effective_energy(replicas, h, J, J_tau)
```

### 2. `metropolis_sampler.py`

Implements Metropolis-Hastings Monte Carlo sampling for the replicated quantum system.

#### Mathematical Foundation

Samples from the effective classical distribution:
```
P(s^1,...,s^M) = (1/Z) exp(-β E_eff[s^1,...,s^M])
```

using Metropolis acceptance criterion:
```
α = min(1, exp(-β ΔE))
```

#### Key Classes

- **`MetropolisSampler`**: Metropolis algorithm implementation
  - `metropolis_step(...)`: Single MC step
  - `sample(...)`: Generate equilibrium samples
  - `adaptive_sampling(...)`: Adaptive strategy selection
  
- **`FlipStrategy`** (Enum): Move proposal strategies
  - `SINGLE_REPLICA_SINGLE_SPIN`: Standard single spin flip
  - `MULTI_REPLICA_SINGLE_SPIN`: Vertical flip across all replicas
  - `RANDOM_REPLICA_SINGLE_SPIN`: Partial vertical flip
  
- **`SamplingStatistics`**: Track acceptance rates and performance

#### Usage Example

```python
from core.solvers.quantum import MetropolisSampler, FlipStrategy

sampler = MetropolisSampler(
    flip_strategy=FlipStrategy.SINGLE_REPLICA_SINGLE_SPIN,
    seed=42
)

# Single Metropolis step
replicas_new, accepted, delta_E = sampler.metropolis_step(
    replicas, h, J, J_tau, beta
)

# Sample for equilibration
replicas_eq, info = sampler.sample(
    replicas, h, J, J_tau, beta,
    num_steps=1000,
    burnin=200,
    thinning=2
)
```

### 3. `simulated_quantum_annealing.py`

Main SQA solver integrating Trotter expansion and Metropolis sampling with annealing schedules.

#### Mathematical Foundation

Quantum annealing evolves the system according to time-dependent schedules:
```
Γ(t) = Γ_0 (1 - t/t_max)^α      (Transverse field)
T(t) = T_0 (t/t_max)^β           (Temperature)
```

The algorithm maintains the system near the instantaneous ground state by slow evolution (adiabatic theorem).

#### Key Classes

- **`SimulatedQuantumAnnealing`**: Main solver
  - Inherits from `BaseSolver`
  - `solve(Q)`: Solve QUBO problem
  - `solve_with_restarts(Q, num_restarts)`: Multi-start optimization
  - `get_annealing_diagnostics()`: Detailed performance metrics

- **`AnnealingSchedule`**: Annealing schedule configuration
  - `get_gamma(t, t_max)`: Compute Γ(t)
  - `get_temperature(t, t_max)`: Compute T(t)
  - Supports: linear, power_law, exponential schedules

#### Usage Example

```python
from core.solvers.quantum import (
    SimulatedQuantumAnnealing,
    AnnealingSchedule
)
import numpy as np

# Create QUBO problem
Q = np.random.randn(20, 20)
Q = (Q + Q.T) / 2

# Configure annealing schedule
schedule = AnnealingSchedule(
    gamma_initial=2.0,
    gamma_final=0.05,
    temp_initial=0.5,
    temp_final=0.01,
    schedule_type='linear'
)

# Create solver
sqa = SimulatedQuantumAnnealing(
    num_trotter_replicas=10,
    num_sweeps=1000,
    sweeps_per_step=10,
    schedule=schedule,
    seed=42,
    verbose=True
)

# Solve
result = sqa.solve(Q)

print(f"Best energy: {result.best_energy}")
print(f"Solution: {result.best_solution}")
print(f"Acceptance rate: {result.metadata['average_acceptance_rate']}")
```

## Complete Example Workflow

```python
import numpy as np
from core.solvers.quantum import (
    SimulatedQuantumAnnealing,
    AnnealingSchedule,
    FlipStrategy
)
from core.utils.experiment_logger import ExperimentLogger

# Create logger
logger = ExperimentLogger("sqa_experiment")

# Define QUBO problem (minimize x^T Q x)
n = 50
Q = np.random.randn(n, n)
Q = (Q + Q.T) / 2  # Symmetric

# Configure aggressive annealing schedule
schedule = AnnealingSchedule(
    gamma_initial=3.0,
    gamma_final=0.01,
    temp_initial=1.0,
    temp_final=0.001,
    schedule_type='power_law',
    gamma_exponent=2.0,
    temp_exponent=1.5
)

# Create solver with multiple restarts
sqa = SimulatedQuantumAnnealing(
    num_trotter_replicas=20,
    num_sweeps=2000,
    sweeps_per_step=20,
    schedule=schedule,
    flip_strategy=FlipStrategy.SINGLE_REPLICA_SINGLE_SPIN,
    logger=logger,
    seed=42,
    verbose=True
)

# Solve with restarts
result = sqa.solve_with_restarts(Q, num_restarts=5)

# Analyze results
print(f"\nFinal Results:")
print(f"  Energy: {result.best_energy:.6f}")
print(f"  Runtime: {result.runtime:.2f}s")
print(f"  Iterations: {result.iterations}")
print(f"  Solution density: {np.sum(result.best_solution)}/{n}")

# Get diagnostics
diagnostics = sqa.get_annealing_diagnostics()
print(f"\nDiagnostics:")
print(f"  Γ range: {diagnostics['gamma_range']}")
print(f"  T range: {diagnostics['temp_range']}")
print(f"  Mean acceptance: {diagnostics['acceptance_rate_mean']:.3f}")
print(f"  Energy improvement: {diagnostics['energy_improvement']:.6f}")

# Finalize logging
logger.finalize()
```

## Parameter Guidelines

### Number of Trotter Replicas (M)
- **Small problems (n < 20)**: M = 4-10
- **Medium problems (20 ≤ n < 100)**: M = 10-20
- **Large problems (n ≥ 100)**: M = 20-50
- Higher M = better quantum approximation but slower

### Annealing Sweeps
- **Quick exploration**: 100-500 sweeps
- **Production runs**: 1000-5000 sweeps
- **High-quality solutions**: 5000-10000 sweeps

### Transverse Field Schedule
- **Initial Γ**: 1.5-3.0 (strong quantum fluctuations)
- **Final Γ**: 0.01-0.1 (weak quantum effects)
- **Exponent α**: 1.0-3.0 (higher = more aggressive cooling)

### Temperature Schedule
- **Initial T**: 0.5-2.0 (thermal exploration)
- **Final T**: 0.001-0.01 (freezing)
- **Exponent β**: 1.0-2.0

### Monte Carlo Sweeps per Step
- **Fast equilibration**: 5-10 sweeps
- **Standard**: 10-20 sweeps
- **Careful equilibration**: 20-50 sweeps

## Mathematical References

1. **Suzuki-Trotter Decomposition**:
   - Suzuki, M. (1976). "Relationship between d-dimensional quantal spin systems and (d+1)-dimensional Ising systems"
   
2. **Quantum Annealing**:
   - Kadowaki & Nishimori (1998): "Quantum annealing in the transverse Ising model"
   - Santoro et al. (2002): "Theory of quantum annealing of an Ising spin glass"
   
3. **Path Integral Monte Carlo**:
   - Martoňák et al. (2002): "Quantum annealing by path-integral Monte Carlo"
   - Feynman & Hibbs: "Quantum Mechanics and Path Integrals"
   
4. **Monte Carlo Methods**:
   - Metropolis et al. (1953): "Equation of State Calculations by Fast Computing Machines"
   - Newman & Barkema: "Monte Carlo Methods in Statistical Physics"

5. **UHI-QUBO Mathematical Documents**:
   - Simulated Quantum Annealing Section
   - Path Integral Formulation
   - Suzuki-Trotter Theory

## Integration with Framework

These modules integrate seamlessly with the UHI-QUBO framework:

- **QUBO/Ising Conversion**: Uses `IsingConverter` for automatic conversion
- **Experiment Logging**: Full integration with `ExperimentLogger`
- **Base Solver**: Inherits from `BaseSolver` for consistent interface
- **Result Format**: Returns standard `SolverResult` objects

## Performance Characteristics

- **Time Complexity**: O(M × n × sweeps × sweeps_per_step)
- **Space Complexity**: O(M × n) for replica storage
- **Parallelization**: Potential for GPU acceleration of replica updates
- **Convergence**: Depends on spectral gap and annealing schedule

## Testing

Run comprehensive tests:
```bash
python scripts/test_quantum_solvers.py
```

Tests validate:
- Trotter coupling calculations
- Energy consistency (full vs. delta)
- Metropolis detailed balance
- Annealing schedule correctness
- End-to-end SQA solve

## Future Extensions

Possible enhancements:
1. **Parallel Tempering**: Multiple temperatures simultaneously
2. **Cluster Updates**: Swendsen-Wang or Wolff algorithms
3. **GPU Acceleration**: CUDA/OpenCL for replica updates
4. **Adaptive Schedules**: Learning-based schedule optimization
5. **Hybrid Classical-Quantum**: Interface with real quantum hardware
