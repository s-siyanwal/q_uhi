# Unified Solver Integration Interface

## Overview

The unified solver integration interface provides a standardized way to interact with all QUBO solvers in the UHI-QUBO framework. This module implements the requirements from File 07 of the UHI-QUBO specification.

## Architecture

### Core Components

```
core/solver_integration/
├── __init__.py                 # Module exports
└── solver_interface.py         # Main implementation
    ├── SolverInterface         # Abstract base class
    ├── SolutionResult          # Standardized result container
    ├── SimulatedAnnealingSolver
    ├── TabuSearchSolver
    ├── GeneticAlgorithmSolver
    ├── SimulatedQuantumAnnealingSolver
    └── create_solver()         # Factory function
```

## Classes

### SolverInterface (Abstract Base Class)

Abstract base class that defines the unified interface for all QUBO solvers.

**Methods:**
- `solve(Q, **kwargs) -> SolutionResult`: Solve QUBO problem

**Protected Methods:**
- `_validate_qubo(Q)`: Validate QUBO matrix
- `_standardize_result(...)`: Convert solver-specific result to SolutionResult

### SolutionResult (Dataclass)

Standardized container for solver results.

**Attributes:**
- `solution: np.ndarray` - Binary solution vector
- `energy: float` - Objective value E(x) = x^T Q x
- `execution_time: float` - Runtime in seconds
- `solver_info: Dict[str, Any]` - Solver metadata
  - `algorithm`: Solver name
  - `parameters`: Algorithm-specific parameters
  - `statistics`: Performance statistics
- `convergence_data: Dict[str, Any]` - Optimization trajectory
  - `energy_history`: List of best energies
  - `iterations`: Total iterations
  - Algorithm-specific metrics
- `verification_results: Optional[Dict]` - Checkpoint validation results

**Methods:**
- `to_dict() -> Dict`: Convert to dictionary for serialization

## Solver Wrappers

### SimulatedAnnealingSolver

Wrapper for classical simulated annealing with verification checkpoints.

**Key Features:**
- Multiple cooling schedules (exponential, linear, logarithmic)
- Metropolis acceptance criterion
- Efficient ΔE computation
- Verification checkpoints (SC-1, SC-2, SC-3)

**Usage:**
```python
from core.solver_integration import SimulatedAnnealingSolver

solver = SimulatedAnnealingSolver(seed=42)
result = solver.solve(
    Q,
    max_iterations=5000,
    initial_temperature=100.0,
    final_temperature=0.01,
    cooling_schedule='exponential',
    cooling_rate=0.95,
    verify_checkpoints=True
)
```

**Verification Checkpoints:**

**SC-1: Metropolis Acceptance Criterion**
- Validates acceptance probability follows P = exp(-ΔE/T)
- Tracks acceptance rates throughout optimization
- Verifies improvements are always accepted
- Checks acceptance rate is in valid range [0, 1]

**SC-2: Energy Monotonicity**
- Ensures best energy is non-increasing
- Counts number of improvements
- Calculates improvement rate
- Validates energy improvement

**SC-3: Temperature Schedule**
- Verifies temperature follows specified schedule
- Confirms monotonic decrease
- Validates initial and final temperatures match configuration

### TabuSearchSolver

Wrapper for tabu search metaheuristic.

**Key Features:**
- Tabu list management
- Aspiration criterion
- Adaptive tabu tenure
- Periodic diversification

**Usage:**
```python
from core.solver_integration import TabuSearchSolver

solver = TabuSearchSolver(seed=42)
result = solver.solve(
    Q,
    max_iterations=5000,
    tabu_tenure=10,
    adaptive_tabu=True,
    aspiration_enabled=True,
    diversification_interval=500
)
```

### GeneticAlgorithmSolver

Wrapper for genetic algorithm.

**Key Features:**
- Tournament selection
- Multiple crossover operators
- Adaptive mutation
- Elitism
- Diversity monitoring

**Usage:**
```python
from core.solver_integration import GeneticAlgorithmSolver

solver = GeneticAlgorithmSolver(seed=42)
result = solver.solve(
    Q,
    population_size=100,
    max_generations=200,
    crossover_rate=0.8,
    mutation_rate=0.01,
    crossover_type='single_point',
    elitism_count=5
)
```

### SimulatedQuantumAnnealingSolver

Wrapper for simulated quantum annealing.

**Key Features:**
- Path integral Monte Carlo
- Suzuki-Trotter decomposition
- Transverse field annealing
- Quantum tunneling effects

**Usage:**
```python
from core.solver_integration import SimulatedQuantumAnnealingSolver

solver = SimulatedQuantumAnnealingSolver(seed=42)
result = solver.solve(
    Q,
    num_trotter_replicas=10,
    num_sweeps=1000,
    sweeps_per_step=10,
    gamma_initial=2.0,
    gamma_final=0.01,
    temp_initial=0.5,
    temp_final=0.01,
    schedule_type='linear'
)
```

## Factory Pattern

The `create_solver()` function provides a convenient way to instantiate solvers.

**Usage:**
```python
from core.solver_integration import create_solver

# Using short names
solver = create_solver('sa', seed=42)  # Simulated Annealing
solver = create_solver('ts', seed=42)  # Tabu Search
solver = create_solver('ga', seed=42)  # Genetic Algorithm
solver = create_solver('sqa', seed=42) # Simulated Quantum Annealing

# Using full names
solver = create_solver('simulated_annealing', seed=42)
solver = create_solver('tabu_search', seed=42)
solver = create_solver('genetic_algorithm', seed=42)
solver = create_solver('simulated_quantum_annealing', seed=42)

# Solve
result = solver.solve(Q)
```

## Complete Example

```python
import numpy as np
from core.solver_integration import create_solver

# Define QUBO problem
Q = np.array([
    [2.0, -1.0, 0.5],
    [-1.0, 3.0, -0.5],
    [0.5, -0.5, 1.5]
])

# Create solver
solver = create_solver('sa', seed=42)

# Solve with custom parameters
result = solver.solve(
    Q,
    max_iterations=5000,
    initial_temperature=100.0,
    cooling_schedule='exponential',
    verify_checkpoints=True,
    verbose=False
)

# Access results
print(f"Solution: {result.solution}")
print(f"Energy: {result.energy:.6f}")
print(f"Time: {result.execution_time:.3f}s")
print(f"Algorithm: {result.solver_info['algorithm']}")
print(f"Iterations: {result.convergence_data['iterations']}")

# Check verification
if result.verification_results:
    all_passed = result.verification_results['all_checkpoints_passed']
    print(f"Verification: {'✓ PASSED' if all_passed else '✗ FAILED'}")

# Serialize to JSON
import json
result_dict = result.to_dict()
json_str = json.dumps(result_dict, indent=2)
```

## Comparing Multiple Solvers

```python
import numpy as np
from core.solver_integration import create_solver

Q = create_test_qubo(n=20)
solver_types = ['sa', 'ts', 'ga', 'sqa']
results = {}

for solver_type in solver_types:
    solver = create_solver(solver_type, seed=42)
    result = solver.solve(Q, max_iterations=1000)
    results[solver_type] = result

# Find best
best_energy = min(r.energy for r in results.values())
best_solver = [k for k, r in results.items() if r.energy == best_energy][0]

print(f"Best solver: {best_solver}")
print(f"Best energy: {best_energy:.6f}")

# Compare
for name, result in results.items():
    print(f"{name}: E={result.energy:.6f}, t={result.execution_time:.3f}s")
```

## Integration with Existing Code

The unified interface wraps existing solver implementations:

- `SimulatedAnnealingSolver` → `core/solvers/classical/simulated_annealing.py`
- `TabuSearchSolver` → `core/solvers/classical/tabu_search.py`
- `GeneticAlgorithmSolver` → `core/solvers/classical/genetic_algorithm.py`
- `SimulatedQuantumAnnealingSolver` → `core/solvers/quantum/simulated_quantum_annealing.py`

All original functionality is preserved while providing a standardized interface.

## Extending the Framework

To add a new solver:

1. Implement the solver in the appropriate directory (`core/solvers/classical/` or `core/solvers/quantum/`)
2. Create a wrapper class that inherits from `SolverInterface`
3. Implement the `solve()` method
4. Use `_standardize_result()` to convert to `SolutionResult`
5. Add to factory function in `create_solver()`

Example:

```python
class MyCustomSolver(SolverInterface):
    def __init__(self, logger=None, seed=None):
        super().__init__(logger, seed)
        self.solver = MyCustomSolverImpl(logger=logger, seed=seed)
    
    def solve(self, Q, **kwargs):
        self._validate_qubo(Q)
        base_result = self.solver.solve(Q, **kwargs)
        return self._standardize_result(base_result, 'my_custom_solver')
```

## Testing

Run the comprehensive demo:

```bash
cd /home/runner/work/UHIP_Quantum/UHIP_Quantum
python3 examples/solver_integration_demo.py
```

This demonstrates:
- Factory pattern usage
- Verification checkpoint validation
- Solver comparison
- Result serialization

## Performance Considerations

- All solvers support random seeding for reproducibility
- Results are JSON-serializable for easy persistence
- Convergence data is tracked automatically
- Memory-efficient: only stores necessary history

## Best Practices

1. **Always set a random seed** for reproducible results
2. **Enable verification checkpoints** for SA to validate algorithm correctness
3. **Use factory pattern** for easy solver switching
4. **Compare multiple solvers** on your problem before choosing one
5. **Serialize results** for experiment tracking and analysis

## References

- File 07: Solver Integration Requirements (UHI-QUBO specification)
- Verification checkpoints: SC-1, SC-2, SC-3 specifications
- Existing solver implementations in `core/solvers/`
