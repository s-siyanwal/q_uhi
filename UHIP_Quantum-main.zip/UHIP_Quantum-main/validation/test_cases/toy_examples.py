"""
Toy Example Test Cases for UHI-QUBO Validation

This module provides small, manually verifiable test instances for the UHI-QUBO
framework. Each example includes known optimal solutions or expected behaviors
to facilitate testing and validation.

Examples:
    >>> from validation.test_cases.toy_examples import get_4cell_example
    >>> problem, expected_solution = get_4cell_example()
    >>> # Verify the problem can be solved correctly
    >>> Q, metadata = problem.build_qubo()
    >>> # expected_solution provides the known optimal greening pattern
"""

import numpy as np
from typing import Dict, Any, Tuple, Optional
from dataclasses import dataclass

from core.problem_modeling.uhi_green_layout import UHIGreenLayoutProblem, UHIProblemConfig, GridCell
from core.problem_modeling.cooling_kernels import GaussianCoolingKernel, ExponentialCoolingKernel


@dataclass
class ToyExampleSolution:
    """Expected solution for a toy example problem.
    
    Attributes:
        solution_vector: Binary solution vector (0/1 for each candidate cell)
        expected_energy: Expected QUBO energy for this solution
        expected_green_cells: Number of cells that should be greened
        expected_area_used: Total greening area used
        is_optimal: Whether this is the known optimal solution
        description: Human-readable description of the solution
        manual_verification_notes: Notes on how to verify this solution manually
    """
    solution_vector: np.ndarray
    expected_energy: float
    expected_green_cells: int
    expected_area_used: float
    is_optimal: bool
    description: str
    manual_verification_notes: str


def get_4cell_example(
    penalty_weight: float = 100.0,
    area_budget_fraction: float = 0.5
) -> Tuple[UHIGreenLayoutProblem, ToyExampleSolution]:
    """
    Create a minimal 2x2 grid with 4 cells.
    
    This is the simplest possible UHI-QUBO problem, useful for:
    - Testing basic QUBO construction
    - Verifying constraint encoding
    - Manual calculation verification
    - Algorithm debugging
    
    Grid Layout (2x2):
    ```
    [0,0] [0,1]
    [1,0] [1,1]
    ```
    
    Problem Setup:
    - 4 cells total, all candidates for greening
    - Uniform cell area: 100 m²
    - Uniform greening cost: 10 units
    - Gaussian cooling kernel with small sigma (local effects)
    - Area budget: 50% of total area (200 m²)
    - Budget constraint: 20 units (2 cells max)
    
    Expected Behavior:
    - Optimal: Select 2 adjacent cells for maximum cooling interaction
    - Diagonal cells [0,0] + [1,1] provide better coverage than same-row
    
    Args:
        penalty_weight: Weight for constraint penalties (default: 100.0)
        area_budget_fraction: Fraction of total area for greening (default: 0.5)
        
    Returns:
        problem: Configured UHIGreenLayoutProblem instance
        expected_solution: ToyExampleSolution with known optimal solution
        
    Example:
        >>> problem, solution = get_4cell_example()
        >>> Q, meta = problem.build_qubo()
        >>> print(f"QUBO size: {Q.shape}")
        QUBO size: (4, 4)
        >>> print(f"Optimal selects {solution.expected_green_cells} cells")
        Optimal selects 2 cells
    """
    # Configure minimal problem
    config = UHIProblemConfig(
        grid_rows=2,
        grid_cols=2,
        cell_size=10.0,  # 10m x 10m = 100 m² per cell
        cooling_kernel_type='gaussian',
        cooling_length_scale=15.0,  # Moderate interaction range
        cooling_amplitude=-2.0,     # Negative for cooling benefit
        area_budget_fraction=area_budget_fraction,
        total_budget=20.0,  # Allows 2 cells at cost 10 each
        penalty_weight=penalty_weight,
        min_green_cells=None,
        max_green_cells=None
    )
    
    # Create problem instance
    problem = UHIGreenLayoutProblem(config)
    
    # Manually create 4-cell grid
    cells = []
    cell_area = config.cell_size ** 2  # 100 m²
    greening_cost = 10.0
    base_temp = 35.0  # Hot urban area
    
    for i in range(2):
        for j in range(2):
            cell = GridCell(
                index=i * 2 + j,
                position=np.array([i * config.cell_size, j * config.cell_size]),
                area=cell_area,
                land_use_type='candidate',
                base_temperature=base_temp,
                greening_cost=greening_cost,
                population_density=1000.0
            )
            cells.append(cell)
    
    problem.cells = cells
    problem.n_cells = 4
    problem.candidate_indices = [0, 1, 2, 3]
    problem.n_candidates = 4
    problem.fixed_indices = set()
    
    # Setup cooling model
    kernel = GaussianCoolingKernel(
        sigma=config.cooling_length_scale,
        amplitude=config.cooling_amplitude
    )
    problem.setup_cooling_model(kernel=kernel)
    
    # Known optimal solution: cells [0,1] and [1,0] or [0,0] and [1,1]
    # Diagonal [0,0] + [1,1] maximizes spatial coverage
    # Distance between [0,0] and [1,1] is sqrt(2) * 10 = 14.14m
    optimal_solution = np.array([1, 0, 0, 1], dtype=int)
    
    expected_solution = ToyExampleSolution(
        solution_vector=optimal_solution,
        expected_energy=None,  # Will depend on kernel parameters
        expected_green_cells=2,
        expected_area_used=200.0,
        is_optimal=True,
        description="Diagonal cells [0,0] and [1,1] for maximum spatial coverage",
        manual_verification_notes="""
        Manual Verification Steps:
        1. Check solution uses exactly 2 cells (budget constraint)
        2. Total area = 2 * 100 = 200 m² (within budget)
        3. Total cost = 2 * 10 = 20 units (within budget)
        4. Cooling benefit: Both cells cool each other via Gaussian kernel
        5. Distance d = sqrt(2)*10 ≈ 14.14m
        6. Interaction strength: exp(-d²/(2*15²)) ≈ 0.78
        7. Alternative [0,1]+[1,0] has same distance, equivalent energy
        8. Adjacent cells [0,0]+[0,1] have d=10m, stronger interaction
        
        Note: Actual optimal depends on kernel parameters. Adjacent cells
        may be better if cooling interaction dominates over coverage.
        """
    )
    
    return problem, expected_solution


def get_8cell_example(
    penalty_weight: float = 100.0,
    area_budget_fraction: float = 0.375,
    include_fixed_green: bool = False
) -> Tuple[UHIGreenLayoutProblem, ToyExampleSolution]:
    """
    Create a 2x4 grid with 8 cells for medium-scale testing.
    
    Grid Layout (2x4):
    ```
    [0,0] [0,1] [0,2] [0,3]
    [1,0] [1,1] [1,2] [1,3]
    ```
    
    Problem Setup:
    - 8 cells total, 7 candidates (if include_fixed_green=True)
    - Uniform cell area: 100 m²
    - Variable greening costs (10, 12, 8, 15, ...)
    - Variable base temperatures (simulate different land uses)
    - Exponential cooling kernel (longer range than Gaussian)
    - Area budget: 37.5% (300 m² = 3 cells)
    - Budget constraint: 36 units
    
    Expected Behavior:
    - Select 3 cells balancing cost and cooling effectiveness
    - If fixed green at [0,0], optimal should cluster nearby
    - Cheaper cells [0,2] (cost=8) should be preferred
    
    Args:
        penalty_weight: Weight for constraint penalties
        area_budget_fraction: Fraction of area for greening (default: 0.375 = 3/8)
        include_fixed_green: If True, cell [0,0] is pre-greened
        
    Returns:
        problem: Configured UHIGreenLayoutProblem
        expected_solution: ToyExampleSolution with good solution
        
    Example:
        >>> problem, solution = get_8cell_example()
        >>> Q, meta = problem.build_qubo()
        >>> print(f"QUBO size: {Q.shape}")
        QUBO size: (7, 7) or (8, 8)
        >>> print(solution.description)
        Select 3 cheapest cells with good coverage
    """
    config = UHIProblemConfig(
        grid_rows=2,
        grid_cols=4,
        cell_size=10.0,
        cooling_kernel_type='exponential',
        cooling_length_scale=20.0,  # Longer range interactions
        cooling_amplitude=-3.0,
        area_budget_fraction=area_budget_fraction,
        total_budget=36.0,  # Allows 3 cells with varied costs
        penalty_weight=penalty_weight
    )
    
    problem = UHIGreenLayoutProblem(config)
    
    # Create heterogeneous grid
    cells = []
    cell_area = config.cell_size ** 2
    
    # Variable costs and temperatures
    greening_costs = [10.0, 12.0, 8.0, 15.0, 11.0, 9.0, 14.0, 10.0]
    base_temps = [36.0, 35.0, 37.0, 34.0, 36.5, 35.5, 35.0, 36.0]
    land_use_types = ['urban', 'commercial', 'urban', 'industrial',
                      'urban', 'residential', 'commercial', 'urban']
    
    for i in range(2):
        for j in range(4):
            idx = i * 4 + j
            is_fixed = (include_fixed_green and idx == 0)
            
            if is_fixed:
                land_use_type = 'existing_green'
            else:
                land_use_type = 'candidate'
            
            cell = GridCell(
                index=idx,
                position=np.array([i * config.cell_size, j * config.cell_size]),
                area=cell_area,
                land_use_type=land_use_type,
                base_temperature=base_temps[idx],
                greening_cost=greening_costs[idx],
                population_density=1000.0 + idx * 100
            )
            cells.append(cell)
    
    problem.cells = cells
    problem.n_cells = 8
    
    if include_fixed_green:
        problem.candidate_indices = [1, 2, 3, 4, 5, 6, 7]
        problem.n_candidates = 7
        problem.fixed_indices = {0}
    else:
        problem.candidate_indices = list(range(8))
        problem.n_candidates = 8
        problem.fixed_indices = set()
    
    # Setup cooling model
    kernel = ExponentialCoolingKernel(
        length_scale=config.cooling_length_scale,
        amplitude=config.cooling_amplitude
    )
    problem.setup_cooling_model(kernel=kernel)
    
    # Expected good solution: cheapest cells with reasonable coverage
    # Cells 2 (cost=8), 5 (cost=9), 0 (cost=10) or 7 (cost=10)
    # Total cost: 8+9+10=27 < 36 ✓
    if include_fixed_green:
        # Cell 0 already green, select next 3 cheapest
        expected_solution_vector = np.array([0, 1, 0, 1, 0, 1, 0], dtype=int)  # cells 1,3,5
    else:
        expected_solution_vector = np.array([0, 0, 1, 0, 0, 1, 0, 1], dtype=int)  # cells 2,5,7
    
    expected_solution = ToyExampleSolution(
        solution_vector=expected_solution_vector,
        expected_energy=None,
        expected_green_cells=3,
        expected_area_used=300.0,
        is_optimal=False,  # Heuristic solution, may not be true optimal
        description="Select 3 cheapest cells with good spatial coverage",
        manual_verification_notes="""
        Manual Verification:
        1. Count green cells: should be 3
        2. Check total cost ≤ 36 units
        3. Check total area = 300 m² ≤ budget
        4. Verify exponential cooling interactions
        5. Lower-cost cells should be preferred
        6. If fixed green exists, check it's at cell [0,0]
        
        This is a heuristic solution based on cost minimization.
        True optimal depends on cooling interaction strength.
        """
    )
    
    return problem, expected_solution


def get_simple_grid_layout(
    rows: int = 3,
    cols: int = 3,
    target_green_count: int = 3,
    penalty_weight: float = 100.0
) -> Tuple[UHIGreenLayoutProblem, ToyExampleSolution]:
    """
    Create a simple rectangular grid with exact count constraint.
    
    This example focuses on testing cardinality constraints (exact count)
    rather than area/budget constraints.
    
    Grid Layout (default 3x3):
    ```
    [0,0] [0,1] [0,2]
    [1,0] [1,1] [1,2]
    [2,0] [2,1] [2,2]
    ```
    
    Problem Setup:
    - Uniform cells (same area, cost, temperature)
    - Exact count constraint: select exactly target_green_count cells
    - Gaussian kernel with medium range
    - No area/budget constraints (focus on cardinality)
    
    Expected Behavior:
    - Select target_green_count cells
    - Clustering pattern for maximum cooling interaction
    - Center cell + neighbors often optimal for 3x3, k=3
    
    Args:
        rows: Number of grid rows
        cols: Number of grid columns
        target_green_count: Exact number of cells to green
        penalty_weight: Constraint penalty weight
        
    Returns:
        problem: UHIGreenLayoutProblem with exact count constraint
        expected_solution: ToyExampleSolution with clustered pattern
        
    Example:
        >>> problem, solution = get_simple_grid_layout(3, 3, 3)
        >>> # Expect clustered solution like center + 2 neighbors
    """
    config = UHIProblemConfig(
        grid_rows=rows,
        grid_cols=cols,
        cell_size=10.0,
        cooling_kernel_type='gaussian',
        cooling_length_scale=12.0,
        cooling_amplitude=-2.5,
        area_budget_fraction=1.0,  # No area constraint
        total_budget=1e6,  # No budget constraint
        penalty_weight=penalty_weight,
        min_green_cells=target_green_count,
        max_green_cells=target_green_count  # Exact count
    )
    
    problem = UHIGreenLayoutProblem(config)
    
    # Create uniform grid
    cells = []
    n_cells = rows * cols
    cell_area = config.cell_size ** 2
    
    for i in range(rows):
        for j in range(cols):
            idx = i * cols + j
            cell = GridCell(
                index=idx,
                position=np.array([i * config.cell_size, j * config.cell_size]),
                area=cell_area,
                land_use_type='candidate',
                base_temperature=35.0,
                greening_cost=10.0,
                population_density=1000.0
            )
            cells.append(cell)
    
    problem.cells = cells
    problem.n_cells = n_cells
    problem.candidate_indices = list(range(n_cells))
    problem.n_candidates = n_cells
    problem.fixed_indices = set()
    
    kernel = GaussianCoolingKernel(
        sigma=config.cooling_length_scale,
        amplitude=config.cooling_amplitude
    )
    problem.setup_cooling_model(kernel=kernel)
    
    # Expected solution: clustered pattern
    # For 3x3 with k=3, center [1,1] + two neighbors
    expected_solution_vector = np.zeros(n_cells, dtype=int)
    
    if rows == 3 and cols == 3 and target_green_count == 3:
        # Center + top + right: indices 4, 1, 5
        expected_solution_vector[[1, 4, 5]] = 1
        description = "Clustered pattern: center cell + 2 neighbors"
    elif rows == 3 and cols == 3 and target_green_count == 4:
        # 2x2 square in corner: indices 0,1,3,4
        expected_solution_vector[[0, 1, 3, 4]] = 1
        description = "2x2 square cluster in corner"
    else:
        # Generic: select first k cells (not optimal, just valid)
        expected_solution_vector[:target_green_count] = 1
        description = f"Generic solution: first {target_green_count} cells"
    
    expected_solution = ToyExampleSolution(
        solution_vector=expected_solution_vector,
        expected_energy=None,
        expected_green_cells=target_green_count,
        expected_area_used=target_green_count * cell_area,
        is_optimal=False,
        description=description,
        manual_verification_notes=f"""
        Manual Verification:
        1. Count selected cells: should be exactly {target_green_count}
        2. Check no area/budget violations (unlimited in this example)
        3. Verify clustering improves cooling interactions
        4. For 3x3 grid, center cell often in optimal solution
        5. Cooling benefit maximized when cells are adjacent
        
        Grid geometry: {rows}×{cols}
        Target count: {target_green_count}
        """
    )
    
    return problem, expected_solution


def get_all_toy_examples() -> Dict[str, Tuple[UHIGreenLayoutProblem, ToyExampleSolution]]:
    """
    Get all predefined toy examples as a dictionary.
    
    Useful for batch testing and validation workflows.
    
    Returns:
        Dictionary mapping example names to (problem, solution) tuples
        
    Example:
        >>> examples = get_all_toy_examples()
        >>> for name, (problem, solution) in examples.items():
        ...     print(f"{name}: {problem.n_candidates} candidates")
        4cell: 4 candidates
        8cell_no_fixed: 8 candidates
        8cell_with_fixed: 7 candidates
        3x3_count3: 9 candidates
        3x3_count4: 9 candidates
    """
    return {
        '4cell': get_4cell_example(),
        '8cell_no_fixed': get_8cell_example(include_fixed_green=False),
        '8cell_with_fixed': get_8cell_example(include_fixed_green=True),
        '3x3_count3': get_simple_grid_layout(3, 3, 3),
        '3x3_count4': get_simple_grid_layout(3, 3, 4),
        '4x4_count5': get_simple_grid_layout(4, 4, 5),
    }


def verify_toy_example_properties(
    problem: UHIGreenLayoutProblem,
    solution: ToyExampleSolution,
    verbose: bool = True
) -> Dict[str, Any]:
    """
    Verify that a toy example has expected properties.
    
    This function performs sanity checks on toy examples to ensure they
    are correctly configured and the expected solution is valid.
    
    Args:
        problem: UHIGreenLayoutProblem instance
        solution: Expected ToyExampleSolution
        verbose: Print verification details
        
    Returns:
        Dictionary with verification results
        
    Example:
        >>> problem, solution = get_4cell_example()
        >>> results = verify_toy_example_properties(problem, solution)
        >>> assert results['all_checks_passed']
    """
    results = {
        'checks_passed': [],
        'checks_failed': [],
        'warnings': []
    }
    
    # Check 1: Solution vector length matches candidates
    if len(solution.solution_vector) == problem.n_candidates:
        results['checks_passed'].append('Solution vector length correct')
    else:
        results['checks_failed'].append(
            f'Solution length {len(solution.solution_vector)} != '
            f'n_candidates {problem.n_candidates}'
        )
    
    # Check 2: Solution is binary
    if np.all(np.isin(solution.solution_vector, [0, 1])):
        results['checks_passed'].append('Solution is binary')
    else:
        results['checks_failed'].append('Solution contains non-binary values')
    
    # Check 3: Green cell count matches
    actual_count = np.sum(solution.solution_vector)
    if actual_count == solution.expected_green_cells:
        results['checks_passed'].append('Green cell count matches expectation')
    else:
        results['checks_failed'].append(
            f'Green count {actual_count} != expected {solution.expected_green_cells}'
        )
    
    # Check 4: Problem has cooling model
    if hasattr(problem, 'alpha') and problem.alpha is not None:
        results['checks_passed'].append('Cooling model configured')
    else:
        results['checks_failed'].append('Cooling model not set up')
    
    # Check 5: All candidates have valid indices
    if all(0 <= idx < problem.n_cells for idx in problem.candidate_indices):
        results['checks_passed'].append('Candidate indices valid')
    else:
        results['checks_failed'].append('Invalid candidate indices found')
    
    # Check 6: Area calculation
    total_area = sum(problem.cells[idx].area 
                     for idx in problem.candidate_indices 
                     if solution.solution_vector[problem.candidate_indices.index(idx)] == 1)
    if abs(total_area - solution.expected_area_used) < 1e-6:
        results['checks_passed'].append('Area calculation correct')
    else:
        results['warnings'].append(
            f'Area mismatch: {total_area:.2f} vs expected {solution.expected_area_used:.2f}'
        )
    
    results['all_checks_passed'] = (len(results['checks_failed']) == 0)
    results['n_passed'] = len(results['checks_passed'])
    results['n_failed'] = len(results['checks_failed'])
    results['n_warnings'] = len(results['warnings'])
    
    if verbose:
        print(f"Toy Example Verification Results:")
        print(f"  Passed: {results['n_passed']}")
        print(f"  Failed: {results['n_failed']}")
        print(f"  Warnings: {results['n_warnings']}")
        
        if results['checks_failed']:
            print("\nFailed Checks:")
            for failure in results['checks_failed']:
                print(f"  ✗ {failure}")
        
        if results['warnings']:
            print("\nWarnings:")
            for warning in results['warnings']:
                print(f"  ⚠ {warning}")
    
    return results


if __name__ == '__main__':
    # Demonstrate toy examples
    print("=" * 70)
    print("UHI-QUBO Toy Examples Demonstration")
    print("=" * 70)
    
    # Example 1: 4-cell
    print("\n1. Four-Cell Example (2×2 grid)")
    print("-" * 70)
    problem_4, solution_4 = get_4cell_example()
    print(f"Grid size: {problem_4.n_rows}×{problem_4.n_cols}")
    print(f"Candidates: {problem_4.n_candidates}")
    print(f"Expected solution: {solution_4.solution_vector}")
    print(f"Green cells: {solution_4.expected_green_cells}")
    verify_toy_example_properties(problem_4, solution_4, verbose=True)
    
    # Example 2: 8-cell
    print("\n2. Eight-Cell Example (2×4 grid)")
    print("-" * 70)
    problem_8, solution_8 = get_8cell_example()
    print(f"Grid size: {problem_8.n_rows}×{problem_8.n_cols}")
    print(f"Candidates: {problem_8.n_candidates}")
    print(f"Expected solution: {solution_8.solution_vector}")
    print(f"Description: {solution_8.description}")
    verify_toy_example_properties(problem_8, solution_8, verbose=True)
    
    # Example 3: Simple grid with exact count
    print("\n3. Simple Grid Layout (3×3, exact count=3)")
    print("-" * 70)
    problem_grid, solution_grid = get_simple_grid_layout(3, 3, 3)
    print(f"Grid size: {problem_grid.n_rows}×{problem_grid.n_cols}")
    print(f"Candidates: {problem_grid.n_candidates}")
    print(f"Expected solution: {solution_grid.solution_vector}")
    print(f"Description: {solution_grid.description}")
    verify_toy_example_properties(problem_grid, solution_grid, verbose=True)
    
    print("\n" + "=" * 70)
    print("All toy examples generated successfully!")
    print("=" * 70)
