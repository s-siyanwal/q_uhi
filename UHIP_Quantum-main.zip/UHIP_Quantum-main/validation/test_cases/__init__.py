"""
Test Cases Package for UHI-QUBO Validation

This package provides test instances for validating UHI-QUBO solvers:
- toy_examples: Small, manually verifiable test cases
- synthetic_instances: Parametric random instance generators
"""

from .toy_examples import (
    get_4cell_example,
    get_8cell_example,
    get_simple_grid_layout,
    get_all_toy_examples,
    verify_toy_example_properties,
    ToyExampleSolution
)

from .synthetic_instances import (
    generate_random_instance,
    generate_benchmark_suite,
    generate_scaling_suite,
    generate_constraint_stress_test,
    ProblemDifficulty,
    LandUseDistribution,
    InstanceMetadata
)

__all__ = [
    # Toy examples
    'get_4cell_example',
    'get_8cell_example',
    'get_simple_grid_layout',
    'get_all_toy_examples',
    'verify_toy_example_properties',
    'ToyExampleSolution',
    
    # Synthetic instances
    'generate_random_instance',
    'generate_benchmark_suite',
    'generate_scaling_suite',
    'generate_constraint_stress_test',
    'ProblemDifficulty',
    'LandUseDistribution',
    'InstanceMetadata',
]
