"""
Synthetic Instance Generator for UHI-QUBO Testing

This module provides parametric generators for creating random UHI-QUBO test instances
with controlled properties. Useful for:
- Stress testing solvers at various problem sizes
- Analyzing solver scaling behavior
- Generating benchmark suites
- Reproducible experiments via random seeds

Examples:
    >>> from validation.test_cases.synthetic_instances import generate_random_instance
    >>> problem, metadata = generate_random_instance(grid_size=10, seed=42)
    >>> Q, qubo_meta = problem.build_qubo()
    >>> print(f"Generated {Q.shape[0]}×{Q.shape[0]} QUBO")
"""

import numpy as np
from typing import Dict, Any, Tuple, Optional, List
from dataclasses import dataclass, field
from enum import Enum

from core.problem_modeling.uhi_green_layout import UHIGreenLayoutProblem, UHIProblemConfig, GridCell
from core.problem_modeling.cooling_kernels import (
    GaussianCoolingKernel,
    ExponentialCoolingKernel,
    PowerLawCoolingKernel,
    CompactSupportKernel
)


class ProblemDifficulty(Enum):
    """Problem difficulty level based on constraint tightness."""
    EASY = "easy"           # Loose constraints, many feasible solutions
    MEDIUM = "medium"       # Moderate constraints
    HARD = "hard"           # Tight constraints, few feasible solutions
    INFEASIBLE = "infeasible"  # Over-constrained, no feasible solution


class LandUseDistribution(Enum):
    """Spatial distribution pattern for land use types."""
    UNIFORM = "uniform"           # Random uniform distribution
    CLUSTERED = "clustered"       # Spatial clustering by type
    ZONED = "zoned"               # Clear zoning (e.g., CBD, residential, industrial)
    CONCENTRIC = "concentric"     # Concentric rings (urban core to suburbs)


@dataclass
class InstanceMetadata:
    """Metadata describing a synthetic problem instance.
    
    Attributes:
        seed: Random seed used for generation
        grid_size: Grid dimensions (rows, cols)
        n_cells: Total number of cells
        n_candidates: Number of candidate cells for greening
        difficulty: Problem difficulty level
        constraint_tightness: Ratio of budget/demand (0-1, lower is tighter)
        problem_density: Fraction of grid that are candidates
        land_use_distribution: Spatial pattern of land uses
        has_fixed_greens: Whether pre-greened cells exist
        has_spatial_constraints: Whether spatial constraints are included
        generation_params: Original generation parameters
        expected_properties: Expected statistical properties
    """
    seed: int
    grid_size: Tuple[int, int]
    n_cells: int
    n_candidates: int
    difficulty: ProblemDifficulty
    constraint_tightness: float
    problem_density: float
    land_use_distribution: LandUseDistribution
    has_fixed_greens: bool
    has_spatial_constraints: bool
    generation_params: Dict[str, Any] = field(default_factory=dict)
    expected_properties: Dict[str, Any] = field(default_factory=dict)


def generate_random_instance(
    grid_size: int = 10,
    candidate_fraction: float = 0.7,
    area_budget_fraction: float = 0.3,
    difficulty: ProblemDifficulty = ProblemDifficulty.MEDIUM,
    land_use_dist: LandUseDistribution = LandUseDistribution.UNIFORM,
    include_fixed_greens: bool = False,
    fixed_green_fraction: float = 0.1,
    kernel_type: str = 'gaussian',
    seed: Optional[int] = None
) -> Tuple[UHIGreenLayoutProblem, InstanceMetadata]:
    """
    Generate a random UHI-QUBO problem instance with controlled properties.
    
    This is the main entry point for synthetic instance generation. It creates
    a problem with random but realistic parameters.
    
    Args:
        grid_size: Grid dimension (creates grid_size × grid_size grid)
        candidate_fraction: Fraction of cells available for greening (0-1)
        area_budget_fraction: Fraction of total area for budget (0-1)
        difficulty: Target difficulty level
        land_use_dist: Spatial distribution of land uses
        include_fixed_greens: Whether to include pre-greened cells
        fixed_green_fraction: Fraction of candidates to fix as green
        kernel_type: Cooling kernel type ('gaussian', 'exponential', 'powerlaw', 'compact')
        seed: Random seed for reproducibility (None = random)
        
    Returns:
        problem: Generated UHIGreenLayoutProblem
        metadata: InstanceMetadata describing the instance
        
    Example:
        >>> # Generate easy 10×10 problem
        >>> problem, meta = generate_random_instance(10, difficulty=ProblemDifficulty.EASY, seed=42)
        >>> print(f"Generated {meta.n_candidates} candidate cells")
        >>> print(f"Constraint tightness: {meta.constraint_tightness:.2f}")
    """
    # Set random seed
    if seed is not None:
        np.random.seed(seed)
    else:
        seed = np.random.randint(0, 1000000)
        np.random.seed(seed)
    
    # Adjust parameters based on difficulty
    if difficulty == ProblemDifficulty.EASY:
        area_budget_fraction = max(area_budget_fraction, 0.4)
        penalty_weight = 50.0
    elif difficulty == ProblemDifficulty.MEDIUM:
        penalty_weight = 100.0
    elif difficulty == ProblemDifficulty.HARD:
        area_budget_fraction = min(area_budget_fraction, 0.25)
        penalty_weight = 200.0
    else:  # INFEASIBLE
        area_budget_fraction = 0.05  # Very tight
        penalty_weight = 500.0
    
    # Create grid configuration
    rows = grid_size
    cols = grid_size
    cell_size = 10.0 + np.random.uniform(-2, 2)  # 8-12 meters
    
    # Kernel parameters
    length_scale = cell_size * (2 + np.random.uniform(0, 3))
    amplitude = -(1.5 + np.random.uniform(0, 2.0))
    
    config = UHIProblemConfig(
        grid_rows=rows,
        grid_cols=cols,
        cell_size=cell_size,
        cooling_kernel_type=kernel_type,
        cooling_length_scale=length_scale,
        cooling_amplitude=amplitude,
        area_budget_fraction=area_budget_fraction,
        total_budget=None,  # Will be set based on costs
        penalty_weight=penalty_weight
    )
    
    problem = UHIGreenLayoutProblem(config)
    
    # Generate grid cells
    n_cells = rows * cols
    cells = _generate_grid_cells(
        rows=rows,
        cols=cols,
        cell_size=cell_size,
        land_use_dist=land_use_dist,
        seed=seed
    )
    
    # Select candidate cells
    candidate_mask = np.random.rand(n_cells) < candidate_fraction
    candidate_indices = np.where(candidate_mask)[0].tolist()
    n_candidates = len(candidate_indices)
    
    # Mark candidates
    for idx in candidate_indices:
        cells[idx].land_use_type = 'candidate'
    
    # Handle fixed greens
    fixed_indices = set()
    if include_fixed_greens and n_candidates > 0:
        n_fixed = max(1, int(n_candidates * fixed_green_fraction))
        fixed_candidates = np.random.choice(candidate_indices, n_fixed, replace=False)
        
        for idx in fixed_candidates:
            cells[idx].land_use_type = 'existing_green'
        
        fixed_indices = set(fixed_candidates.tolist())
        candidate_indices = [idx for idx in candidate_indices if idx not in fixed_indices]
        n_candidates = len(candidate_indices)
    
    # Set problem cells
    problem.cells = cells
    problem.n_cells = n_cells
    problem.candidate_indices = candidate_indices
    problem.n_candidates = n_candidates
    problem.fixed_indices = fixed_indices
    
    # Set budget based on costs
    total_cost = sum(cells[idx].greening_cost for idx in candidate_indices)
    total_area = sum(cells[idx].area for idx in candidate_indices)
    
    # Adjust budget for difficulty
    if difficulty == ProblemDifficulty.EASY:
        budget_multiplier = 0.6
    elif difficulty == ProblemDifficulty.MEDIUM:
        budget_multiplier = 0.4
    elif difficulty == ProblemDifficulty.HARD:
        budget_multiplier = 0.25
    else:  # INFEASIBLE
        budget_multiplier = 0.1
    
    config.total_budget = total_cost * budget_multiplier
    
    # Setup cooling model
    kernel = _create_cooling_kernel(kernel_type, length_scale, amplitude)
    problem.setup_cooling_model(kernel=kernel)
    
    # Calculate constraint tightness
    area_budget = total_area * area_budget_fraction
    achievable_count = int(area_budget / (total_area / n_candidates))
    constraint_tightness = achievable_count / max(n_candidates, 1) if n_candidates > 0 else 0
    
    # Create metadata
    metadata = InstanceMetadata(
        seed=seed,
        grid_size=(rows, cols),
        n_cells=n_cells,
        n_candidates=n_candidates,
        difficulty=difficulty,
        constraint_tightness=constraint_tightness,
        problem_density=n_candidates / n_cells if n_cells > 0 else 0,
        land_use_distribution=land_use_dist,
        has_fixed_greens=include_fixed_greens,
        has_spatial_constraints=False,
        generation_params={
            'grid_size': grid_size,
            'candidate_fraction': candidate_fraction,
            'area_budget_fraction': area_budget_fraction,
            'kernel_type': kernel_type,
            'cell_size': cell_size,
            'length_scale': length_scale,
            'amplitude': amplitude
        },
        expected_properties={
            'total_cost': total_cost,
            'total_area': total_area,
            'budget': config.total_budget,
            'area_budget': area_budget,
            'achievable_green_count': achievable_count
        }
    )
    
    return problem, metadata


def generate_benchmark_suite(
    grid_sizes: List[int] = [5, 10, 15, 20],
    difficulties: List[ProblemDifficulty] = None,
    instances_per_config: int = 3,
    base_seed: int = 42
) -> List[Tuple[UHIGreenLayoutProblem, InstanceMetadata]]:
    """
    Generate a suite of benchmark instances for systematic testing.
    
    Creates multiple instances across different grid sizes and difficulty levels,
    useful for solver comparison and scaling analysis.
    
    Args:
        grid_sizes: List of grid dimensions to test
        difficulties: List of difficulty levels (default: all except INFEASIBLE)
        instances_per_config: Number of instances per (size, difficulty) pair
        base_seed: Base random seed (incremented for each instance)
        
    Returns:
        List of (problem, metadata) tuples
        
    Example:
        >>> suite = generate_benchmark_suite(grid_sizes=[5, 10], instances_per_config=2)
        >>> print(f"Generated {len(suite)} benchmark instances")
        >>> for i, (problem, meta) in enumerate(suite):
        ...     print(f"  {i}: {meta.grid_size}, {meta.difficulty.value}, n={meta.n_candidates}")
    """
    if difficulties is None:
        difficulties = [ProblemDifficulty.EASY, ProblemDifficulty.MEDIUM, ProblemDifficulty.HARD]
    
    suite = []
    seed = base_seed
    
    for grid_size in grid_sizes:
        for difficulty in difficulties:
            for instance_num in range(instances_per_config):
                problem, metadata = generate_random_instance(
                    grid_size=grid_size,
                    difficulty=difficulty,
                    seed=seed
                )
                suite.append((problem, metadata))
                seed += 1
    
    return suite


def generate_scaling_suite(
    min_size: int = 5,
    max_size: int = 50,
    num_sizes: int = 10,
    instances_per_size: int = 3,
    difficulty: ProblemDifficulty = ProblemDifficulty.MEDIUM,
    base_seed: int = 100
) -> List[Tuple[UHIGreenLayoutProblem, InstanceMetadata]]:
    """
    Generate instances for scaling analysis.
    
    Creates problems of increasing size to study solver performance scaling.
    
    Args:
        min_size: Minimum grid size
        max_size: Maximum grid size
        num_sizes: Number of different sizes to generate
        instances_per_size: Replications per size
        difficulty: Fixed difficulty level
        base_seed: Base random seed
        
    Returns:
        List of (problem, metadata) tuples sorted by size
        
    Example:
        >>> suite = generate_scaling_suite(min_size=10, max_size=50, num_sizes=5)
        >>> sizes = [meta.n_candidates for _, meta in suite]
        >>> print(f"Candidate counts: {sorted(set(sizes))}")
    """
    # Generate grid sizes (logarithmic spacing for better coverage)
    if num_sizes == 1:
        grid_sizes = [max_size]
    else:
        log_sizes = np.logspace(np.log10(min_size), np.log10(max_size), num_sizes)
        grid_sizes = sorted(set(int(np.round(s)) for s in log_sizes))
    
    suite = []
    seed = base_seed
    
    for grid_size in grid_sizes:
        for _ in range(instances_per_size):
            problem, metadata = generate_random_instance(
                grid_size=grid_size,
                difficulty=difficulty,
                seed=seed
            )
            suite.append((problem, metadata))
            seed += 1
    
    return suite


def generate_constraint_stress_test(
    grid_size: int = 15,
    num_constraint_levels: int = 5,
    seed: int = 200
) -> List[Tuple[UHIGreenLayoutProblem, InstanceMetadata]]:
    """
    Generate instances with varying constraint tightness.
    
    Useful for testing how solvers handle increasingly constrained problems.
    
    Args:
        grid_size: Fixed grid size
        num_constraint_levels: Number of tightness levels to test
        seed: Random seed
        
    Returns:
        List of (problem, metadata) tuples ordered by increasing tightness
        
    Example:
        >>> suite = generate_constraint_stress_test(grid_size=10, num_constraint_levels=5)
        >>> for prob, meta in suite:
        ...     print(f"Tightness: {meta.constraint_tightness:.2f}")
    """
    suite = []
    
    # Vary area budget from loose to tight
    budget_fractions = np.linspace(0.5, 0.1, num_constraint_levels)
    
    for i, budget_frac in enumerate(budget_fractions):
        problem, metadata = generate_random_instance(
            grid_size=grid_size,
            area_budget_fraction=budget_frac,
            difficulty=ProblemDifficulty.MEDIUM,
            seed=seed + i
        )
        suite.append((problem, metadata))
    
    return suite


def _generate_grid_cells(
    rows: int,
    cols: int,
    cell_size: float,
    land_use_dist: LandUseDistribution,
    seed: int
) -> List[GridCell]:
    """
    Generate grid cells with realistic heterogeneous properties.
    
    Args:
        rows: Number of rows
        cols: Number of columns
        cell_size: Cell dimension (meters)
        land_use_dist: Land use distribution pattern
        seed: Random seed
        
    Returns:
        List of GridCell objects
    """
    np.random.seed(seed)
    n_cells = rows * cols
    cells = []
    
    cell_area = cell_size ** 2
    
    # Land use types and their properties
    land_use_types = ['urban', 'commercial', 'industrial', 'residential', 'mixed']
    land_use_temps = {
        'urban': (34, 37),
        'commercial': (35, 38),
        'industrial': (36, 39),
        'residential': (32, 35),
        'mixed': (33, 36)
    }
    land_use_costs = {
        'urban': (8, 12),
        'commercial': (12, 18),
        'industrial': (10, 15),
        'residential': (6, 10),
        'mixed': (7, 11)
    }
    
    # Generate land use pattern
    land_use_grid = _generate_land_use_pattern(rows, cols, land_use_dist, seed)
    
    for i in range(rows):
        for j in range(cols):
            idx = i * cols + j
            land_use = land_use_grid[i, j]
            
            # Temperature (higher toward center for concentric patterns)
            if land_use_dist == LandUseDistribution.CONCENTRIC:
                center_dist = np.sqrt((i - rows/2)**2 + (j - cols/2)**2)
                max_dist = np.sqrt((rows/2)**2 + (cols/2)**2)
                temp_boost = 3 * (1 - center_dist / max_dist)  # Hotter in center
            else:
                temp_boost = 0
            
            temp_range = land_use_temps[land_use]
            base_temp = np.random.uniform(*temp_range) + temp_boost
            
            # Cost
            cost_range = land_use_costs[land_use]
            cost = np.random.uniform(*cost_range)
            
            # Population density
            if land_use == 'residential':
                pop_density = np.random.uniform(1500, 3000)
            elif land_use == 'commercial':
                pop_density = np.random.uniform(800, 1500)
            elif land_use == 'industrial':
                pop_density = np.random.uniform(200, 600)
            else:
                pop_density = np.random.uniform(800, 2000)
            
            # Area variation (±10%)
            area = cell_area * np.random.uniform(0.9, 1.1)
            
            cell = GridCell(
                index=idx,
                position=np.array([i * cell_size, j * cell_size]),
                area=area,
                land_use_type=land_use,
                base_temperature=base_temp,
                greening_cost=cost,
                population_density=pop_density
            )
            cells.append(cell)
    
    return cells


def _generate_land_use_pattern(
    rows: int,
    cols: int,
    distribution: LandUseDistribution,
    seed: int
) -> np.ndarray:
    """
    Generate spatial land use pattern.
    
    Args:
        rows: Grid rows
        cols: Grid columns
        distribution: Distribution type
        seed: Random seed
        
    Returns:
        2D array of land use type strings
    """
    np.random.seed(seed)
    land_use_types = ['urban', 'commercial', 'industrial', 'residential', 'mixed']
    
    if distribution == LandUseDistribution.UNIFORM:
        # Random uniform
        indices = np.random.choice(len(land_use_types), size=(rows, cols))
        return np.array([[land_use_types[idx] for idx in row] for row in indices])
    
    elif distribution == LandUseDistribution.CLUSTERED:
        # Spatial clustering via smoothed random field
        field = np.random.randn(rows, cols)
        # Simple smoothing using convolution instead of scipy
        kernel_size = 3
        kernel = np.ones((kernel_size, kernel_size)) / (kernel_size ** 2)
        # Manual convolution for smoothing
        smoothed = np.copy(field)
        for i in range(1, rows-1):
            for j in range(1, cols-1):
                smoothed[i, j] = np.mean(field[i-1:i+2, j-1:j+2])
        # Threshold into categories
        percentiles = np.percentile(smoothed, [20, 40, 60, 80])
        grid = np.zeros((rows, cols), dtype=int)
        for i, thresh in enumerate(percentiles):
            grid[smoothed > thresh] = i + 1
        return np.array([[land_use_types[idx] for idx in row] for row in grid])
    
    elif distribution == LandUseDistribution.ZONED:
        # Clear zones (quadrants)
        grid = np.empty((rows, cols), dtype=object)
        mid_row, mid_col = rows // 2, cols // 2
        
        grid[:mid_row, :mid_col] = 'commercial'      # Top-left
        grid[:mid_row, mid_col:] = 'residential'     # Top-right
        grid[mid_row:, :mid_col] = 'industrial'      # Bottom-left
        grid[mid_row:, mid_col:] = 'urban'           # Bottom-right
        
        # Add some noise
        noise_mask = np.random.rand(rows, cols) < 0.1
        grid[noise_mask] = np.random.choice(land_use_types, size=np.sum(noise_mask))
        
        return grid
    
    elif distribution == LandUseDistribution.CONCENTRIC:
        # Concentric rings (CBD in center)
        grid = np.empty((rows, cols), dtype=object)
        center_i, center_j = rows / 2, cols / 2
        
        for i in range(rows):
            for j in range(cols):
                dist = np.sqrt((i - center_i)**2 + (j - center_j)**2)
                max_dist = np.sqrt(center_i**2 + center_j**2)
                
                if dist < 0.2 * max_dist:
                    grid[i, j] = 'commercial'  # CBD
                elif dist < 0.4 * max_dist:
                    grid[i, j] = 'mixed'
                elif dist < 0.6 * max_dist:
                    grid[i, j] = 'residential'
                elif dist < 0.8 * max_dist:
                    grid[i, j] = 'urban'
                else:
                    grid[i, j] = 'industrial'  # Periphery
        
        return grid
    
    else:
        # Default to uniform
        indices = np.random.choice(len(land_use_types), size=(rows, cols))
        return np.array([[land_use_types[idx] for idx in row] for row in indices])


def _create_cooling_kernel(kernel_type: str, length_scale: float, amplitude: float):
    """
    Create cooling kernel instance.
    
    Args:
        kernel_type: Kernel type name
        length_scale: Spatial length scale
        amplitude: Cooling amplitude
        
    Returns:
        Cooling kernel instance
    """
    if kernel_type.lower() == 'gaussian':
        return GaussianCoolingKernel(sigma=length_scale, amplitude=amplitude)
    elif kernel_type.lower() == 'exponential':
        return ExponentialCoolingKernel(length_scale=length_scale, amplitude=amplitude)
    elif kernel_type.lower() == 'powerlaw':
        return PowerLawCoolingKernel(length_scale=length_scale, amplitude=amplitude, power=2.0)
    elif kernel_type.lower() == 'compact':
        return CompactSupportKernel(cutoff_radius=length_scale * 2, amplitude=amplitude)
    else:
        return GaussianCoolingKernel(sigma=length_scale, amplitude=amplitude)


if __name__ == '__main__':
    print("=" * 70)
    print("Synthetic Instance Generator Demonstration")
    print("=" * 70)
    
    # Example 1: Single random instance
    print("\n1. Random Instance Generation")
    print("-" * 70)
    problem, metadata = generate_random_instance(
        grid_size=10,
        difficulty=ProblemDifficulty.MEDIUM,
        seed=42
    )
    print(f"Seed: {metadata.seed}")
    print(f"Grid: {metadata.grid_size[0]}×{metadata.grid_size[1]}")
    print(f"Candidates: {metadata.n_candidates} / {metadata.n_cells}")
    print(f"Difficulty: {metadata.difficulty.value}")
    print(f"Constraint tightness: {metadata.constraint_tightness:.3f}")
    print(f"Problem density: {metadata.problem_density:.3f}")
    
    # Example 2: Benchmark suite
    print("\n2. Benchmark Suite Generation")
    print("-" * 70)
    suite = generate_benchmark_suite(
        grid_sizes=[5, 10],
        instances_per_config=2,
        base_seed=100
    )
    print(f"Generated {len(suite)} instances")
    for i, (prob, meta) in enumerate(suite[:4]):
        print(f"  Instance {i}: {meta.grid_size}, {meta.difficulty.value}, "
              f"n={meta.n_candidates}, tightness={meta.constraint_tightness:.2f}")
    
    # Example 3: Scaling suite
    print("\n3. Scaling Suite Generation")
    print("-" * 70)
    scaling = generate_scaling_suite(
        min_size=5,
        max_size=25,
        num_sizes=5,
        instances_per_size=1
    )
    print(f"Generated {len(scaling)} scaling instances")
    sizes = [meta.n_candidates for _, meta in scaling]
    print(f"Candidate counts: {sorted(set(sizes))}")
    
    # Example 4: Constraint stress test
    print("\n4. Constraint Stress Test")
    print("-" * 70)
    stress = generate_constraint_stress_test(grid_size=10, num_constraint_levels=5)
    print(f"Generated {len(stress)} constraint stress instances")
    for i, (prob, meta) in enumerate(stress):
        print(f"  Level {i}: tightness={meta.constraint_tightness:.3f}, "
              f"budget_frac={meta.generation_params['area_budget_fraction']:.2f}")
    
    print("\n" + "=" * 70)
    print("Synthetic instance generation complete!")
    print("=" * 70)
