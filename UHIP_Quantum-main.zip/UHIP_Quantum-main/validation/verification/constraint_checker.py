"""
Constraint Satisfaction Checker for UHI-QUBO Solutions

This module provides comprehensive constraint verification for UHI-QUBO solutions.
It checks all constraint types, quantifies violations, and determines feasibility.

Key Features:
- Check individual constraint types (area, budget, cardinality, spatial)
- Compute violation amounts (how much constraints are exceeded)
- Determine overall feasibility
- Detailed violation reports

Examples:
    >>> from validation.verification.constraint_checker import ConstraintChecker
    >>> checker = ConstraintChecker(problem)
    >>> violations = checker.check_all_constraints(solution)
    >>> print(f"Feasible: {violations['is_feasible']}")
    >>> print(f"Area violation: {violations['area_violation']}")
"""

import numpy as np
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field

from core.problem_modeling.uhi_green_layout import UHIGreenLayoutProblem
from core.problem_modeling.uhi_green_layout import GridCell


@dataclass
class ConstraintViolation:
    """Details of a single constraint violation.
    
    Attributes:
        constraint_name: Name/description of the constraint
        constraint_type: Type (e.g., 'area', 'budget', 'cardinality')
        target_value: Target/threshold value for constraint
        actual_value: Actual value in the solution
        violation_amount: How much constraint is violated (0 if satisfied)
        is_satisfied: Whether constraint is satisfied
        violation_percentage: Violation as percentage of target
        severity: Severity level ('none', 'minor', 'moderate', 'severe')
    """
    constraint_name: str
    constraint_type: str
    target_value: float
    actual_value: float
    violation_amount: float
    is_satisfied: bool
    violation_percentage: float = 0.0
    severity: str = 'none'
    
    def __post_init__(self):
        """Calculate derived fields."""
        if self.target_value != 0:
            self.violation_percentage = (self.violation_amount / abs(self.target_value)) * 100
        else:
            self.violation_percentage = 0.0 if self.violation_amount == 0 else float('inf')
        
        # Classify severity
        if self.violation_amount == 0:
            self.severity = 'none'
        elif self.violation_percentage < 5:
            self.severity = 'minor'
        elif self.violation_percentage < 20:
            self.severity = 'moderate'
        else:
            self.severity = 'severe'


@dataclass
class ConstraintCheckResult:
    """Comprehensive constraint checking results.
    
    Attributes:
        is_feasible: Overall feasibility (all constraints satisfied)
        violations: List of ConstraintViolation objects
        n_violations: Total number of violated constraints
        max_violation_percentage: Maximum violation percentage across all constraints
        summary: Human-readable summary
        constraint_details: Detailed breakdown by constraint type
    """
    is_feasible: bool
    violations: List[ConstraintViolation]
    n_violations: int
    max_violation_percentage: float
    summary: str
    constraint_details: Dict[str, Any] = field(default_factory=dict)
    
    def get_violations_by_severity(self, severity: str) -> List[ConstraintViolation]:
        """Get violations of a specific severity level."""
        return [v for v in self.violations if v.severity == severity]
    
    def get_violations_by_type(self, constraint_type: str) -> List[ConstraintViolation]:
        """Get violations of a specific constraint type."""
        return [v for v in self.violations if v.constraint_type == constraint_type]


class ConstraintChecker:
    """
    Comprehensive constraint satisfaction checker for UHI-QUBO solutions.
    
    This class verifies all types of constraints and provides detailed violation
    reports. It integrates with UHIGreenLayoutProblem to access constraint definitions.
    
    Attributes:
        problem: UHIGreenLayoutProblem instance
        tolerance: Numerical tolerance for floating-point comparisons (default: 1e-6)
        
    Example:
        >>> problem = UHIGreenLayoutProblem(config)
        >>> problem.setup_uniform_grid()
        >>> checker = ConstraintChecker(problem)
        >>> result = checker.check_all_constraints(solution_vector)
        >>> if not result.is_feasible:
        ...     print(result.summary)
        ...     for violation in result.violations:
        ...         print(f"  {violation.constraint_name}: {violation.violation_amount}")
    """
    
    def __init__(self, problem: UHIGreenLayoutProblem, tolerance: float = 1e-6):
        """
        Initialize constraint checker.
        
        Args:
            problem: UHIGreenLayoutProblem to check constraints for
            tolerance: Numerical tolerance for comparisons
        """
        self.problem = problem
        self.tolerance = tolerance
    
    def check_all_constraints(
        self,
        solution: np.ndarray,
        verbose: bool = False
    ) -> ConstraintCheckResult:
        """
        Check all constraints for a given solution.
        
        This is the main entry point for comprehensive constraint checking.
        
        Args:
            solution: Binary solution vector (length n_candidates)
            verbose: Print detailed checking progress
            
        Returns:
            ConstraintCheckResult with comprehensive violation information
            
        Example:
            >>> result = checker.check_all_constraints(solution)
            >>> print(f"Feasible: {result.is_feasible}")
            >>> print(f"Violations: {result.n_violations}")
        """
        violations = []
        
        # Check binary integrity
        binary_violations = self._check_binary_integrity(solution)
        violations.extend(binary_violations)
        
        # Check area constraint
        area_violation = self._check_area_constraint(solution)
        if area_violation:
            violations.append(area_violation)
        
        # Check budget constraint
        budget_violation = self._check_budget_constraint(solution)
        if budget_violation:
            violations.append(budget_violation)
        
        # Check cardinality constraints (min/max green cells)
        cardinality_violations = self._check_cardinality_constraints(solution)
        violations.extend(cardinality_violations)
        
        # Check spatial constraints (if any)
        spatial_violations = self._check_spatial_constraints(solution)
        violations.extend(spatial_violations)
        
        # Determine overall feasibility
        is_feasible = all(v.is_satisfied for v in violations)
        n_violations = sum(1 for v in violations if not v.is_satisfied)
        
        # Calculate max violation percentage
        if violations:
            violation_percentages = [v.violation_percentage for v in violations 
                                    if not v.is_satisfied and not np.isinf(v.violation_percentage)]
            max_violation_percentage = max(violation_percentages) if violation_percentages else 0.0
        else:
            max_violation_percentage = 0.0
        
        # Create summary
        if is_feasible:
            summary = "✓ All constraints satisfied"
        else:
            summary = f"✗ {n_violations} constraint(s) violated (max: {max_violation_percentage:.1f}%)"
        
        # Detailed breakdown by type
        constraint_details = self._create_constraint_details(violations, solution)
        
        result = ConstraintCheckResult(
            is_feasible=is_feasible,
            violations=violations,
            n_violations=n_violations,
            max_violation_percentage=max_violation_percentage,
            summary=summary,
            constraint_details=constraint_details
        )
        
        if verbose:
            self._print_check_results(result)
        
        return result
    
    def _check_binary_integrity(self, solution: np.ndarray) -> List[ConstraintViolation]:
        """Check that solution is valid binary vector."""
        violations = []
        
        # Check length
        if len(solution) != self.problem.n_candidates:
            violations.append(ConstraintViolation(
                constraint_name="Solution vector length",
                constraint_type="binary_integrity",
                target_value=self.problem.n_candidates,
                actual_value=len(solution),
                violation_amount=abs(len(solution) - self.problem.n_candidates),
                is_satisfied=False
            ))
        
        # Check binary values
        non_binary_count = np.sum(~np.isin(solution, [0, 1]))
        if non_binary_count > 0:
            violations.append(ConstraintViolation(
                constraint_name="Binary values (0/1 only)",
                constraint_type="binary_integrity",
                target_value=0,
                actual_value=non_binary_count,
                violation_amount=non_binary_count,
                is_satisfied=False
            ))
        
        return violations
    
    def _check_area_constraint(self, solution: np.ndarray) -> Optional[ConstraintViolation]:
        """Check area budget constraint."""
        if not hasattr(self.problem.config, 'area_budget_fraction'):
            return None
        
        # Calculate total area used
        total_area = 0.0
        for i, cell_idx in enumerate(self.problem.candidate_indices):
            if i < len(solution) and solution[i] == 1:
                total_area += self.problem.cells[cell_idx].area
        
        # Calculate area budget
        total_available_area = sum(
            self.problem.cells[idx].area 
            for idx in self.problem.candidate_indices
        )
        area_budget = total_available_area * self.problem.config.area_budget_fraction
        
        # Check violation
        violation_amount = max(0, total_area - area_budget - self.tolerance)
        is_satisfied = violation_amount < self.tolerance
        
        return ConstraintViolation(
            constraint_name="Area budget",
            constraint_type="area",
            target_value=area_budget,
            actual_value=total_area,
            violation_amount=violation_amount,
            is_satisfied=is_satisfied
        )
    
    def _check_budget_constraint(self, solution: np.ndarray) -> Optional[ConstraintViolation]:
        """Check cost budget constraint."""
        if self.problem.config.total_budget is None:
            return None
        
        # Calculate total cost
        total_cost = 0.0
        for i, cell_idx in enumerate(self.problem.candidate_indices):
            if i < len(solution) and solution[i] == 1:
                total_cost += self.problem.cells[cell_idx].greening_cost
        
        budget = self.problem.config.total_budget
        
        # Check violation
        violation_amount = max(0, total_cost - budget - self.tolerance)
        is_satisfied = violation_amount < self.tolerance
        
        return ConstraintViolation(
            constraint_name="Cost budget",
            constraint_type="budget",
            target_value=budget,
            actual_value=total_cost,
            violation_amount=violation_amount,
            is_satisfied=is_satisfied
        )
    
    def _check_cardinality_constraints(self, solution: np.ndarray) -> List[ConstraintViolation]:
        """Check min/max green cell count constraints."""
        violations = []
        
        n_green = np.sum(solution)
        
        # Check minimum
        if self.problem.config.min_green_cells is not None:
            min_cells = self.problem.config.min_green_cells
            violation_amount = max(0, min_cells - n_green)
            is_satisfied = violation_amount < self.tolerance
            
            violations.append(ConstraintViolation(
                constraint_name="Minimum green cells",
                constraint_type="cardinality",
                target_value=min_cells,
                actual_value=n_green,
                violation_amount=violation_amount,
                is_satisfied=is_satisfied
            ))
        
        # Check maximum
        if self.problem.config.max_green_cells is not None:
            max_cells = self.problem.config.max_green_cells
            violation_amount = max(0, n_green - max_cells)
            is_satisfied = violation_amount < self.tolerance
            
            violations.append(ConstraintViolation(
                constraint_name="Maximum green cells",
                constraint_type="cardinality",
                target_value=max_cells,
                actual_value=n_green,
                violation_amount=violation_amount,
                is_satisfied=is_satisfied
            ))
        
        return violations
    
    def _check_spatial_constraints(self, solution: np.ndarray) -> List[ConstraintViolation]:
        """Check spatial constraints (connectivity, separation, etc.)."""
        violations = []
        
        # Note: Spatial constraints are typically implemented as soft constraints
        # in the QUBO objective. Here we can add hard constraint checks if needed.
        
        # Example: Check minimum separation distance (if defined)
        # This would require additional problem configuration
        
        return violations
    
    def _create_constraint_details(
        self,
        violations: List[ConstraintViolation],
        solution: np.ndarray
    ) -> Dict[str, Any]:
        """Create detailed breakdown by constraint type."""
        details = {}
        
        # Group by type
        by_type = {}
        for v in violations:
            if v.constraint_type not in by_type:
                by_type[v.constraint_type] = []
            by_type[v.constraint_type].append(v)
        
        # Summarize each type
        for ctype, viols in by_type.items():
            n_total = len(viols)
            n_satisfied = sum(1 for v in viols if v.is_satisfied)
            n_violated = n_total - n_satisfied
            
            details[ctype] = {
                'n_constraints': n_total,
                'n_satisfied': n_satisfied,
                'n_violated': n_violated,
                'violations': [
                    {
                        'name': v.constraint_name,
                        'target': v.target_value,
                        'actual': v.actual_value,
                        'violation': v.violation_amount,
                        'severity': v.severity
                    }
                    for v in viols if not v.is_satisfied
                ]
            }
        
        # Add solution statistics
        details['solution_stats'] = {
            'n_green_cells': int(np.sum(solution)),
            'n_candidates': self.problem.n_candidates,
            'green_fraction': float(np.sum(solution)) / max(len(solution), 1)
        }
        
        return details
    
    def _print_check_results(self, result: ConstraintCheckResult):
        """Print detailed check results."""
        print("=" * 70)
        print("Constraint Check Results")
        print("=" * 70)
        print(f"\n{result.summary}\n")
        
        if result.is_feasible:
            print("✓ Solution is feasible")
        else:
            print("✗ Solution is infeasible\n")
            print("Violated Constraints:")
            print("-" * 70)
            
            for v in result.violations:
                if not v.is_satisfied:
                    print(f"  [{v.severity.upper()}] {v.constraint_name}")
                    print(f"    Target: {v.target_value:.2f}")
                    print(f"    Actual: {v.actual_value:.2f}")
                    print(f"    Violation: {v.violation_amount:.2f} ({v.violation_percentage:.1f}%)")
                    print()
        
        # Print constraint summary by type
        print("\nConstraint Summary by Type:")
        print("-" * 70)
        for ctype, details in result.constraint_details.items():
            if ctype == 'solution_stats':
                continue
            print(f"  {ctype.upper()}: {details['n_satisfied']}/{details['n_constraints']} satisfied")
        
        # Print solution stats
        stats = result.constraint_details.get('solution_stats', {})
        print("\nSolution Statistics:")
        print("-" * 70)
        print(f"  Green cells: {stats.get('n_green_cells', 0)}")
        print(f"  Candidates: {stats.get('n_candidates', 0)}")
        print(f"  Green fraction: {stats.get('green_fraction', 0):.1%}")
        print("=" * 70)
    
    def check_constraint_type(
        self,
        solution: np.ndarray,
        constraint_type: str
    ) -> List[ConstraintViolation]:
        """
        Check only constraints of a specific type.
        
        Args:
            solution: Binary solution vector
            constraint_type: Type to check ('area', 'budget', 'cardinality', etc.)
            
        Returns:
            List of violations for that constraint type
            
        Example:
            >>> violations = checker.check_constraint_type(solution, 'area')
            >>> if violations and not violations[0].is_satisfied:
            ...     print(f"Area exceeded by {violations[0].violation_amount}")
        """
        if constraint_type == 'area':
            violation = self._check_area_constraint(solution)
            return [violation] if violation else []
        elif constraint_type == 'budget':
            violation = self._check_budget_constraint(solution)
            return [violation] if violation else []
        elif constraint_type == 'cardinality':
            return self._check_cardinality_constraints(solution)
        elif constraint_type == 'binary_integrity':
            return self._check_binary_integrity(solution)
        elif constraint_type == 'spatial':
            return self._check_spatial_constraints(solution)
        else:
            raise ValueError(f"Unknown constraint type: {constraint_type}")
    
    def compute_total_violation_penalty(
        self,
        solution: np.ndarray
    ) -> float:
        """
        Compute total constraint violation penalty.
        
        This sums up all violation amounts, weighted by severity if needed.
        Useful for optimization algorithms that need a single penalty value.
        
        Args:
            solution: Binary solution vector
            
        Returns:
            Total penalty value (0 if feasible)
            
        Example:
            >>> penalty = checker.compute_total_violation_penalty(solution)
            >>> print(f"Total penalty: {penalty}")
        """
        result = self.check_all_constraints(solution, verbose=False)
        
        total_penalty = 0.0
        for v in result.violations:
            if not v.is_satisfied:
                # Weight by severity
                severity_weights = {
                    'minor': 1.0,
                    'moderate': 2.0,
                    'severe': 5.0
                }
                weight = severity_weights.get(v.severity, 1.0)
                total_penalty += v.violation_amount * weight
        
        return total_penalty


if __name__ == '__main__':
    # Demonstration
    print("=" * 70)
    print("Constraint Checker Demonstration")
    print("=" * 70)
    
    # Create a simple test problem
    from core.problem_modeling.uhi_green_layout import UHIProblemConfig
    from core.problem_modeling.cooling_kernels import GaussianCoolingKernel
    
    config = UHIProblemConfig(
        grid_rows=3,
        grid_cols=3,
        cell_size=10.0,
        cooling_kernel_type='gaussian',
        cooling_length_scale=15.0,
        cooling_amplitude=-2.0,
        area_budget_fraction=0.3,
        total_budget=30.0,
        min_green_cells=2,
        max_green_cells=4
    )
    
    problem = UHIGreenLayoutProblem(config)
    problem.setup_uniform_grid(candidate_fraction=1.0)
    problem.setup_cooling_model(kernel=GaussianCoolingKernel(sigma=15.0, amplitude=-2.0))
    
    # Create checker
    checker = ConstraintChecker(problem)
    
    # Test 1: Feasible solution
    print("\nTest 1: Feasible Solution")
    print("-" * 70)
    feasible_solution = np.array([1, 0, 0, 1, 0, 0, 1, 0, 0], dtype=int)  # 3 cells
    result1 = checker.check_all_constraints(feasible_solution, verbose=True)
    
    # Test 2: Infeasible solution (too many cells)
    print("\n\nTest 2: Infeasible Solution (Too Many Green Cells)")
    print("-" * 70)
    infeasible_solution = np.array([1, 1, 1, 1, 1, 0, 0, 0, 0], dtype=int)  # 5 cells
    result2 = checker.check_all_constraints(infeasible_solution, verbose=True)
    
    # Test 3: Check specific constraint type
    print("\n\nTest 3: Check Area Constraint Only")
    print("-" * 70)
    area_violations = checker.check_constraint_type(feasible_solution, 'area')
    if area_violations:
        for v in area_violations:
            print(f"{v.constraint_name}: {'✓ Satisfied' if v.is_satisfied else '✗ Violated'}")
            print(f"  Target: {v.target_value:.2f}, Actual: {v.actual_value:.2f}")
    
    print("\n" + "=" * 70)
    print("Constraint checking demonstration complete!")
    print("=" * 70)
