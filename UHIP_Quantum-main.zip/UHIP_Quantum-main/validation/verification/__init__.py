"""
Verification Package for UHI-QUBO Solutions

This package provides solution verification tools:
- constraint_checker: Constraint satisfaction verification
- solution_validator: Multi-level solution validation
"""

from .constraint_checker import (
    ConstraintChecker,
    ConstraintViolation,
    ConstraintCheckResult
)

from .solution_validator import (
    SolutionValidator,
    ValidationReport,
    ValidationLevel,
    ValidationStatus
)

__all__ = [
    # Constraint checking
    'ConstraintChecker',
    'ConstraintViolation',
    'ConstraintCheckResult',
    
    # Solution validation
    'SolutionValidator',
    'ValidationReport',
    'ValidationLevel',
    'ValidationStatus',
]
