"""
Multi-Level Solution Validator for UHI-QUBO

This module provides comprehensive validation of UHI-QUBO solutions with multiple
verification levels. It integrates constraint checking, energy validation, and
produces detailed validation reports.

Validation Levels:
1. Binary Integrity: Check solution format and binary constraints
2. Constraint Satisfaction: Verify all problem constraints
3. Energy Consistency: Validate QUBO energy calculations
4. Physical Plausibility: Check cooling physics and spatial patterns

Examples:
    >>> from validation.verification.solution_validator import SolutionValidator
    >>> validator = SolutionValidator(problem)
    >>> report = validator.validate_complete(solution)
    >>> print(report.overall_status)  # 'VALID', 'INVALID', or 'WARNING'
    >>> validator.print_report(report)
"""

import numpy as np
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import time

from core.problem_modeling.uhi_green_layout import UHIGreenLayoutProblem
from validation.verification.constraint_checker import ConstraintChecker, ConstraintCheckResult


class ValidationStatus(Enum):
    """Overall validation status."""
    VALID = "VALID"           # All checks passed
    INVALID = "INVALID"       # Critical failures
    WARNING = "WARNING"       # Passed but with warnings
    ERROR = "ERROR"           # Validation could not complete


@dataclass
class ValidationLevel:
    """Results for a single validation level.
    
    Attributes:
        level_name: Name of validation level
        passed: Whether this level passed
        issues: List of issues found (empty if passed)
        warnings: List of warnings (non-critical)
        details: Detailed results dictionary
        execution_time: Time taken for this level (seconds)
    """
    level_name: str
    passed: bool
    issues: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)
    execution_time: float = 0.0


@dataclass
class ValidationReport:
    """Comprehensive validation report.
    
    Attributes:
        overall_status: Overall validation status
        is_valid: Whether solution is valid (all levels passed)
        levels: Results for each validation level
        summary: Human-readable summary
        solution_statistics: Solution statistics
        timestamp: When validation was performed
        total_execution_time: Total validation time (seconds)
    """
    overall_status: ValidationStatus
    is_valid: bool
    levels: Dict[str, ValidationLevel]
    summary: str
    solution_statistics: Dict[str, Any]
    timestamp: str
    total_execution_time: float
    
    def get_all_issues(self) -> List[str]:
        """Get all issues across all levels."""
        issues = []
        for level in self.levels.values():
            issues.extend(level.issues)
        return issues
    
    def get_all_warnings(self) -> List[str]:
        """Get all warnings across all levels."""
        warnings = []
        for level in self.levels.values():
            warnings.extend(level.warnings)
        return warnings
    
    def has_critical_issues(self) -> bool:
        """Check if any critical issues exist."""
        return not self.is_valid


class SolutionValidator:
    """
    Comprehensive multi-level validator for UHI-QUBO solutions.
    
    This class performs thorough validation including:
    - Binary integrity checks
    - Constraint satisfaction verification
    - Energy calculation consistency
    - Physical plausibility checks
    
    Attributes:
        problem: UHIGreenLayoutProblem instance
        constraint_checker: ConstraintChecker instance
        tolerance: Numerical tolerance for comparisons
        
    Example:
        >>> problem = UHIGreenLayoutProblem(config)
        >>> problem.setup_uniform_grid()
        >>> Q, metadata = problem.build_qubo()
        >>> 
        >>> # Solve and validate
        >>> solution = solver.solve(Q)
        >>> validator = SolutionValidator(problem)
        >>> report = validator.validate_complete(solution)
        >>> 
        >>> if report.is_valid:
        ...     print("Solution is valid!")
        ... else:
        ...     print(f"Issues: {report.get_all_issues()}")
    """
    
    def __init__(
        self,
        problem: UHIGreenLayoutProblem,
        tolerance: float = 1e-6
    ):
        """
        Initialize solution validator.
        
        Args:
            problem: UHIGreenLayoutProblem to validate solutions for
            tolerance: Numerical tolerance for floating-point comparisons
        """
        self.problem = problem
        self.tolerance = tolerance
        self.constraint_checker = ConstraintChecker(problem, tolerance)
    
    def validate_complete(
        self,
        solution: np.ndarray,
        expected_energy: Optional[float] = None,
        verbose: bool = False
    ) -> ValidationReport:
        """
        Perform complete multi-level validation.
        
        This is the main entry point for comprehensive solution validation.
        
        Args:
            solution: Binary solution vector to validate
            expected_energy: Optional expected energy for comparison
            verbose: Print detailed progress
            
        Returns:
            ValidationReport with comprehensive results
            
        Example:
            >>> report = validator.validate_complete(solution)
            >>> validator.print_report(report)
        """
        start_time = time.time()
        levels = {}
        
        # Level 1: Binary Integrity
        if verbose:
            print("Validating Level 1: Binary Integrity...")
        levels['binary_integrity'] = self._validate_binary_integrity(solution)
        
        # Level 2: Constraint Satisfaction
        if verbose:
            print("Validating Level 2: Constraint Satisfaction...")
        levels['constraint_satisfaction'] = self._validate_constraint_satisfaction(solution)
        
        # Level 3: Energy Consistency
        if verbose:
            print("Validating Level 3: Energy Consistency...")
        levels['energy_consistency'] = self._validate_energy_consistency(
            solution, expected_energy
        )
        
        # Level 4: Physical Plausibility
        if verbose:
            print("Validating Level 4: Physical Plausibility...")
        levels['physical_plausibility'] = self._validate_physical_plausibility(solution)
        
        # Determine overall status
        all_passed = all(level.passed for level in levels.values())
        has_warnings = any(level.warnings for level in levels.values())
        
        if all_passed and not has_warnings:
            overall_status = ValidationStatus.VALID
            is_valid = True
            summary = "✓ All validation levels passed"
        elif all_passed and has_warnings:
            overall_status = ValidationStatus.WARNING
            is_valid = True
            summary = "⚠ Validation passed with warnings"
        else:
            overall_status = ValidationStatus.INVALID
            is_valid = False
            failed_levels = [name for name, level in levels.items() if not level.passed]
            summary = f"✗ Validation failed: {', '.join(failed_levels)}"
        
        # Gather solution statistics
        solution_stats = self._compute_solution_statistics(solution)
        
        # Create report
        total_time = time.time() - start_time
        report = ValidationReport(
            overall_status=overall_status,
            is_valid=is_valid,
            levels=levels,
            summary=summary,
            solution_statistics=solution_stats,
            timestamp=time.strftime('%Y-%m-%d %H:%M:%S'),
            total_execution_time=total_time
        )
        
        if verbose:
            self.print_report(report)
        
        return report
    
    def _validate_binary_integrity(self, solution: np.ndarray) -> ValidationLevel:
        """Validate binary integrity of solution."""
        start_time = time.time()
        issues = []
        warnings = []
        details = {}
        
        # Check vector length
        expected_length = self.problem.n_candidates
        actual_length = len(solution)
        details['expected_length'] = expected_length
        details['actual_length'] = actual_length
        
        if actual_length != expected_length:
            issues.append(
                f"Solution length {actual_length} != expected {expected_length}"
            )
        
        # Check binary values
        non_binary_mask = ~np.isin(solution, [0, 1])
        n_non_binary = np.sum(non_binary_mask)
        details['n_non_binary'] = int(n_non_binary)
        
        if n_non_binary > 0:
            issues.append(f"{n_non_binary} non-binary values found")
            if n_non_binary <= 5:
                non_binary_indices = np.where(non_binary_mask)[0]
                details['non_binary_indices'] = non_binary_indices.tolist()
        
        # Check data type
        details['dtype'] = str(solution.dtype)
        if not np.issubdtype(solution.dtype, np.integer):
            warnings.append(f"Solution dtype is {solution.dtype}, expected integer")
        
        # Check for NaN or inf
        if np.any(np.isnan(solution)):
            issues.append("Solution contains NaN values")
        if np.any(np.isinf(solution)):
            issues.append("Solution contains infinite values")
        
        passed = len(issues) == 0
        execution_time = time.time() - start_time
        
        return ValidationLevel(
            level_name="Binary Integrity",
            passed=passed,
            issues=issues,
            warnings=warnings,
            details=details,
            execution_time=execution_time
        )
    
    def _validate_constraint_satisfaction(self, solution: np.ndarray) -> ValidationLevel:
        """Validate constraint satisfaction."""
        start_time = time.time()
        
        # Use constraint checker
        constraint_result = self.constraint_checker.check_all_constraints(
            solution, verbose=False
        )
        
        issues = []
        warnings = []
        
        # Extract issues from violations
        for violation in constraint_result.violations:
            if not violation.is_satisfied:
                msg = (
                    f"{violation.constraint_name}: "
                    f"violated by {violation.violation_amount:.2f} "
                    f"({violation.violation_percentage:.1f}%)"
                )
                
                if violation.severity in ['severe', 'moderate']:
                    issues.append(msg)
                else:
                    warnings.append(msg)
        
        details = {
            'is_feasible': constraint_result.is_feasible,
            'n_violations': constraint_result.n_violations,
            'max_violation_percentage': constraint_result.max_violation_percentage,
            'constraint_details': constraint_result.constraint_details
        }
        
        passed = constraint_result.is_feasible
        execution_time = time.time() - start_time
        
        return ValidationLevel(
            level_name="Constraint Satisfaction",
            passed=passed,
            issues=issues,
            warnings=warnings,
            details=details,
            execution_time=execution_time
        )
    
    def _validate_energy_consistency(
        self,
        solution: np.ndarray,
        expected_energy: Optional[float]
    ) -> ValidationLevel:
        """Validate energy calculation consistency."""
        start_time = time.time()
        issues = []
        warnings = []
        details = {}
        
        # Build QUBO if not already built
        try:
            if not hasattr(self.problem, 'Q') or self.problem.Q is None:
                Q, metadata = self.problem.build_qubo()
            else:
                Q = self.problem.Q
                metadata = {}
            
            details['qubo_built'] = True
        except Exception as e:
            issues.append(f"Failed to build QUBO: {str(e)}")
            details['qubo_built'] = False
            passed = False
            execution_time = time.time() - start_time
            return ValidationLevel(
                level_name="Energy Consistency",
                passed=passed,
                issues=issues,
                warnings=warnings,
                details=details,
                execution_time=execution_time
            )
        
        # Calculate energy
        try:
            # Direct calculation: E = x^T Q x
            if len(solution) == Q.shape[0]:
                energy = solution @ Q @ solution
                details['calculated_energy'] = float(energy)
            else:
                issues.append(
                    f"Solution length {len(solution)} != QUBO size {Q.shape[0]}"
                )
                passed = False
                execution_time = time.time() - start_time
                return ValidationLevel(
                    level_name="Energy Consistency",
                    passed=passed,
                    issues=issues,
                    warnings=warnings,
                    details=details,
                    execution_time=execution_time
                )
            
            # Compare with expected energy if provided
            if expected_energy is not None:
                details['expected_energy'] = expected_energy
                energy_diff = abs(energy - expected_energy)
                details['energy_difference'] = energy_diff
                
                # Check if difference is within tolerance
                rel_tol = max(self.tolerance, abs(expected_energy) * 1e-6)
                if energy_diff > rel_tol:
                    warnings.append(
                        f"Energy mismatch: calculated={energy:.6f}, "
                        f"expected={expected_energy:.6f}, "
                        f"diff={energy_diff:.6e}"
                    )
            
            # Get energy decomposition
            try:
                eval_result = self.problem.evaluate_solution(solution)
                details['energy_decomposition'] = eval_result
                
                # Verify consistency
                if 'total_energy' in eval_result:
                    decomp_energy = eval_result['total_energy']
                    decomp_diff = abs(energy - decomp_energy)
                    
                    if decomp_diff > self.tolerance:
                        warnings.append(
                            f"Energy decomposition inconsistent: "
                            f"direct={energy:.6f}, decomposed={decomp_energy:.6f}"
                        )
            except Exception as e:
                warnings.append(f"Could not decompose energy: {str(e)}")
            
        except Exception as e:
            issues.append(f"Energy calculation failed: {str(e)}")
        
        passed = len(issues) == 0
        execution_time = time.time() - start_time
        
        return ValidationLevel(
            level_name="Energy Consistency",
            passed=passed,
            issues=issues,
            warnings=warnings,
            details=details,
            execution_time=execution_time
        )
    
    def _validate_physical_plausibility(self, solution: np.ndarray) -> ValidationLevel:
        """Validate physical plausibility of solution."""
        start_time = time.time()
        issues = []
        warnings = []
        details = {}
        
        # Check if any cells are selected
        n_green = np.sum(solution)
        details['n_green_cells'] = int(n_green)
        
        if n_green == 0:
            warnings.append("No cells selected for greening")
        elif n_green == len(solution):
            warnings.append("All cells selected (may not be realistic)")
        
        # Check spatial distribution
        if n_green > 0:
            green_indices = [
                self.problem.candidate_indices[i] 
                for i in range(len(solution)) 
                if solution[i] == 1
            ]
            
            # Get positions
            positions = np.array([
                self.problem.cells[idx].position 
                for idx in green_indices
            ])
            
            # Handle 1D positions (shouldn't happen, but be safe)
            if positions.ndim == 1:
                positions = positions.reshape(-1, 1)
            
            # Calculate centroid
            centroid = np.mean(positions, axis=0)
            details['centroid'] = centroid.tolist()
            
            # Calculate spatial spread
            distances_from_centroid = np.linalg.norm(
                positions - centroid, axis=1
            )
            # Calculate spatial spread (only if we have valid positions)
            if len(distances_from_centroid) > 0:
                avg_spread = np.mean(distances_from_centroid)
                max_spread = np.max(distances_from_centroid)
                
                details['avg_spread'] = float(avg_spread)
                details['max_spread'] = float(max_spread)
                
                # Check for extreme clustering
                if n_green > 3 and avg_spread < self.problem.config.cell_size:
                    warnings.append(
                        f"Extremely clustered solution (avg spread: {avg_spread:.1f}m)"
                    )
            
            # Calculate cooling benefit estimate
            if hasattr(self.problem, 'alpha') and self.problem.alpha is not None:
                try:
                    # Physical energy component
                    physical_energy = (
                        solution @ self.problem.alpha +
                        solution @ self.problem.beta @ solution
                    )
                    details['physical_energy'] = float(physical_energy)
                    
                    # Check if cooling benefit is reasonable (should be negative)
                    if physical_energy > 0:
                        warnings.append(
                            f"Positive physical energy ({physical_energy:.2f}), "
                            "expected cooling benefit (negative)"
                        )
                except Exception as e:
                    warnings.append(f"Could not compute physical energy: {str(e)}")
        
        # All checks in this level are warnings, not hard failures
        passed = True
        execution_time = time.time() - start_time
        
        return ValidationLevel(
            level_name="Physical Plausibility",
            passed=passed,
            issues=issues,
            warnings=warnings,
            details=details,
            execution_time=execution_time
        )
    
    def _compute_solution_statistics(self, solution: np.ndarray) -> Dict[str, Any]:
        """Compute comprehensive solution statistics."""
        stats = {}
        
        n_green = np.sum(solution)
        stats['n_green_cells'] = int(n_green)
        stats['n_candidates'] = self.problem.n_candidates
        stats['green_fraction'] = float(n_green) / max(len(solution), 1)
        
        if n_green > 0:
            # Area used
            total_area = sum(
                self.problem.cells[self.problem.candidate_indices[i]].area
                for i in range(len(solution)) if solution[i] == 1
            )
            stats['total_area_used'] = total_area
            
            # Cost
            total_cost = sum(
                self.problem.cells[self.problem.candidate_indices[i]].greening_cost
                for i in range(len(solution)) if solution[i] == 1
            )
            stats['total_cost'] = total_cost
            
            # Average temperature of greened cells
            avg_temp = np.mean([
                self.problem.cells[self.problem.candidate_indices[i]].base_temperature
                for i in range(len(solution)) if solution[i] == 1
            ])
            stats['avg_base_temperature'] = float(avg_temp)
        else:
            stats['total_area_used'] = 0.0
            stats['total_cost'] = 0.0
            stats['avg_base_temperature'] = 0.0
        
        return stats
    
    def print_report(self, report: ValidationReport):
        """
        Print formatted validation report.
        
        Args:
            report: ValidationReport to print
        """
        print("=" * 80)
        print("SOLUTION VALIDATION REPORT".center(80))
        print("=" * 80)
        print(f"Timestamp: {report.timestamp}")
        print(f"Execution Time: {report.total_execution_time:.3f}s")
        print()
        
        # Overall status
        status_symbols = {
            ValidationStatus.VALID: "✓",
            ValidationStatus.INVALID: "✗",
            ValidationStatus.WARNING: "⚠",
            ValidationStatus.ERROR: "⊗"
        }
        symbol = status_symbols.get(report.overall_status, "?")
        print(f"Overall Status: {symbol} {report.overall_status.value}")
        print(f"Summary: {report.summary}")
        print()
        
        # Validation levels
        print("Validation Levels:")
        print("-" * 80)
        for level_name, level in report.levels.items():
            status = "✓ PASS" if level.passed else "✗ FAIL"
            print(f"  [{status}] {level.level_name} ({level.execution_time:.3f}s)")
            
            if level.issues:
                print(f"    Issues ({len(level.issues)}):")
                for issue in level.issues:
                    print(f"      • {issue}")
            
            if level.warnings:
                print(f"    Warnings ({len(level.warnings)}):")
                for warning in level.warnings:
                    print(f"      ⚠ {warning}")
            
            print()
        
        # Solution statistics
        print("Solution Statistics:")
        print("-" * 80)
        for key, value in report.solution_statistics.items():
            if isinstance(value, float):
                print(f"  {key}: {value:.4f}")
            else:
                print(f"  {key}: {value}")
        
        print("=" * 80)
    
    def validate_quick(self, solution: np.ndarray) -> bool:
        """
        Quick validation (binary + constraints only).
        
        Args:
            solution: Solution to validate
            
        Returns:
            True if valid, False otherwise
        """
        binary_level = self._validate_binary_integrity(solution)
        if not binary_level.passed:
            return False
        
        constraint_level = self._validate_constraint_satisfaction(solution)
        return constraint_level.passed


if __name__ == '__main__':
    print("=" * 80)
    print("Solution Validator Demonstration")
    print("=" * 80)
    
    # Create test problem
    from core.problem_modeling.uhi_green_layout import UHIProblemConfig
    from core.problem_modeling.cooling_kernels import GaussianCoolingKernel
    
    config = UHIProblemConfig(
        grid_rows=4,
        grid_cols=4,
        cell_size=10.0,
        cooling_kernel_type='gaussian',
        cooling_length_scale=15.0,
        cooling_amplitude=-2.0,
        area_budget_fraction=0.3,
        total_budget=50.0,
        min_green_cells=3,
        max_green_cells=6
    )
    
    problem = UHIGreenLayoutProblem(config)
    problem.setup_uniform_grid(candidate_fraction=1.0)
    problem.setup_cooling_model(kernel=GaussianCoolingKernel(sigma=15.0, amplitude=-2.0))
    Q, metadata = problem.build_qubo()
    
    # Create validator
    validator = SolutionValidator(problem)
    
    # Test 1: Valid solution
    print("\nTest 1: Valid Solution")
    print("=" * 80)
    valid_solution = np.array([1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0], dtype=int)
    report1 = validator.validate_complete(valid_solution, verbose=False)
    validator.print_report(report1)
    
    # Test 2: Invalid solution (too many greens)
    print("\n\nTest 2: Invalid Solution (Constraint Violation)")
    print("=" * 80)
    invalid_solution = np.array([1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0], dtype=int)
    report2 = validator.validate_complete(invalid_solution, verbose=False)
    validator.print_report(report2)
    
    # Test 3: Quick validation
    print("\n\nTest 3: Quick Validation")
    print("=" * 80)
    is_valid = validator.validate_quick(valid_solution)
    print(f"Quick validation result: {'✓ VALID' if is_valid else '✗ INVALID'}")
    
    print("\n" + "=" * 80)
    print("Solution validation demonstration complete!")
    print("=" * 80)
