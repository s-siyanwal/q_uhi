"""
Unit Tests for Validation Framework

Comprehensive tests for all validation modules ensuring correctness and reliability.
"""

import pytest
import numpy as np
from validation.test_cases.toy_examples import (
    get_4cell_example,
    get_8cell_example,
    get_simple_grid_layout,
    get_all_toy_examples,
    verify_toy_example_properties
)
from validation.test_cases.synthetic_instances import (
    generate_random_instance,
    generate_benchmark_suite,
    generate_scaling_suite,
    ProblemDifficulty,
    LandUseDistribution
)
from validation.verification.constraint_checker import ConstraintChecker
from validation.verification.solution_validator import SolutionValidator, ValidationStatus


class TestToyExamples:
    """Test toy example generation."""
    
    def test_4cell_example(self):
        """Test 4-cell example creation."""
        problem, solution = get_4cell_example()
        
        assert problem.n_cells == 4
        assert problem.n_candidates == 4
        assert len(solution.solution_vector) == 4
        assert solution.expected_green_cells == 2
        assert np.sum(solution.solution_vector) == 2
    
    def test_8cell_example(self):
        """Test 8-cell example creation."""
        problem, solution = get_8cell_example()
        
        assert problem.n_cells == 8
        assert len(solution.solution_vector) in [7, 8]  # Depends on fixed greens
        assert solution.expected_green_cells == 3
    
    def test_simple_grid_layout(self):
        """Test simple grid layout with exact count."""
        problem, solution = get_simple_grid_layout(3, 3, 3)
        
        assert problem.n_cells == 9
        assert problem.n_candidates == 9
        assert len(solution.solution_vector) == 9
        assert solution.expected_green_cells == 3
        assert np.sum(solution.solution_vector) == 3
    
    def test_all_toy_examples(self):
        """Test all predefined toy examples."""
        examples = get_all_toy_examples()
        
        assert len(examples) >= 4
        for name, (problem, solution) in examples.items():
            assert problem.n_candidates > 0
            assert len(solution.solution_vector) == problem.n_candidates
            assert np.sum(solution.solution_vector) == solution.expected_green_cells
    
    def test_verify_properties(self):
        """Test toy example property verification."""
        problem, solution = get_4cell_example()
        results = verify_toy_example_properties(problem, solution, verbose=False)
        
        assert results['all_checks_passed']
        assert results['n_failed'] == 0


class TestSyntheticInstances:
    """Test synthetic instance generation."""
    
    def test_random_instance_generation(self):
        """Test basic random instance generation."""
        problem, metadata = generate_random_instance(
            grid_size=5,
            seed=42
        )
        
        assert problem.n_cells == 25
        assert metadata.seed == 42
        assert metadata.grid_size == (5, 5)
        assert 0 <= metadata.constraint_tightness <= 1
    
    def test_difficulty_levels(self):
        """Test different difficulty levels."""
        for difficulty in [ProblemDifficulty.EASY, ProblemDifficulty.MEDIUM, ProblemDifficulty.HARD]:
            problem, metadata = generate_random_instance(
                grid_size=5,
                difficulty=difficulty,
                seed=42
            )
            assert metadata.difficulty == difficulty
            assert problem.n_candidates > 0
    
    def test_land_use_distributions(self):
        """Test different land use distributions."""
        for dist in [LandUseDistribution.UNIFORM, LandUseDistribution.CLUSTERED]:
            problem, metadata = generate_random_instance(
                grid_size=5,
                land_use_dist=dist,
                seed=42
            )
            assert metadata.land_use_distribution == dist
    
    def test_benchmark_suite(self):
        """Test benchmark suite generation."""
        suite = generate_benchmark_suite(
            grid_sizes=[5, 10],
            instances_per_config=2,
            base_seed=100
        )
        
        assert len(suite) >= 4  # 2 sizes × 2+ difficulties × 2 instances
        for problem, metadata in suite:
            assert problem.n_candidates > 0
            assert metadata.seed is not None
    
    def test_scaling_suite(self):
        """Test scaling suite generation."""
        suite = generate_scaling_suite(
            min_size=5,
            max_size=15,
            num_sizes=3,
            instances_per_size=2
        )
        
        sizes = [meta.n_candidates for _, meta in suite]
        assert len(set(sizes)) >= 2  # At least 2 different sizes
    
    def test_reproducibility(self):
        """Test that same seed produces same instance."""
        problem1, meta1 = generate_random_instance(grid_size=5, seed=12345)
        problem2, meta2 = generate_random_instance(grid_size=5, seed=12345)
        
        assert problem1.n_candidates == problem2.n_candidates
        assert meta1.n_cells == meta2.n_cells


class TestConstraintChecker:
    """Test constraint checking functionality."""
    
    @pytest.fixture
    def setup_problem(self):
        """Create a test problem."""
        problem, solution = get_4cell_example()
        return problem, solution
    
    def test_feasible_solution(self, setup_problem):
        """Test checking a feasible solution."""
        problem, solution = setup_problem
        checker = ConstraintChecker(problem)
        
        result = checker.check_all_constraints(solution.solution_vector)
        
        assert result.is_feasible
        assert result.n_violations == 0
    
    def test_infeasible_solution_count(self, setup_problem):
        """Test detecting violation of green cell count."""
        problem, solution = setup_problem
        checker = ConstraintChecker(problem)
        
        # Create solution with too many greens
        bad_solution = np.ones(problem.n_candidates, dtype=int)
        result = checker.check_all_constraints(bad_solution)
        
        # Should violate area/budget constraints
        assert not result.is_feasible or result.n_violations > 0
    
    def test_binary_integrity_check(self, setup_problem):
        """Test binary integrity checking."""
        problem, _ = setup_problem
        checker = ConstraintChecker(problem)
        
        # Non-binary solution
        bad_solution = np.array([0.5, 0.3, 0.8, 0.1])
        result = checker.check_all_constraints(bad_solution)
        
        binary_violations = [v for v in result.violations 
                            if v.constraint_type == 'binary_integrity']
        assert len(binary_violations) > 0
    
    def test_constraint_type_filtering(self, setup_problem):
        """Test checking specific constraint types."""
        problem, solution = setup_problem
        checker = ConstraintChecker(problem)
        
        area_violations = checker.check_constraint_type(
            solution.solution_vector, 'area'
        )
        assert isinstance(area_violations, list)
    
    def test_total_violation_penalty(self, setup_problem):
        """Test total violation penalty computation."""
        problem, solution = setup_problem
        checker = ConstraintChecker(problem)
        
        # Feasible solution should have 0 penalty
        penalty = checker.compute_total_violation_penalty(solution.solution_vector)
        assert penalty == 0.0 or penalty < 1e-6
        
        # Infeasible solution should have positive penalty
        bad_solution = np.ones(problem.n_candidates, dtype=int)
        penalty_bad = checker.compute_total_violation_penalty(bad_solution)
        # May or may not have penalty depending on constraints


class TestSolutionValidator:
    """Test solution validation functionality."""
    
    @pytest.fixture
    def setup_validator(self):
        """Create a test validator."""
        problem, solution = get_4cell_example()
        validator = SolutionValidator(problem)
        return validator, problem, solution
    
    def test_complete_validation_valid(self, setup_validator):
        """Test complete validation of valid solution."""
        validator, problem, solution = setup_validator
        
        report = validator.validate_complete(solution.solution_vector)
        
        assert report.is_valid
        assert report.overall_status in [ValidationStatus.VALID, ValidationStatus.WARNING]
        assert len(report.levels) == 4  # 4 validation levels
    
    def test_validation_levels(self, setup_validator):
        """Test all validation levels are executed."""
        validator, problem, solution = setup_validator
        
        report = validator.validate_complete(solution.solution_vector)
        
        expected_levels = [
            'binary_integrity',
            'constraint_satisfaction',
            'energy_consistency',
            'physical_plausibility'
        ]
        for level in expected_levels:
            assert level in report.levels
            assert report.levels[level].execution_time >= 0
    
    def test_quick_validation(self, setup_validator):
        """Test quick validation mode."""
        validator, problem, solution = setup_validator
        
        is_valid = validator.validate_quick(solution.solution_vector)
        assert isinstance(is_valid, bool)
    
    def test_invalid_solution_detection(self, setup_validator):
        """Test detection of invalid solution."""
        validator, problem, solution = setup_validator
        
        # Non-binary solution
        bad_solution = np.array([0.5] * problem.n_candidates)
        report = validator.validate_complete(bad_solution)
        
        assert not report.is_valid
        assert report.overall_status == ValidationStatus.INVALID
        assert len(report.get_all_issues()) > 0
    
    def test_solution_statistics(self, setup_validator):
        """Test solution statistics computation."""
        validator, problem, solution = setup_validator
        
        report = validator.validate_complete(solution.solution_vector)
        
        stats = report.solution_statistics
        assert 'n_green_cells' in stats
        assert 'n_candidates' in stats
        assert 'green_fraction' in stats
        assert stats['n_green_cells'] == solution.expected_green_cells


class TestIntegration:
    """Integration tests for validation framework."""
    
    def test_full_workflow(self):
        """Test complete workflow: generate -> validate -> report."""
        # Generate problem
        problem, metadata = generate_random_instance(
            grid_size=5,
            difficulty=ProblemDifficulty.EASY,
            seed=999
        )
        
        # Create a simple solution
        n_green = min(3, problem.n_candidates)
        solution = np.zeros(problem.n_candidates, dtype=int)
        solution[:n_green] = 1
        
        # Validate constraints
        checker = ConstraintChecker(problem)
        constraint_result = checker.check_all_constraints(solution)
        
        # Full validation
        validator = SolutionValidator(problem)
        validation_report = validator.validate_complete(solution)
        
        # Check results are consistent
        assert validation_report.solution_statistics['n_green_cells'] == n_green
    
    def test_toy_example_full_validation(self):
        """Test full validation on all toy examples."""
        examples = get_all_toy_examples()
        
        for name, (problem, solution) in examples.items():
            # Verify properties
            props = verify_toy_example_properties(problem, solution, verbose=False)
            assert props['all_checks_passed'], f"Properties check failed for {name}"
            
            # Validate solution
            validator = SolutionValidator(problem)
            report = validator.validate_complete(solution.solution_vector)
            
            # Toy examples may not pass all constraints (they're examples, not necessarily feasible)
            # Just ensure validation runs without error
            assert report is not None
            assert 'binary_integrity' in report.levels


if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])
