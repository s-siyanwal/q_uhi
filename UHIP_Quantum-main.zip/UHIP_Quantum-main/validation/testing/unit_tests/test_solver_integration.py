"""
Comprehensive Unit Tests for Solver Integration Module

Tests the solver_integration module including:
- SolutionResult: Result dataclass and serialization
- SimulatedAnnealingSolver: SA implementation with SC checkpoints
- TabuSearchSolver: Tabu search algorithm
- GeneticAlgorithmSolver: GA implementation
- SimulatedQuantumAnnealingSolver: SQA implementation
- create_solver: Factory function
- Solver interface compliance

Author: UHI-QUBO Testing Team
"""

import pytest
import numpy as np
from typing import Dict, Any

from core.solver_integration.solver_interface import (
    SolutionResult,
    SolverInterface,
    SimulatedAnnealingSolver,
    TabuSearchSolver,
    GeneticAlgorithmSolver,
    SimulatedQuantumAnnealingSolver,
    create_solver
)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def tiny_qubo():
    """Tiny 5x5 QUBO for quick tests."""
    Q = np.random.randn(5, 5)
    Q = (Q + Q.T) / 2  # Make symmetric
    return Q


@pytest.fixture
def small_qubo():
    """Small 10x10 QUBO for realistic tests."""
    np.random.seed(42)
    Q = np.random.randn(10, 10)
    Q = (Q + Q.T) / 2
    return Q


@pytest.fixture
def medium_qubo():
    """Medium 50x50 QUBO."""
    np.random.seed(42)
    Q = np.random.randn(50, 50)
    Q = (Q + Q.T) / 2
    return Q


@pytest.fixture
def known_solution_qubo():
    """QUBO with known optimal solution."""
    # Solution x = [1, 0, 1, 0] has energy -4
    Q = np.array([
        [-1, 0, 1, 0],
        [0, 2, 0, -1],
        [1, 0, -1, 0],
        [0, -1, 0, 1]
    ])
    return Q


@pytest.fixture
def all_zeros_optimal_qubo():
    """QUBO where all zeros is optimal (positive diagonal)."""
    Q = np.diag([1, 2, 3, 4, 5])
    return Q


@pytest.fixture
def all_ones_optimal_qubo():
    """QUBO where all ones is optimal."""
    Q = -np.diag([1, 2, 3, 4, 5])
    return Q


# ============================================================================
# SolutionResult Tests
# ============================================================================

class TestSolutionResult:
    """Test SolutionResult dataclass."""
    
    def test_basic_initialization(self):
        """Test creating a basic result."""
        solution = np.array([1, 0, 1, 0, 1])
        result = SolutionResult(
            solution=solution,
            energy=-5.5,
            execution_time=1.23
        )
        
        assert np.array_equal(result.solution, solution)
        assert result.energy == -5.5
        assert result.execution_time == 1.23
        assert isinstance(result.solver_info, dict)
        assert isinstance(result.convergence_data, dict)
    
    def test_full_initialization(self):
        """Test creating result with all fields."""
        solution = np.array([1, 0, 1])
        result = SolutionResult(
            solution=solution,
            energy=-2.0,
            execution_time=0.5,
            solver_info={'algorithm': 'SA', 'iterations': 100},
            convergence_data={'energy_history': [-1.0, -1.5, -2.0]},
            verification_results={'SC-1': True, 'SC-2': True, 'SC-3': True}
        )
        
        assert result.solver_info['algorithm'] == 'SA'
        assert len(result.convergence_data['energy_history']) == 3
        assert result.verification_results['SC-1']
    
    def test_to_dict(self):
        """Test serialization to dictionary."""
        solution = np.array([1, 0, 1])
        result = SolutionResult(
            solution=solution,
            energy=-2.0,
            execution_time=0.5,
            solver_info={'algorithm': 'Test'}
        )
        
        d = result.to_dict()
        
        assert isinstance(d, dict)
        assert d['solution'] == [1, 0, 1]
        assert d['energy'] == -2.0
        assert d['execution_time'] == 0.5
        assert d['solver_info']['algorithm'] == 'Test'
    
    def test_repr(self):
        """Test string representation."""
        solution = np.array([1, 0, 1, 0, 0])
        result = SolutionResult(
            solution=solution,
            energy=-3.5,
            execution_time=1.0,
            solver_info={'algorithm': 'TestSolver'}
        )
        
        repr_str = repr(result)
        
        assert 'TestSolver' in repr_str
        assert '-3.5' in repr_str
        assert '1.0' in repr_str
        assert '3/5' in repr_str  # density


# ============================================================================
# SimulatedAnnealingSolver Tests
# ============================================================================

class TestSimulatedAnnealingSolver:
    """Test Simulated Annealing solver implementation."""
    
    def test_initialization(self):
        """Test SA solver initialization."""
        solver = SimulatedAnnealingSolver(seed=42)
        assert solver.seed == 42
        assert isinstance(solver.rng, np.random.Generator)
    
    def test_solve_small_problem(self, small_qubo):
        """Test solving small QUBO."""
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(small_qubo, max_iterations=100)
        
        assert isinstance(result, SolutionResult)
        assert len(result.solution) == 10
        assert all(x in [0, 1] for x in result.solution)
        assert isinstance(result.energy, (int, float))
        assert result.execution_time > 0
    
    def test_solve_with_custom_params(self, small_qubo):
        """Test solving with custom SA parameters."""
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(
            small_qubo,
            max_iterations=200,
            T_initial=10.0,
            T_final=0.01,
            cooling_rate=0.95
        )
        
        assert result.solver_info.get('max_iterations') == 200
    
    def test_energy_decreases(self, medium_qubo):
        """Test that energy generally decreases."""
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(medium_qubo, max_iterations=500)
        
        history = result.convergence_data.get('energy_history', [])
        if len(history) > 10:
            # Initial energy should be higher than final (generally)
            assert history[0] >= history[-1]
    
    def test_verification_checkpoints(self, small_qubo):
        """Test SC-1, SC-2, SC-3 verification checkpoints."""
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(small_qubo, max_iterations=100, verify=True)
        
        # Check that verification results are present
        if result.verification_results:
            assert 'SC-1' in result.verification_results
            assert 'SC-2' in result.verification_results
            assert 'SC-3' in result.verification_results
    
    def test_deterministic_with_seed(self, tiny_qubo):
        """Test that same seed gives same results."""
        solver1 = SimulatedAnnealingSolver(seed=42)
        result1 = solver1.solve(tiny_qubo, max_iterations=50)
        
        solver2 = SimulatedAnnealingSolver(seed=42)
        result2 = solver2.solve(tiny_qubo, max_iterations=50)
        
        assert np.array_equal(result1.solution, result2.solution)
        assert result1.energy == result2.energy
    
    def test_finds_known_solution(self, all_zeros_optimal_qubo):
        """Test finding known optimal solution (all zeros)."""
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(all_zeros_optimal_qubo, max_iterations=1000)
        
        # Should find all zeros (or very close)
        energy_all_zeros = 0.0
        assert result.energy <= energy_all_zeros + 1.0  # Allow small tolerance
    
    def test_convergence_data_present(self, small_qubo):
        """Test that convergence data is recorded."""
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(small_qubo, max_iterations=100)
        
        assert 'energy_history' in result.convergence_data
        assert len(result.convergence_data['energy_history']) > 0
        
        # May also have acceptance rates, temperature history
        if 'acceptance_rates' in result.convergence_data:
            assert len(result.convergence_data['acceptance_rates']) > 0


class TestSimulatedAnnealingEdgeCases:
    """Test SA edge cases and error handling."""
    
    def test_invalid_qubo_shape(self):
        """Test error on non-square QUBO."""
        solver = SimulatedAnnealingSolver()
        Q = np.random.randn(5, 7)
        
        with pytest.raises(ValueError):
            solver.solve(Q)
    
    def test_empty_qubo(self):
        """Test error on empty QUBO."""
        solver = SimulatedAnnealingSolver()
        Q = np.array([[]]).reshape(0, 0)
        
        with pytest.raises(ValueError):
            solver.solve(Q)
    
    def test_single_variable(self):
        """Test single variable QUBO."""
        solver = SimulatedAnnealingSolver(seed=42)
        Q = np.array([[-1.0]])
        result = solver.solve(Q, max_iterations=10)
        
        assert len(result.solution) == 1
        # Should choose x=1 for negative coefficient
        assert result.solution[0] == 1


# ============================================================================
# TabuSearchSolver Tests
# ============================================================================

class TestTabuSearchSolver:
    """Test Tabu Search solver implementation."""
    
    def test_initialization(self):
        """Test TS solver initialization."""
        solver = TabuSearchSolver(seed=42)
        assert solver.seed == 42
    
    def test_solve_small_problem(self, small_qubo):
        """Test solving small QUBO with Tabu Search."""
        solver = TabuSearchSolver(seed=42)
        result = solver.solve(small_qubo, max_iterations=100)
        
        assert isinstance(result, SolutionResult)
        assert len(result.solution) == 10
        assert all(x in [0, 1] for x in result.solution)
    
    def test_tabu_list_prevents_cycles(self, tiny_qubo):
        """Test that tabu list prevents immediate cycling."""
        solver = TabuSearchSolver(seed=42)
        result = solver.solve(tiny_qubo, max_iterations=50, tabu_tenure=5)
        
        # Check solver completed
        assert result.execution_time > 0
    
    def test_solve_with_aspiration_criterion(self, small_qubo):
        """Test that aspiration criterion allows good moves."""
        solver = TabuSearchSolver(seed=42)
        result = solver.solve(small_qubo, max_iterations=100, use_aspiration=True)
        
        assert result.energy < np.inf


# ============================================================================
# GeneticAlgorithmSolver Tests
# ============================================================================

class TestGeneticAlgorithmSolver:
    """Test Genetic Algorithm solver implementation."""
    
    def test_initialization(self):
        """Test GA solver initialization."""
        solver = GeneticAlgorithmSolver(seed=42)
        assert solver.seed == 42
    
    def test_solve_small_problem(self, small_qubo):
        """Test solving small QUBO with GA."""
        solver = GeneticAlgorithmSolver(seed=42)
        result = solver.solve(
            small_qubo,
            population_size=20,
            generations=50
        )
        
        assert isinstance(result, SolutionResult)
        assert len(result.solution) == 10
        assert all(x in [0, 1] for x in result.solution)
    
    def test_population_evolution(self, small_qubo):
        """Test that population evolves over generations."""
        solver = GeneticAlgorithmSolver(seed=42)
        result = solver.solve(
            small_qubo,
            population_size=30,
            generations=100
        )
        
        # Energy should improve
        history = result.convergence_data.get('energy_history', [])
        if len(history) > 10:
            assert history[-1] <= history[0]
    
    def test_diversity_tracking(self, small_qubo):
        """Test that diversity is tracked."""
        solver = GeneticAlgorithmSolver(seed=42)
        result = solver.solve(
            small_qubo,
            population_size=20,
            generations=50
        )
        
        # May have diversity history
        if 'diversity_history' in result.convergence_data:
            assert len(result.convergence_data['diversity_history']) > 0
    
    def test_crossover_and_mutation(self, tiny_qubo):
        """Test that crossover and mutation work."""
        solver = GeneticAlgorithmSolver(seed=42)
        result = solver.solve(
            tiny_qubo,
            population_size=10,
            generations=30,
            crossover_rate=0.8,
            mutation_rate=0.1
        )
        
        assert result.execution_time > 0


# ============================================================================
# SimulatedQuantumAnnealingSolver Tests
# ============================================================================

class TestSimulatedQuantumAnnealingSolver:
    """Test Simulated Quantum Annealing solver."""
    
    def test_initialization(self):
        """Test SQA solver initialization."""
        solver = SimulatedQuantumAnnealingSolver(seed=42)
        assert solver.seed == 42
    
    def test_solve_small_problem(self, small_qubo):
        """Test solving small QUBO with SQA."""
        solver = SimulatedQuantumAnnealingSolver(seed=42)
        result = solver.solve(
            small_qubo,
            num_reads=10,
            num_sweeps=100
        )
        
        assert isinstance(result, SolutionResult)
        assert len(result.solution) == 10
        assert all(x in [0, 1] for x in result.solution)
    
    def test_quantum_annealing_schedule(self, tiny_qubo):
        """Test that quantum annealing schedule is used."""
        solver = SimulatedQuantumAnnealingSolver(seed=42)
        result = solver.solve(
            tiny_qubo,
            num_reads=5,
            num_sweeps=50
        )
        
        # Check metadata for schedule information
        assert 'algorithm' in result.solver_info
    
    def test_multiple_reads(self, tiny_qubo):
        """Test multiple independent reads."""
        solver = SimulatedQuantumAnnealingSolver(seed=42)
        result = solver.solve(
            tiny_qubo,
            num_reads=20,
            num_sweeps=50
        )
        
        # Should return best result from multiple reads
        assert result.solution is not None


# ============================================================================
# Solver Factory Tests
# ============================================================================

class TestCreateSolver:
    """Test solver factory function."""
    
    def test_create_sa_solver(self):
        """Test creating SA solver via factory."""
        solver = create_solver('simulated_annealing', seed=42)
        assert isinstance(solver, SimulatedAnnealingSolver)
        assert solver.seed == 42
    
    def test_create_tabu_solver(self):
        """Test creating Tabu Search solver via factory."""
        solver = create_solver('tabu_search', seed=42)
        assert isinstance(solver, TabuSearchSolver)
    
    def test_create_ga_solver(self):
        """Test creating GA solver via factory."""
        solver = create_solver('genetic_algorithm', seed=42)
        assert isinstance(solver, GeneticAlgorithmSolver)
    
    def test_create_sqa_solver(self):
        """Test creating SQA solver via factory."""
        solver = create_solver('simulated_quantum_annealing', seed=42)
        assert isinstance(solver, SimulatedQuantumAnnealingSolver)
    
    def test_invalid_solver_name(self):
        """Test error on invalid solver name."""
        with pytest.raises(ValueError, match="Unknown solver"):
            create_solver('invalid_solver')
    
    def test_case_insensitive(self):
        """Test that solver names are case-insensitive."""
        solver = create_solver('SIMULATED_ANNEALING', seed=42)
        assert isinstance(solver, SimulatedAnnealingSolver)


# ============================================================================
# Solver Interface Compliance Tests
# ============================================================================

class TestSolverInterfaceCompliance:
    """Test that all solvers comply with interface."""
    
    @pytest.mark.parametrize("solver_name", [
        'simulated_annealing',
        'tabu_search',
        'genetic_algorithm',
        'simulated_quantum_annealing'
    ])
    def test_solver_is_subclass(self, solver_name):
        """Test that all solvers are SolverInterface subclasses."""
        solver = create_solver(solver_name, seed=42)
        assert isinstance(solver, SolverInterface)
    
    @pytest.mark.parametrize("solver_name", [
        'simulated_annealing',
        'tabu_search',
        'genetic_algorithm',
        'simulated_quantum_annealing'
    ])
    def test_solver_has_solve_method(self, solver_name):
        """Test that all solvers have solve method."""
        solver = create_solver(solver_name, seed=42)
        assert hasattr(solver, 'solve')
        assert callable(solver.solve)
    
    @pytest.mark.parametrize("solver_name", [
        'simulated_annealing',
        'tabu_search',
        'genetic_algorithm',
        'simulated_quantum_annealing'
    ])
    def test_solver_returns_solution_result(self, solver_name, tiny_qubo):
        """Test that all solvers return SolutionResult."""
        solver = create_solver(solver_name, seed=42)
        result = solver.solve(tiny_qubo, max_iterations=20)
        assert isinstance(result, SolutionResult)
    
    @pytest.mark.parametrize("solver_name", [
        'simulated_annealing',
        'tabu_search',
        'genetic_algorithm',
        'simulated_quantum_annealing'
    ])
    def test_solver_produces_valid_solution(self, solver_name, tiny_qubo):
        """Test that all solvers produce valid binary solutions."""
        solver = create_solver(solver_name, seed=42)
        result = solver.solve(tiny_qubo, max_iterations=20)
        
        assert len(result.solution) == len(tiny_qubo)
        assert all(x in [0, 1] for x in result.solution)
        assert isinstance(result.energy, (int, float))
        assert result.execution_time >= 0


# ============================================================================
# Energy Computation Tests
# ============================================================================

class TestEnergyComputation:
    """Test that energy is correctly computed."""
    
    def test_energy_matches_objective(self, small_qubo):
        """Test that reported energy matches QUBO objective."""
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(small_qubo, max_iterations=100)
        
        # Compute energy manually
        x = result.solution
        energy_computed = x @ small_qubo @ x
        
        assert result.energy == pytest.approx(energy_computed, rel=1e-6)
    
    def test_all_zeros_energy(self):
        """Test energy computation for all-zeros solution."""
        Q = np.random.randn(5, 5)
        Q = (Q + Q.T) / 2
        
        x = np.zeros(5)
        energy = x @ Q @ x
        
        assert energy == 0.0
    
    def test_all_ones_energy(self):
        """Test energy computation for all-ones solution."""
        Q = np.array([
            [1, -1, 0],
            [-1, 2, -1],
            [0, -1, 1]
        ])
        
        x = np.ones(3)
        energy = x @ Q @ x
        # Energy = 1 - 1 + 0 - 1 + 2 - 1 + 0 - 1 + 1 = 0
        expected = 0.0
        
        assert energy == pytest.approx(expected)


# ============================================================================
# Performance Tests
# ============================================================================

class TestSolverPerformance:
    """Test solver performance characteristics."""
    
    def test_sa_completes_quickly(self, small_qubo):
        """Test that SA completes in reasonable time."""
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(small_qubo, max_iterations=100)
        
        # Should complete in under 5 seconds for small problem
        assert result.execution_time < 5.0
    
    def test_multiple_solves_independent(self, tiny_qubo):
        """Test that multiple solves are independent."""
        solver = SimulatedAnnealingSolver(seed=None)  # Random seed
        
        result1 = solver.solve(tiny_qubo, max_iterations=20)
        result2 = solver.solve(tiny_qubo, max_iterations=20)
        
        # May get different solutions (non-deterministic)
        # Just check both are valid
        assert len(result1.solution) == len(tiny_qubo)
        assert len(result2.solution) == len(tiny_qubo)


# ============================================================================
# Comparison Tests
# ============================================================================

class TestSolverComparison:
    """Compare different solvers on same problem."""
    
    def test_all_solvers_on_same_problem(self, small_qubo):
        """Test that all solvers can solve the same problem."""
        solvers = [
            SimulatedAnnealingSolver(seed=42),
            TabuSearchSolver(seed=42),
            GeneticAlgorithmSolver(seed=42),
            SimulatedQuantumAnnealingSolver(seed=42)
        ]
        
        results = []
        for solver in solvers:
            result = solver.solve(small_qubo, max_iterations=100)
            results.append(result)
        
        # All should produce valid results
        for result in results:
            assert len(result.solution) == 10
            assert isinstance(result.energy, (int, float))
    
    def test_solver_quality_comparison(self, all_ones_optimal_qubo):
        """Compare solver quality on problem with known optimum."""
        solvers = {
            'SA': SimulatedAnnealingSolver(seed=42),
            'TS': TabuSearchSolver(seed=42),
            'GA': GeneticAlgorithmSolver(seed=42),
        }
        
        results = {}
        for name, solver in solvers.items():
            result = solver.solve(all_ones_optimal_qubo, max_iterations=200)
            results[name] = result.energy
        
        # All should find good solutions (negative energy)
        for name, energy in results.items():
            assert energy < 0, f"{name} failed to find negative energy"


# ============================================================================
# Metadata and Logging Tests
# ============================================================================

class TestSolverMetadata:
    """Test solver metadata and logging."""
    
    def test_solver_info_populated(self, tiny_qubo):
        """Test that solver info is populated."""
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(tiny_qubo, max_iterations=50)
        
        assert 'algorithm' in result.solver_info
        assert len(result.solver_info) > 0
    
    def test_convergence_data_recorded(self, tiny_qubo):
        """Test that convergence data is recorded."""
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(tiny_qubo, max_iterations=50)
        
        assert 'energy_history' in result.convergence_data
        assert len(result.convergence_data['energy_history']) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
