"""
Comprehensive Unit Tests for Spatial Modeling Module

Tests the spatial_modeling module including:
- UrbanGrid: Grid structure, indexing, distances, neighbors
- HeatDiffusionSolver: PDE solving, cooling effects
- ConnectivityAnalyzer: Graph operations, connectivity verification
- Helper functions: Synthetic grid generation

Author: UHI-QUBO Testing Team
"""

import pytest
import numpy as np
import networkx as nx
from typing import List, Set

from core.spatial_modeling.urban_grid import UrbanGrid, CellProperties
from core.spatial_modeling.heat_diffusion import HeatDiffusionSolver
from core.spatial_modeling.connectivity_analyzer import ConnectivityAnalyzer


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def small_grid():
    """Small 5x5 grid for basic tests."""
    return UrbanGrid(n_rows=5, n_cols=5, cell_size=50.0)


@pytest.fixture
def medium_grid():
    """Medium 10x10 grid for realistic tests."""
    grid = UrbanGrid(n_rows=10, n_cols=10, cell_size=100.0)
    # Set temperature field
    temps = np.random.uniform(25, 35, (10, 10))
    grid.set_temperature_field(temps)
    return grid


@pytest.fixture
def large_grid():
    """Larger 20x20 grid for performance tests."""
    return UrbanGrid(n_rows=20, n_cols=20, cell_size=50.0, origin=(1000.0, 2000.0))


@pytest.fixture
def grid_with_obstacles(small_grid):
    """Grid with some prohibited cells."""
    prohibited = {0, 1, 2, 5, 10}
    small_grid.set_prohibited_cells(prohibited)
    return small_grid


@pytest.fixture
def heat_solver(medium_grid):
    """Heat diffusion solver with medium grid."""
    return HeatDiffusionSolver(medium_grid, alpha=1e-5, method='explicit')


@pytest.fixture
def connectivity_analyzer(medium_grid):
    """Connectivity analyzer with 4-connected grid."""
    return ConnectivityAnalyzer(medium_grid, connectivity=4)


# ============================================================================
# UrbanGrid Tests
# ============================================================================

class TestUrbanGridInitialization:
    """Test UrbanGrid initialization and parameter validation."""
    
    def test_valid_initialization(self):
        """Test successful grid creation with valid parameters."""
        grid = UrbanGrid(n_rows=10, n_cols=8, cell_size=50.0)
        assert grid.n_rows == 10
        assert grid.n_cols == 8
        assert grid.N == 80
        assert grid.cell_size == 50.0
        assert grid.origin == (0.0, 0.0)
    
    def test_custom_origin(self):
        """Test grid with custom origin."""
        grid = UrbanGrid(n_rows=5, n_cols=5, cell_size=100.0, origin=(1000.0, 2000.0))
        assert grid.origin == (1000.0, 2000.0)
    
    def test_invalid_dimensions(self):
        """Test that invalid dimensions raise errors."""
        with pytest.raises(ValueError, match="Grid dimensions must be positive"):
            UrbanGrid(n_rows=0, n_cols=5, cell_size=50.0)
        with pytest.raises(ValueError, match="Grid dimensions must be positive"):
            UrbanGrid(n_rows=5, n_cols=-1, cell_size=50.0)
    
    def test_invalid_cell_size(self):
        """Test that invalid cell size raises error."""
        with pytest.raises(ValueError, match="Cell size must be positive"):
            UrbanGrid(n_rows=5, n_cols=5, cell_size=0.0)
        with pytest.raises(ValueError, match="Cell size must be positive"):
            UrbanGrid(n_rows=5, n_cols=5, cell_size=-10.0)


class TestUrbanGridIndexing:
    """Test grid indexing and coordinate conversions."""
    
    def test_flatten_unflatten_roundtrip(self, small_grid):
        """Test 2D to 1D and back conversion."""
        for row in range(5):
            for col in range(5):
                idx = small_grid.flatten_index(row, col)
                r, c = small_grid.unflatten_index(idx)
                assert r == row
                assert c == col
    
    def test_flatten_index_bounds(self, small_grid):
        """Test flattened index bounds."""
        idx = small_grid.flatten_index(0, 0)
        assert idx == 0
        
        idx = small_grid.flatten_index(4, 4)
        assert idx == 24
        
        idx = small_grid.flatten_index(2, 3)
        assert idx == 2 * 5 + 3
    
    def test_unflatten_index_bounds(self, small_grid):
        """Test unflattening edge cases."""
        row, col = small_grid.unflatten_index(0)
        assert (row, col) == (0, 0)
        
        row, col = small_grid.unflatten_index(24)
        assert (row, col) == (4, 4)
    
    def test_is_valid_index(self, small_grid):
        """Test index validity checking via unflatten_index."""
        # Valid indices should not raise errors
        try:
            small_grid.unflatten_index(0)
            small_grid.unflatten_index(24)
            small_grid.unflatten_index(12)
            valid = True
        except IndexError:
            valid = False
        assert valid
        
        # Invalid indices should raise errors
        with pytest.raises(IndexError):
            small_grid.unflatten_index(-1)
        with pytest.raises(IndexError):
            small_grid.unflatten_index(25)
        with pytest.raises(IndexError):
            small_grid.unflatten_index(100)


class TestUrbanGridGeometry:
    """Test geometric operations: distances, centroids, neighbors."""
    
    def test_get_centroid(self, small_grid):
        """Test centroid calculation."""
        # Cell (0, 0) - southwest corner
        centroid = small_grid.get_centroid(0)
        assert centroid[0] == 25.0  # cell_size/2
        assert centroid[1] == 25.0
        
        # Cell (4, 4) - northeast corner
        centroid = small_grid.get_centroid(24)
        assert centroid[0] == 4 * 50 + 25.0
        assert centroid[1] == 4 * 50 + 25.0
    
    def test_get_centroid_with_origin(self, large_grid):
        """Test centroid with non-zero origin."""
        centroid = large_grid.get_centroid(0)
        assert centroid[0] == 1000.0 + 25.0
        assert centroid[1] == 2000.0 + 25.0
    
    def test_manhattan_distance(self, small_grid):
        """Test Manhattan distance calculation."""
        # Horizontal neighbors
        dist = small_grid.get_distance(0, 1, metric='manhattan')
        assert dist == 50.0  # One cell width
        
        # Vertical neighbors
        dist = small_grid.get_distance(0, 5, metric='manhattan')
        assert dist == 50.0
        
        # Diagonal
        dist = small_grid.get_distance(0, 6, metric='manhattan')
        assert dist == 100.0  # Two moves
        
        # Opposite corners
        dist = small_grid.get_distance(0, 24, metric='manhattan')
        assert dist == 400.0  # 4 cells in each direction
    
    def test_euclidean_distance(self, small_grid):
        """Test Euclidean distance calculation."""
        # Same cell
        dist = small_grid.get_distance(5, 5)
        assert dist == 0.0
        
        # Horizontal neighbors
        dist = small_grid.get_distance(0, 1)
        assert dist == pytest.approx(50.0)
        
        # Diagonal neighbors
        dist = small_grid.get_distance(0, 6)
        assert dist == pytest.approx(50.0 * np.sqrt(2), rel=1e-6)
        
        # Opposite corners
        dist = small_grid.get_distance(0, 24)
        expected = 50.0 * np.sqrt(4**2 + 4**2)
        assert dist == pytest.approx(expected, rel=1e-6)
    
    def test_get_neighbors_4connected(self, small_grid):
        """Test 4-connected neighborhood."""
        # Corner cell (0)
        neighbors = small_grid.get_neighbors(0, connectivity=4)
        assert set(neighbors) == {1, 5}
        
        # Edge cell (5)
        neighbors = small_grid.get_neighbors(5, connectivity=4)
        assert set(neighbors) == {0, 6, 10}
        
        # Interior cell (12)
        neighbors = small_grid.get_neighbors(12, connectivity=4)
        assert set(neighbors) == {7, 11, 13, 17}
    
    def test_get_neighbors_8connected(self, small_grid):
        """Test 8-connected neighborhood."""
        # Corner cell (0)
        neighbors = small_grid.get_neighbors(0, connectivity=8)
        assert set(neighbors) == {1, 5, 6}
        
        # Interior cell (12)
        neighbors = small_grid.get_neighbors(12, connectivity=8)
        assert len(neighbors) == 8
        expected = {6, 7, 8, 11, 13, 16, 17, 18}
        assert set(neighbors) == expected


class TestUrbanGridTemperature:
    """Test temperature field operations."""
    
    def test_set_temperature_field(self, small_grid):
        """Test setting temperature field."""
        temps = np.random.uniform(25, 35, (5, 5))
        small_grid.set_temperature_field(temps)
        
        # Check temperatures are set
        for i in range(25):
            row, col = small_grid.unflatten_index(i)
            assert small_grid.temperature[row, col] == temps[row, col]
    
    def test_set_temperature_wrong_shape(self, small_grid):
        """Test error on wrong temperature shape."""
        temps = np.random.uniform(25, 35, (4, 4))
        with pytest.raises(ValueError, match="shape"):
            small_grid.set_temperature_field(temps)
    
    def test_get_temperature(self, medium_grid):
        """Test temperature retrieval."""
        for i in range(medium_grid.N):
            row, col = medium_grid.unflatten_index(i)
            temp = medium_grid.temperature[row, col]
            assert 25.0 <= temp <= 35.0
    
    def test_get_temperature_gradient(self, medium_grid):
        """Test temperature gradient computation (not directly available)."""
        # Set linear temperature field
        temps = np.zeros((10, 10))
        for i in range(10):
            for j in range(10):
                temps[i, j] = i + j  # Linear gradient
        medium_grid.set_temperature_field(temps)
        
        # Check temperatures are set correctly
        row, col = medium_grid.unflatten_index(55)
        assert medium_grid.temperature[row, col] == row + col


class TestUrbanGridProperties:
    """Test cell property management."""
    
    def test_mark_prohibited(self, small_grid):
        """Test marking cells as prohibited."""
        small_grid.set_prohibited_cells({5})
        assert small_grid.cells[5].is_prohibited
        assert not small_grid.cells[6].is_prohibited
    
    def test_get_cell_properties(self, small_grid):
        """Test retrieving cell properties."""
        props = small_grid.cells[12]
        assert isinstance(props, CellProperties)
        assert props.index == 12
        assert props.row == 2
        assert props.col == 2
    
    def test_get_available_cells(self, grid_with_obstacles):
        """Test getting available (non-prohibited) cells."""
        available = grid_with_obstacles.get_candidate_cells()
        prohibited = {0, 1, 2, 5, 10}
        
        assert len(available) == 25 - len(prohibited)
        assert not any(cell in prohibited for cell in available)


# ============================================================================
# HeatDiffusionSolver Tests
# ============================================================================

class TestHeatDiffusionInitialization:
    """Test heat diffusion solver initialization."""
    
    def test_explicit_solver_init(self, medium_grid):
        """Test explicit solver initialization."""
        solver = HeatDiffusionSolver(medium_grid, alpha=1e-5, method='explicit')
        assert solver.grid == medium_grid
        assert solver.alpha == 1e-5
        assert solver.method == 'explicit'
        assert solver.time == 0.0
        assert len(solver.T) == medium_grid.N
    
    def test_implicit_solver_init(self, medium_grid):
        """Test implicit solver initialization."""
        solver = HeatDiffusionSolver(medium_grid, alpha=1e-5, method='implicit')
        assert solver.method == 'implicit'
    
    def test_invalid_method(self, medium_grid):
        """Test error on invalid method."""
        with pytest.raises(ValueError, match="Unknown method"):
            HeatDiffusionSolver(medium_grid, alpha=1e-5, method='invalid')
    
    def test_stable_timestep_computation(self, heat_solver):
        """Test that stable timestep is computed."""
        assert heat_solver.dt_stable > 0
        # CFL condition: dt <= h^2 / (4*alpha)
        expected_max = heat_solver.grid.cell_size**2 / (4 * heat_solver.alpha)
        assert heat_solver.dt_stable <= expected_max


class TestHeatDiffusionEvolution:
    """Test heat equation evolution."""
    
    def test_set_initial_temperature(self, heat_solver):
        """Test setting uniform initial temperature."""
        heat_solver.set_initial_temperature(30.0)
        assert np.allclose(heat_solver.T, 30.0)
    
    def test_set_initial_temperature_field(self, heat_solver):
        """Test setting non-uniform initial temperature."""
        temps = np.random.uniform(25, 35, heat_solver.grid.N)
        heat_solver.set_initial_temperature(temps)
        assert np.allclose(heat_solver.T, temps)
    
    def test_diffusion_smoothing(self, heat_solver):
        """Test that diffusion smooths temperature field."""
        # Set hot spot in center
        heat_solver.set_initial_temperature(25.0)
        heat_solver.T[50] = 35.0  # Hot center cell
        
        initial_variance = np.var(heat_solver.T)
        
        # Evolve for a bit
        heat_solver.evolve(t_final=100, dt=heat_solver.dt_stable)
        
        final_variance = np.var(heat_solver.T)
        
        # Variance should decrease (smoothing)
        assert final_variance < initial_variance
    
    def test_time_tracking(self, heat_solver):
        """Test that simulation time is tracked correctly."""
        heat_solver.set_initial_temperature(30.0)
        t_final = 500.0
        heat_solver.evolve(t_final=t_final, dt=10.0)
        assert heat_solver.time == pytest.approx(t_final, rel=0.01)
    
    def test_energy_conservation_no_source(self, heat_solver):
        """Test energy conservation with no sources."""
        heat_solver.set_initial_temperature(30.0)
        initial_energy = np.sum(heat_solver.T)
        
        heat_solver.evolve(t_final=1000, dt=heat_solver.dt_stable)
        final_energy = np.sum(heat_solver.T)
        
        # Total energy should be conserved (no boundary flux, no sources)
        assert final_energy == pytest.approx(initial_energy, rel=0.01)


class TestHeatDiffusionCooling:
    """Test green space cooling effects."""
    
    def test_add_green_space_cooling(self, heat_solver):
        """Test adding cooling source."""
        heat_solver.set_initial_temperature(30.0)
        green_cells = [50, 51, 60, 61]
        cooling_rate = 2.0
        
        heat_solver.add_green_space_cooling(green_cells, cooling_rate)
        
        # Check source term is negative (cooling)
        for cell in green_cells:
            assert heat_solver.source[cell] < 0
    
    def test_cooling_effect_on_evolution(self, heat_solver):
        """Test that cooling reduces temperature."""
        # Set initial temperature
        initial_temp = 35.0
        heat_solver.set_initial_temperature(initial_temp)
        
        # Add strong cooling at specific cells
        green_cells = [45, 50, 55]
        heat_solver.add_green_space_cooling(green_cells, cooling_rate=10.0)
        
        # Record initial state
        initial_avg = np.mean(heat_solver.T)
        
        # Evolve
        heat_solver.evolve(t_final=2000, dt=10.0)
        
        # Average temperature should decrease with cooling
        final_avg = np.mean(heat_solver.T)
        assert final_avg < initial_avg
    
    def test_remove_cooling(self, heat_solver):
        """Test removing cooling sources by resetting source term."""
        green_cells = [10, 20, 30]
        heat_solver.add_green_space_cooling(green_cells, cooling_rate=2.0)
        
        # Reset source term
        heat_solver.source = np.zeros(heat_solver.grid.N)
        
        for cell in green_cells:
            assert heat_solver.source[cell] == 0.0


class TestHeatDiffusionNumericalStability:
    """Test numerical stability of solver."""
    
    def test_explicit_stability_with_small_dt(self, heat_solver):
        """Test explicit solver is stable with small timestep."""
        heat_solver.set_initial_temperature(30.0)
        heat_solver.T[50] = 40.0  # Hot spot
        
        # Use stable timestep
        dt = heat_solver.dt_stable * 0.5
        
        try:
            heat_solver.evolve(t_final=1000, dt=dt)
            # Should not blow up
            assert np.all(np.isfinite(heat_solver.T))
            assert np.max(heat_solver.T) < 100.0  # Reasonable bound
        except Exception as e:
            pytest.fail(f"Solver became unstable: {e}")
    
    def test_boundary_conditions(self, heat_solver):
        """Test boundary conditions are enforced."""
        # Set gradient at boundary
        heat_solver.set_initial_temperature(30.0)
        heat_solver.T[0] = 35.0  # Corner
        
        heat_solver.evolve(t_final=100, dt=heat_solver.dt_stable)
        
        # Check solution remains bounded
        assert np.all(heat_solver.T >= 20.0)
        assert np.all(heat_solver.T <= 40.0)


# ============================================================================
# ConnectivityAnalyzer Tests
# ============================================================================

class TestConnectivityAnalyzerInitialization:
    """Test connectivity analyzer initialization."""
    
    def test_init_4connected(self, medium_grid):
        """Test initialization with 4-connected grid."""
        analyzer = ConnectivityAnalyzer(medium_grid, connectivity=4)
        assert analyzer.connectivity == 4
        assert analyzer.grid == medium_grid
        assert isinstance(analyzer.graph, nx.Graph)
    
    def test_init_8connected(self, medium_grid):
        """Test initialization with 8-connected grid."""
        analyzer = ConnectivityAnalyzer(medium_grid, connectivity=8)
        assert analyzer.connectivity == 8
    
    def test_invalid_connectivity(self, medium_grid):
        """Test error on invalid connectivity."""
        with pytest.raises(ValueError, match="Connectivity must be 4 or 8"):
            ConnectivityAnalyzer(medium_grid, connectivity=6)
    
    def test_graph_construction(self, connectivity_analyzer):
        """Test that graph is properly constructed."""
        graph = connectivity_analyzer.graph
        
        # All cells should be nodes
        assert graph.number_of_nodes() == connectivity_analyzer.grid.N
        
        # Check edges exist
        assert graph.number_of_edges() > 0


class TestConnectivityAnalysis:
    """Test connectivity verification and component detection."""
    
    def test_verify_connectivity_single_component(self, connectivity_analyzer):
        """Test connectivity of a single connected component."""
        # Horizontal line
        solution = [10, 11, 12, 13, 14]
        is_connected = connectivity_analyzer.verify_connectivity(solution)
        assert is_connected
    
    def test_verify_connectivity_disconnected(self, connectivity_analyzer):
        """Test detection of disconnected components."""
        # Two separate cells
        solution = [10, 50]
        is_connected = connectivity_analyzer.verify_connectivity(solution)
        assert not is_connected
    
    def test_verify_connectivity_complex_shape(self, connectivity_analyzer):
        """Test connectivity of complex connected shape."""
        # L-shape
        solution = [22, 23, 24, 34, 44]
        is_connected = connectivity_analyzer.verify_connectivity(solution)
        assert is_connected
    
    def test_get_connected_components_single(self, connectivity_analyzer):
        """Test getting components when fully connected."""
        solution = [10, 11, 12, 20, 21, 22]
        components = connectivity_analyzer.get_connected_components(solution)
        assert len(components) == 1
        assert set(components[0]) == set(solution)
    
    def test_get_connected_components_multiple(self, connectivity_analyzer):
        """Test getting multiple components."""
        # Two separate clusters
        solution = [10, 11, 20, 21] + [50, 51, 60, 61]
        components = connectivity_analyzer.get_connected_components(solution)
        
        assert len(components) == 2
        assert len(components[0]) == 4
        assert len(components[1]) == 4
    
    def test_largest_connected_component(self, connectivity_analyzer):
        """Test finding largest component."""
        solution = [10, 11] + [50, 51, 52, 60, 61, 62]  # Sizes 2 and 6
        largest = connectivity_analyzer.get_largest_component(solution)
        
        assert len(largest) == 6
        assert 50 in largest


class TestConnectivityMetrics:
    """Test network metric calculations."""
    
    def test_compute_coverage(self, connectivity_analyzer):
        """Test coverage ratio computation."""
        solution = list(range(50))  # Half the grid
        coverage = len(solution) / connectivity_analyzer.grid.N
        assert coverage == pytest.approx(0.5, rel=0.01)
    
    def test_compute_metrics(self, connectivity_analyzer):
        """Test connectivity metrics computation."""
        solution = [10, 11, 12]
        metrics = connectivity_analyzer.compute_connectivity_metrics(solution)
        assert isinstance(metrics, dict)
        assert 'num_components' in metrics
    
    def test_network_properties(self, connectivity_analyzer):
        """Test network property calculations."""
        # Linear configuration
        solution = [10, 11, 12, 13, 14]
        
        # Get connected components
        components = connectivity_analyzer.get_connected_components(solution)
        assert len(components) == 1  # Should be connected


class TestConnectivityEdgeCases:
    """Test edge cases and error handling."""
    
    def test_empty_solution(self, connectivity_analyzer):
        """Test handling of empty solution."""
        is_connected = connectivity_analyzer.verify_connectivity([])
        assert is_connected  # Empty set is vacuously connected
    
    def test_single_cell(self, connectivity_analyzer):
        """Test single cell solution."""
        is_connected = connectivity_analyzer.verify_connectivity([50])
        assert is_connected
    
    def test_invalid_cell_indices(self, connectivity_analyzer):
        """Test handling of invalid cell indices."""
        # Invalid indices are ignored, so no error raised
        # Just test it doesn't crash
        try:
            result = connectivity_analyzer.verify_connectivity([1000])
            # May return True (empty valid set is connected)
            assert isinstance(result, bool)
        except (ValueError, KeyError):
            # Or may raise error
            pass


# ============================================================================
# Helper Functions Tests
# ============================================================================

class TestSyntheticGridGeneration:
    """Test synthetic grid generation utilities."""
    
    def test_create_synthetic_grid(self):
        """Test creation of synthetic test grid."""
        from core.spatial_modeling import create_synthetic_grid
        
        grid = create_synthetic_grid(
            n_rows=15,
            n_cols=15,
            cell_size=50.0,
            temp_range=(25, 35),
            random_seed=42
        )
        
        assert isinstance(grid, UrbanGrid)
        assert grid.n_rows == 15
        assert grid.n_cols == 15
        
        # Check temperatures are in range
        for i in range(grid.N):
            row, col = grid.unflatten_index(i)
            temp = grid.temperature[row, col]
            assert 25 <= temp <= 35


# ============================================================================
# Integration Tests
# ============================================================================

class TestSpatialModelingIntegration:
    """Integration tests combining multiple components."""
    
    def test_grid_to_heat_diffusion_workflow(self):
        """Test complete workflow from grid to heat diffusion."""
        # Create grid
        grid = UrbanGrid(n_rows=10, n_cols=10, cell_size=50.0)
        grid.set_temperature_field(np.full((10, 10), 30.0))
        
        # Create solver
        solver = HeatDiffusionSolver(grid, alpha=1e-5)
        solver.set_initial_temperature(30.0)
        
        # Add cooling
        green_cells = [44, 45, 54, 55]
        solver.add_green_space_cooling(green_cells, cooling_rate=3.0)
        
        # Evolve
        solver.evolve(t_final=1000, dt=10.0)
        
        # Check results
        assert np.mean(solver.T) < 30.0  # Average should decrease
    
    def test_grid_to_connectivity_workflow(self):
        """Test workflow from grid to connectivity analysis."""
        # Create grid
        grid = UrbanGrid(n_rows=10, n_cols=10, cell_size=50.0)
        
        # Analyze connectivity
        analyzer = ConnectivityAnalyzer(grid, connectivity=4)
        
        # Check solution
        solution = [33, 34, 43, 44, 45, 54, 55]
        is_connected = analyzer.verify_connectivity(solution)
        
        assert is_connected
        
        # Compute metrics
        coverage = len(solution) / analyzer.grid.N
        assert 0 < coverage < 1


# ============================================================================
# Performance Tests
# ============================================================================

class TestPerformance:
    """Test performance characteristics (should be fast)."""
    
    def test_grid_operations_fast(self, large_grid):
        """Test that grid operations are fast."""
        import time
        
        start = time.time()
        for i in range(100):
            _ = large_grid.get_neighbors(i)
            _ = large_grid.get_distance(i, i + 1)
        elapsed = time.time() - start
        
        # Should complete quickly
        assert elapsed < 1.0
    
    def test_heat_diffusion_single_step_fast(self, heat_solver):
        """Test single diffusion step is fast."""
        import time
        
        heat_solver.set_initial_temperature(30.0)
        
        start = time.time()
        heat_solver.step(dt=heat_solver.dt_stable)
        elapsed = time.time() - start
        
        # Single step should be very fast
        assert elapsed < 0.1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
