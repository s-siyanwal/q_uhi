"""
Comprehensive Unit Tests for Quantum Circuits Module

Tests the quantum_circuits module including:
- QAOACircuitBuilder: Circuit construction, parameter optimization
- VQESolver: Different ansatzes, optimization
- BackendManager: Backend selection and management
- CircuitOptimizer: Circuit optimization techniques
- Noise mitigation methods

Author: UHI-QUBO Testing Team
"""

import pytest
import numpy as np
from typing import List, Dict, Any

try:
    from qiskit import QuantumCircuit
    from qiskit.quantum_info import Statevector
    QISKIT_AVAILABLE = True
except ImportError:
    QISKIT_AVAILABLE = False

from core.quantum_circuits.qaoa_builder import QAOACircuitBuilder, QAOAResult
from core.quantum_circuits.vqe_ansatz import VQESolver, VQEResult
from core.quantum_circuits.backend_interface import BackendManager, QuantumBackend
from core.quantum_circuits.gate_decomposition import CircuitOptimizer
from core.quantum_circuits.noise_mitigation import (
    ZeroNoiseExtrapolation,
    MeasurementErrorMitigation
)


# Skip all tests if Qiskit not available
pytestmark = pytest.mark.skipif(not QISKIT_AVAILABLE, reason="Qiskit not installed")


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def tiny_qubo():
    """Tiny 3x3 QUBO for quick quantum tests."""
    Q = np.array([
        [-1, 0.5, 0],
        [0.5, -1, 0.5],
        [0, 0.5, -1]
    ])
    return Q


@pytest.fixture
def small_qubo():
    """Small 5x5 QUBO."""
    np.random.seed(42)
    Q = np.random.randn(5, 5)
    Q = (Q + Q.T) / 2
    return Q


@pytest.fixture
def diagonal_qubo():
    """Diagonal QUBO (easier to solve)."""
    return np.diag([-1, -2, -3, -4])


@pytest.fixture
def qaoa_builder():
    """QAOA circuit builder with p=1."""
    return QAOACircuitBuilder(p=1, seed=42)


@pytest.fixture
def qaoa_builder_multilayer():
    """QAOA builder with multiple layers."""
    return QAOACircuitBuilder(p=3, seed=42)


@pytest.fixture
def vqe_solver():
    """VQE solver with default ansatz."""
    return VQESolver(ansatz_type='ry', seed=42)


@pytest.fixture
def backend_manager():
    """Backend manager for simulations."""
    return BackendManager(backend_type='statevector')


# ============================================================================
# QAOACircuitBuilder Tests
# ============================================================================

class TestQAOACircuitBuilderInitialization:
    """Test QAOA circuit builder initialization."""
    
    def test_valid_initialization(self):
        """Test creating QAOA builder with valid parameters."""
        builder = QAOACircuitBuilder(p=2, seed=42)
        assert builder.p == 2
        assert builder.seed == 42
    
    def test_single_layer(self):
        """Test single-layer QAOA (p=1)."""
        builder = QAOACircuitBuilder(p=1)
        assert builder.p == 1
    
    def test_multiple_layers(self):
        """Test multi-layer QAOA (p=3)."""
        builder = QAOACircuitBuilder(p=3)
        assert builder.p == 3
    
    def test_invalid_p(self):
        """Test error on invalid p value."""
        with pytest.raises(ValueError):
            QAOACircuitBuilder(p=0)
        with pytest.raises(ValueError):
            QAOACircuitBuilder(p=-1)


class TestQAOACircuitConstruction:
    """Test QAOA circuit construction."""
    
    def test_build_circuit_small_problem(self, qaoa_builder, tiny_qubo):
        """Test building circuit for small problem."""
        gamma = [0.5]
        beta = [0.3]
        
        circuit = qaoa_builder.build_circuit(tiny_qubo, gamma, beta)
        
        assert isinstance(circuit, QuantumCircuit)
        assert circuit.num_qubits == 3
    
    def test_circuit_has_initial_state(self, qaoa_builder, tiny_qubo):
        """Test that circuit starts with |+⟩ state."""
        gamma = [0.5]
        beta = [0.3]
        
        circuit = qaoa_builder.build_circuit(tiny_qubo, gamma, beta)
        
        # Circuit should contain Hadamard gates at start
        # Check circuit depth > 0
        assert circuit.depth() > 0
    
    def test_parameter_count(self, qaoa_builder_multilayer, small_qubo):
        """Test correct number of parameters for p layers."""
        p = 3
        gamma = np.random.rand(p)
        beta = np.random.rand(p)
        
        circuit = qaoa_builder_multilayer.build_circuit(small_qubo, gamma, beta)
        
        assert circuit is not None
    
    def test_circuit_depth_increases_with_p(self, tiny_qubo):
        """Test that circuit depth increases with p."""
        builder1 = QAOACircuitBuilder(p=1)
        builder2 = QAOACircuitBuilder(p=3)
        
        gamma1 = [0.5]
        beta1 = [0.3]
        circuit1 = builder1.build_circuit(tiny_qubo, gamma1, beta1)
        
        gamma2 = [0.5, 0.4, 0.3]
        beta2 = [0.3, 0.2, 0.1]
        circuit2 = builder2.build_circuit(tiny_qubo, gamma2, beta2)
        
        assert circuit2.depth() > circuit1.depth()


class TestQAOAOptimization:
    """Test QAOA parameter optimization."""
    
    def test_optimize_qaoa_completes(self, qaoa_builder, tiny_qubo):
        """Test that QAOA optimization completes."""
        result = qaoa_builder.optimize_qaoa(
            tiny_qubo,
            method='COBYLA',
            maxiter=30
        )
        
        assert isinstance(result, QAOAResult)
        assert result.optimal_parameters is not None
        assert isinstance(result.optimal_energy, (int, float))
    
    def test_optimization_improves_energy(self, qaoa_builder, diagonal_qubo):
        """Test that optimization improves energy."""
        result = qaoa_builder.optimize_qaoa(
            diagonal_qubo,
            method='COBYLA',
            maxiter=50
        )
        
        # For diagonal QUBO with negative values, optimal should be negative
        assert result.optimal_energy < 0
    
    def test_convergence_history_recorded(self, qaoa_builder, tiny_qubo):
        """Test that convergence history is recorded."""
        result = qaoa_builder.optimize_qaoa(
            tiny_qubo,
            method='COBYLA',
            maxiter=20
        )
        
        assert len(result.convergence_history) > 0
        # Energy should generally decrease
        assert result.convergence_history[-1] <= result.convergence_history[0]
    
    def test_different_optimization_methods(self, qaoa_builder, tiny_qubo):
        """Test different classical optimization methods."""
        methods = ['COBYLA', 'Nelder-Mead']
        
        for method in methods:
            result = qaoa_builder.optimize_qaoa(
                tiny_qubo,
                method=method,
                maxiter=20
            )
            assert result.success or result.execution_counts > 0
    
    def test_metadata_contains_info(self, qaoa_builder, tiny_qubo):
        """Test that result metadata is populated."""
        result = qaoa_builder.optimize_qaoa(tiny_qubo, maxiter=20)
        
        assert 'circuit_depth' in result.metadata
        assert 'num_qubits' in result.metadata
        assert result.metadata['num_qubits'] == 3


class TestQAOAExpectationValue:
    """Test expectation value computation."""
    
    def test_compute_expectation_value(self, qaoa_builder, tiny_qubo):
        """Test computing expectation value."""
        gamma = [0.5]
        beta = [0.3]
        
        energy = qaoa_builder.compute_expectation_value(tiny_qubo, gamma, beta)
        
        assert isinstance(energy, (int, float))
        assert np.isfinite(energy)
    
    def test_expectation_value_with_circuit(self, qaoa_builder, tiny_qubo):
        """Test expectation value matches circuit measurement."""
        gamma = [0.5]
        beta = [0.3]
        
        energy1 = qaoa_builder.compute_expectation_value(tiny_qubo, gamma, beta)
        
        # Should be consistent
        energy2 = qaoa_builder.compute_expectation_value(tiny_qubo, gamma, beta)
        
        assert energy1 == pytest.approx(energy2, rel=1e-6)


# ============================================================================
# VQESolver Tests
# ============================================================================

class TestVQESolverInitialization:
    """Test VQE solver initialization."""
    
    def test_init_with_ry_ansatz(self):
        """Test initialization with RY ansatz."""
        solver = VQESolver(ansatz_type='ry', seed=42)
        assert solver.ansatz_type == 'ry'
        assert solver.seed == 42
    
    def test_init_with_hardware_efficient(self):
        """Test initialization with hardware-efficient ansatz."""
        solver = VQESolver(ansatz_type='hardware_efficient', seed=42)
        assert solver.ansatz_type == 'hardware_efficient'
    
    def test_init_with_custom_depth(self):
        """Test initialization with custom ansatz depth."""
        solver = VQESolver(ansatz_type='ry', depth=3, seed=42)
        assert solver.depth == 3
    
    def test_invalid_ansatz_type(self):
        """Test error on invalid ansatz type."""
        with pytest.raises(ValueError):
            VQESolver(ansatz_type='invalid_ansatz')


class TestVQESolve:
    """Test VQE solving."""
    
    def test_solve_small_problem(self, vqe_solver, tiny_qubo):
        """Test solving small problem with VQE."""
        result = vqe_solver.solve(tiny_qubo, maxiter=30)
        
        assert isinstance(result, VQEResult)
        assert result.optimal_parameters is not None
        assert isinstance(result.optimal_energy, (int, float))
    
    def test_solve_diagonal_qubo(self, vqe_solver, diagonal_qubo):
        """Test VQE on diagonal QUBO."""
        result = vqe_solver.solve(diagonal_qubo, maxiter=50)
        
        # Should find negative energy (all-ones solution)
        assert result.optimal_energy < 0
    
    def test_convergence_tracking(self, vqe_solver, tiny_qubo):
        """Test that VQE tracks convergence."""
        result = vqe_solver.solve(tiny_qubo, maxiter=30)
        
        assert len(result.convergence_history) > 0
    
    def test_extract_solution(self, vqe_solver, tiny_qubo):
        """Test extracting binary solution from VQE."""
        result = vqe_solver.solve(tiny_qubo, maxiter=30)
        
        solution = vqe_solver.extract_solution(result.optimal_parameters, tiny_qubo)
        
        assert len(solution) == 3
        assert all(x in [0, 1] for x in solution)


class TestVQEAnsatzes:
    """Test different VQE ansatzes."""
    
    @pytest.mark.parametrize("ansatz_type", ['ry', 'hardware_efficient'])
    def test_ansatz_types(self, ansatz_type, tiny_qubo):
        """Test different ansatz types work."""
        solver = VQESolver(ansatz_type=ansatz_type, seed=42)
        result = solver.solve(tiny_qubo, maxiter=20)
        
        assert result is not None
        assert isinstance(result.optimal_energy, (int, float))
    
    def test_ansatz_depth_variation(self, tiny_qubo):
        """Test varying ansatz depth."""
        depths = [1, 2, 3]
        
        for depth in depths:
            solver = VQESolver(ansatz_type='ry', depth=depth, seed=42)
            result = solver.solve(tiny_qubo, maxiter=20)
            assert result is not None


# ============================================================================
# BackendManager Tests
# ============================================================================

class TestBackendManagerInitialization:
    """Test backend manager initialization."""
    
    def test_init_statevector_backend(self):
        """Test initialization with statevector backend."""
        manager = BackendManager(backend_type='statevector')
        assert manager.backend_type == 'statevector'
    
    def test_init_qasm_backend(self):
        """Test initialization with QASM simulator."""
        manager = BackendManager(backend_type='qasm')
        assert manager.backend_type == 'qasm'
    
    def test_get_backend(self, backend_manager):
        """Test getting backend instance."""
        backend = backend_manager.get_backend()
        assert backend is not None
    
    def test_invalid_backend_type(self):
        """Test error on invalid backend type."""
        with pytest.raises(ValueError):
            BackendManager(backend_type='invalid_backend')


class TestBackendExecution:
    """Test circuit execution on backends."""
    
    def test_execute_circuit_statevector(self, backend_manager):
        """Test executing circuit on statevector simulator."""
        # Create simple circuit
        qc = QuantumCircuit(2)
        qc.h(0)
        qc.cx(0, 1)
        
        result = backend_manager.execute(qc)
        assert result is not None
    
    def test_execute_with_shots(self):
        """Test execution with specified number of shots."""
        manager = BackendManager(backend_type='qasm')
        
        qc = QuantumCircuit(2)
        qc.h(0)
        qc.measure_all()
        
        result = manager.execute(qc, shots=1000)
        assert result is not None
    
    def test_backend_switching(self):
        """Test switching between backends."""
        manager = BackendManager(backend_type='statevector')
        backend1 = manager.get_backend()
        
        manager.switch_backend('qasm')
        backend2 = manager.get_backend()
        
        # Backends should be different
        assert type(backend1).__name__ != type(backend2).__name__


# ============================================================================
# CircuitOptimizer Tests
# ============================================================================

class TestCircuitOptimizer:
    """Test circuit optimization."""
    
    def test_initialize_optimizer(self):
        """Test creating circuit optimizer."""
        optimizer = CircuitOptimizer()
        assert optimizer is not None
    
    def test_optimize_circuit(self):
        """Test basic circuit optimization."""
        optimizer = CircuitOptimizer()
        
        # Create unoptimized circuit
        qc = QuantumCircuit(3)
        qc.h(0)
        qc.x(1)
        qc.x(1)  # Redundant
        qc.h(0)
        qc.h(0)
        
        original_depth = qc.depth()
        
        optimized = optimizer.optimize(qc, level=1)
        
        # Optimized should be simpler or equal
        assert optimized.depth() <= original_depth
    
    def test_optimization_levels(self):
        """Test different optimization levels."""
        optimizer = CircuitOptimizer()
        
        qc = QuantumCircuit(3)
        for _ in range(5):
            qc.h(0)
            qc.cx(0, 1)
            qc.x(2)
        
        opt1 = optimizer.optimize(qc, level=1)
        opt2 = optimizer.optimize(qc, level=2)
        opt3 = optimizer.optimize(qc, level=3)
        
        # Higher optimization should give simpler or equal circuits
        assert opt3.depth() <= opt2.depth() <= opt1.depth()
    
    def test_gate_decomposition(self):
        """Test gate decomposition."""
        optimizer = CircuitOptimizer()
        
        qc = QuantumCircuit(2)
        qc.swap(0, 1)
        
        decomposed = optimizer.decompose_gates(qc)
        
        # SWAP should be decomposed to CNOTs
        assert decomposed is not None
    
    def test_optimization_preserves_functionality(self):
        """Test that optimization preserves circuit functionality."""
        optimizer = CircuitOptimizer()
        
        # Bell state preparation
        qc = QuantumCircuit(2)
        qc.h(0)
        qc.cx(0, 1)
        
        optimized = optimizer.optimize(qc, level=2)
        
        # Both should produce same statevector
        sv1 = Statevector.from_instruction(qc)
        sv2 = Statevector.from_instruction(optimized)
        
        assert sv1.equiv(sv2)


# ============================================================================
# Noise Mitigation Tests
# ============================================================================

class TestZeroNoiseExtrapolation:
    """Test zero-noise extrapolation."""
    
    def test_zne_initialization(self):
        """Test ZNE initialization."""
        zne = ZeroNoiseExtrapolation()
        assert zne is not None
    
    def test_zne_with_scale_factors(self):
        """Test ZNE with custom scale factors."""
        zne = ZeroNoiseExtrapolation(scale_factors=[1, 2, 3])
        assert zne.scale_factors == [1, 2, 3]


class TestMeasurementErrorMitigation:
    """Test measurement error mitigation."""
    
    def test_mem_initialization(self):
        """Test MEM initialization."""
        mem = MeasurementErrorMitigation()
        assert mem is not None


# ============================================================================
# Integration Tests
# ============================================================================

class TestQuantumCircuitsIntegration:
    """Integration tests combining multiple components."""
    
    def test_qaoa_with_backend(self, qaoa_builder, tiny_qubo, backend_manager):
        """Test QAOA with specific backend."""
        qaoa_builder.backend_manager = backend_manager
        
        result = qaoa_builder.optimize_qaoa(tiny_qubo, maxiter=20)
        
        assert result is not None
        assert isinstance(result.optimal_energy, (int, float))
    
    def test_vqe_with_optimization(self, tiny_qubo):
        """Test VQE with circuit optimization."""
        solver = VQESolver(ansatz_type='ry', seed=42)
        optimizer = CircuitOptimizer()
        
        result = solver.solve(tiny_qubo, maxiter=20)
        
        # Get optimized circuit
        circuit = solver.build_ansatz(len(tiny_qubo), result.optimal_parameters)
        optimized = optimizer.optimize(circuit, level=2)
        
        assert optimized.depth() <= circuit.depth()
    
    def test_qaoa_vs_vqe_comparison(self, tiny_qubo):
        """Compare QAOA and VQE on same problem."""
        qaoa = QAOACircuitBuilder(p=1, seed=42)
        vqe = VQESolver(ansatz_type='ry', seed=42)
        
        qaoa_result = qaoa.optimize_qaoa(tiny_qubo, maxiter=30)
        vqe_result = vqe.solve(tiny_qubo, maxiter=30)
        
        # Both should find reasonable solutions
        assert qaoa_result.optimal_energy < 0
        assert vqe_result.optimal_energy < 0


# ============================================================================
# Edge Cases and Error Handling
# ============================================================================

class TestQuantumCircuitsEdgeCases:
    """Test edge cases and error handling."""
    
    def test_single_qubit_qaoa(self, qaoa_builder):
        """Test QAOA with single qubit."""
        Q = np.array([[-1.0]])
        
        result = qaoa_builder.optimize_qaoa(Q, maxiter=10)
        assert result is not None
    
    def test_empty_qubo(self, qaoa_builder):
        """Test error on empty QUBO."""
        Q = np.array([[]]).reshape(0, 0)
        
        with pytest.raises(ValueError):
            qaoa_builder.optimize_qaoa(Q)
    
    def test_non_symmetric_qubo(self, qaoa_builder):
        """Test handling of non-symmetric QUBO."""
        Q = np.random.randn(3, 3)
        # Don't symmetrize
        
        # Should either symmetrize or raise error
        try:
            result = qaoa_builder.optimize_qaoa(Q, maxiter=10)
            # If it works, check result is valid
            assert result is not None
        except ValueError:
            # Or it correctly raises error
            pass
    
    def test_very_large_parameters(self, qaoa_builder, tiny_qubo):
        """Test QAOA with very large parameter values."""
        gamma = [100.0]
        beta = [100.0]
        
        # Should handle large parameters gracefully
        try:
            circuit = qaoa_builder.build_circuit(tiny_qubo, gamma, beta)
            assert circuit is not None
        except Exception:
            # Or raise appropriate error
            pass


# ============================================================================
# Performance Tests
# ============================================================================

class TestQuantumCircuitsPerformance:
    """Test performance characteristics."""
    
    def test_qaoa_optimization_time(self, qaoa_builder, tiny_qubo):
        """Test QAOA optimization completes quickly."""
        import time
        
        start = time.time()
        result = qaoa_builder.optimize_qaoa(tiny_qubo, maxiter=20)
        elapsed = time.time() - start
        
        # Should complete in reasonable time
        assert elapsed < 30.0  # 30 seconds for small problem
    
    def test_circuit_construction_fast(self, qaoa_builder, small_qubo):
        """Test circuit construction is fast."""
        import time
        
        gamma = [0.5]
        beta = [0.3]
        
        start = time.time()
        for _ in range(10):
            circuit = qaoa_builder.build_circuit(small_qubo, gamma, beta)
        elapsed = time.time() - start
        
        # 10 constructions should be fast
        assert elapsed < 5.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
