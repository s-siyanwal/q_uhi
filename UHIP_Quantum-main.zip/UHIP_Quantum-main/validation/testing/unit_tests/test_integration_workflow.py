"""
Comprehensive End-to-End Integration Tests

Tests complete workflows combining all modules:
- Grid → QUBO → Solver → Solution → Validation
- QUBO-Ising conversion
- Quantum circuit execution
- Real-world scenarios with toy examples

Author: UHI-QUBO Testing Team
"""

import pytest
import numpy as np
from typing import List, Dict, Any

# Spatial modeling
from core.spatial_modeling.urban_grid import UrbanGrid
from core.spatial_modeling.heat_diffusion import HeatDiffusionSolver
from core.spatial_modeling.connectivity_analyzer import ConnectivityAnalyzer

# QUBO formulation
from core.qubo_formulation.qubo_matrix_builder import QUBOMatrixBuilder
from core.qubo_formulation.ising_converter import IsingConverter

# Solvers
from core.solver_integration.solver_interface import (
    SimulatedAnnealingSolver,
    TabuSearchSolver,
    create_solver
)

# Quantum circuits (conditional on Qiskit)
try:
    from core.quantum_circuits.qaoa_builder import QAOACircuitBuilder
    from core.quantum_circuits.vqe_ansatz import VQESolver
    QISKIT_AVAILABLE = True
except ImportError:
    QISKIT_AVAILABLE = False


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def toy_grid():
    """Tiny 5x5 grid for integration tests."""
    grid = UrbanGrid(n_rows=5, n_cols=5, cell_size=50.0)
    
    # Set realistic temperature field (hot center)
    temps = np.full((5, 5), 30.0)
    temps[2, 2] = 35.0  # Hot center
    temps[1:4, 1:4] += 2.0
    grid.set_temperature_field(temps)
    
    # Mark some cells as prohibited (e.g., buildings)
    grid.set_prohibited_cells({0, 4, 20, 24})
    
    return grid


@pytest.fixture
def medium_grid():
    """Medium 10x10 grid for realistic tests."""
    grid = UrbanGrid(n_rows=10, n_cols=10, cell_size=100.0)
    
    # Create temperature gradient
    temps = np.zeros((10, 10))
    for i in range(10):
        for j in range(10):
            temps[i, j] = 28 + 2 * ((i - 4.5)**2 + (j - 4.5)**2) / 20
    grid.set_temperature_field(temps)
    
    return grid


@pytest.fixture
def simple_qubo():
    """Simple QUBO for integration."""
    Q = np.array([
        [1, -2, 0],
        [-2, 3, -1],
        [0, -1, 2]
    ])
    return Q


# ============================================================================
# Complete Workflow Tests
# ============================================================================

class TestCompleteWorkflow:
    """Test complete UHI-QUBO workflow from grid to solution."""
    
    def test_grid_to_solution_workflow(self, toy_grid):
        """
        Complete workflow:
        1. Create urban grid
        2. Build QUBO formulation
        3. Solve with classical solver
        4. Validate solution
        """
        # Step 1: Grid already created (fixture)
        assert toy_grid.N == 25
        
        # Step 2: Build simple QUBO formulation
        # For testing, create a minimal QUBO (temperature minimization)
        n_cells = toy_grid.N
        Q = np.zeros((n_cells, n_cells))
        
        # Objective: minimize temperature coverage
        for k in range(n_cells):
            if not toy_grid.cells[k].is_prohibited:
                row, col = toy_grid.unflatten_index(k)
                temp = toy_grid.temperature[row, col]
                Q[k, k] = -temp  # Negative to favor hot cells
        
        # Step 3: Solve with SA
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(Q, max_iterations=100)
        
        # Step 4: Validate solution
        assert len(result.solution) == n_cells
        assert all(x in [0, 1] for x in result.solution)
        
        # Check that prohibited cells are not selected
        for k in range(n_cells):
            if toy_grid.cells[k].is_prohibited:
                # May or may not be selected depending on penalty strength
                pass  # Just check solution is valid
    
    def test_grid_to_heat_diffusion_workflow(self, toy_grid):
        """
        Workflow with heat diffusion validation:
        1. Create grid and select cells
        2. Apply cooling with heat diffusion
        3. Validate temperature reduction
        """
        # Select some cells for green space
        green_cells = [6, 7, 11, 12, 13]
        
        # Create heat diffusion solver
        solver = HeatDiffusionSolver(toy_grid, alpha=1e-5, method='explicit')
        
        # Get all temperatures as 1D array
        temps_1d = np.zeros(toy_grid.N)
        for k in range(toy_grid.N):
            row, col = toy_grid.unflatten_index(k)
            temps_1d[k] = toy_grid.temperature[row, col]
        
        solver.set_initial_temperature(temps_1d)
        
        # Add cooling at green cells
        solver.add_green_space_cooling(green_cells, cooling_rate=2.0)
        
        # Get initial average temp
        initial_avg = np.mean(solver.T)
        
        # Evolve
        solver.evolve(t_final=500, dt=10.0)
        
        # Get final average temp
        final_avg = np.mean(solver.T)
        
        # Temperature should decrease
        assert final_avg < initial_avg
    
    def test_grid_to_connectivity_workflow(self, toy_grid):
        """
        Workflow with connectivity validation:
        1. Create grid
        2. Generate candidate solution
        3. Verify connectivity
        4. Compute metrics
        """
        # Create connectivity analyzer
        analyzer = ConnectivityAnalyzer(toy_grid, connectivity=4)
        
        # Candidate solution (connected L-shape)
        solution = [6, 7, 8, 13, 18]
        
        # Verify connectivity
        is_connected = analyzer.verify_connectivity(solution)
        assert is_connected
        
        # Compute metrics
        coverage = len(solution) / analyzer.grid.N
        assert 0 < coverage < 1
        
        components = analyzer.get_connected_components(solution)
        assert len(components) == 1


class TestQUBOFormulation:
    """Test QUBO formulation pipeline."""
    
    def test_qubo_matrix_basic(self, toy_grid):
        """Test basic QUBO matrix construction."""
        n = toy_grid.N
        
        # Create simple QUBO directly
        Q = np.zeros((n, n))
        
        # Add temperature objectives
        for k in range(n):
            row, col = toy_grid.unflatten_index(k)
            Q[k, k] = -toy_grid.temperature[row, col]
        
        # Add connectivity bonus
        for k in range(n):
            neighbors = toy_grid.get_neighbors(k)
            for neighbor in neighbors:
                if neighbor > k:  # Avoid double counting
                    Q[k, neighbor] = -0.5
                    Q[neighbor, k] = -0.5
        
        # Verify matrix properties
        assert Q.shape == (n, n)
        assert np.allclose(Q, Q.T)  # Symmetric
    
    def test_qubo_matrix_builder(self, toy_grid):
        """Test complete QUBO matrix construction."""
        n = toy_grid.N
        Q = np.zeros((n, n))
        
        # Add objective: temperature minimization
        for k in range(n):
            row, col = toy_grid.unflatten_index(k)
            temp = toy_grid.temperature[row, col]
            Q[k, k] = -temp
        
        # Add proximity bonus
        for k in range(n):
            neighbors = toy_grid.get_neighbors(k)
            for neighbor in neighbors:
                if neighbor > k:
                    Q[k, neighbor] = -0.5
                    Q[neighbor, k] = -0.5
        
        # Build matrix
        assert Q.shape == (n, n)
        assert np.allclose(Q, Q.T)  # Symmetric


class TestIsingConversion:
    """Test QUBO to Ising conversion."""
    
    def test_qubo_to_ising(self, simple_qubo):
        """Test converting QUBO to Ising model."""
        converter = IsingConverter()
        
        ising_model = converter.qubo_to_ising(simple_qubo)
        
        assert ising_model is not None
        assert hasattr(ising_model, 'h')  # Linear terms
        assert hasattr(ising_model, 'J')  # Quadratic terms
        assert hasattr(ising_model, 'offset')  # Constant offset
    
    def test_ising_to_qubo(self, simple_qubo):
        """Test converting Ising back to QUBO."""
        converter = IsingConverter()
        
        # QUBO -> Ising -> QUBO
        ising_model = converter.qubo_to_ising(simple_qubo)
        qubo_reconstructed = converter.ising_to_qubo(
            ising_model.h,
            ising_model.J,
            ising_model.offset
        )
        
        # Should match original (up to numerical precision)
        assert np.allclose(qubo_reconstructed, simple_qubo, atol=1e-6)
    
    def test_energy_equivalence(self, simple_qubo):
        """Test that QUBO and Ising energies are equivalent."""
        converter = IsingConverter()
        
        # Convert to Ising
        ising_model = converter.qubo_to_ising(simple_qubo)
        
        # Sample solution
        x_qubo = np.array([1, 0, 1])
        
        # Compute QUBO energy
        E_qubo = x_qubo @ simple_qubo @ x_qubo
        
        # Convert to Ising variables: s = 2x - 1
        s_ising = 2 * x_qubo - 1
        
        # Compute Ising energy
        E_ising = ising_model.offset
        for i, h in enumerate(ising_model.h):
            E_ising += h * s_ising[i]
        for (i, j), J in ising_model.J.items():
            E_ising += J * s_ising[i] * s_ising[j]
        
        # Energies should match
        assert E_qubo == pytest.approx(E_ising, rel=1e-6)


class TestSolverIntegration:
    """Test solver integration with QUBO formulation."""
    
    def test_multiple_solvers_same_problem(self, simple_qubo):
        """Test multiple solvers on same QUBO."""
        solvers = {
            'SA': SimulatedAnnealingSolver(seed=42),
            'TS': TabuSearchSolver(seed=42),
        }
        
        results = {}
        for name, solver in solvers.items():
            result = solver.solve(simple_qubo, max_iterations=100)
            results[name] = result
        
        # All should find valid solutions
        for name, result in results.items():
            assert len(result.solution) == 3
            assert all(x in [0, 1] for x in result.solution)
    
    def test_solver_with_constraints(self, toy_grid):
        """Test solver respecting prohibited cells."""
        n = toy_grid.N
        
        # Build QUBO with hard constraints for prohibited cells
        Q = np.zeros((n, n))
        
        # Objective
        for k in range(n):
            if not toy_grid.cells[k].is_prohibited:
                Q[k, k] = -1.0
            else:
                Q[k, k] = 1000.0  # Large penalty
        
        # Solve
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(Q, max_iterations=200)
        
        # Prohibited cells should have large penalty, so likely not selected
        # But we can't guarantee 100% since SA is probabilistic
        assert result is not None


# ============================================================================
# Quantum Circuit Integration Tests
# ============================================================================

@pytest.mark.skipif(not QISKIT_AVAILABLE, reason="Qiskit not installed")
class TestQuantumCircuitIntegration:
    """Test quantum circuit integration with QUBO."""
    
    def test_qaoa_on_grid_problem(self, toy_grid):
        """Test QAOA on grid-based QUBO."""
        # Create small QUBO from grid
        n = 5  # Use subset of grid
        Q = np.random.randn(n, n)
        Q = (Q + Q.T) / 2
        
        # Solve with QAOA
        qaoa = QAOACircuitBuilder(p=1, seed=42)
        result = qaoa.optimize_qaoa(Q, maxiter=30)
        
        assert result is not None
        assert isinstance(result.optimal_energy, (int, float))
    
    def test_vqe_on_grid_problem(self, toy_grid):
        """Test VQE on grid-based QUBO."""
        # Create small QUBO
        n = 5
        Q = np.random.randn(n, n)
        Q = (Q + Q.T) / 2
        
        # Solve with VQE
        vqe = VQESolver(ansatz_type='ry', seed=42)
        result = vqe.solve(Q, maxiter=30)
        
        assert result is not None
        assert isinstance(result.optimal_energy, (int, float))
    
    def test_qaoa_with_ising_conversion(self, simple_qubo):
        """Test QAOA with explicit Ising conversion."""
        # Convert to Ising
        converter = IsingConverter()
        ising_model = converter.qubo_to_ising(simple_qubo)
        
        # QAOA works with Ising Hamiltonian
        qaoa = QAOACircuitBuilder(p=1, seed=42)
        result = qaoa.optimize_qaoa(simple_qubo, maxiter=30)
        
        assert result is not None


# ============================================================================
# Validation Workflow Tests
# ============================================================================

class TestSolutionValidation:
    """Test solution validation workflows."""
    
    def test_validate_binary_solution(self):
        """Test that solution is binary."""
        solution = np.array([1, 0, 1, 0, 1])
        assert all(x in [0, 1] for x in solution)
        
        # Invalid solution
        invalid_solution = np.array([1, 0.5, 1])
        assert not all(x in [0, 1] for x in invalid_solution)
    
    def test_validate_budget_constraint(self):
        """Test budget constraint validation."""
        solution = np.array([1, 0, 1, 0, 1])
        budget = 3
        
        assert np.sum(solution) == budget
    
    def test_validate_connectivity(self, toy_grid):
        """Test connectivity validation."""
        analyzer = ConnectivityAnalyzer(toy_grid, connectivity=4)
        
        # Connected solution
        connected_solution = [6, 7, 11, 12]
        assert analyzer.verify_connectivity(connected_solution)
        
        # Disconnected solution
        disconnected_solution = [6, 18]
        assert not analyzer.verify_connectivity(disconnected_solution)
    
    def test_validate_prohibited_cells(self, toy_grid):
        """Test that prohibited cells are not selected."""
        solution = np.zeros(toy_grid.N, dtype=int)
        solution[[6, 7, 12]] = 1  # Select some cells
        
        # Check no prohibited cells selected
        prohibited = {0, 4, 20, 24}
        selected = {i for i, x in enumerate(solution) if x == 1}
        
        assert selected.isdisjoint(prohibited)


# ============================================================================
# Realistic Scenario Tests
# ============================================================================

class TestRealisticScenarios:
    """Test realistic UHI scenarios."""
    
    def test_small_city_scenario(self):
        """
        Test small city scenario:
        - 15x15 grid (225 cells)
        - Budget: 20 green cells
        - Connectivity required
        - Temperature reduction goal
        """
        # Create grid
        grid = UrbanGrid(n_rows=15, n_cols=15, cell_size=100.0)
        temps = np.random.uniform(28, 36, (15, 15))
        grid.set_temperature_field(temps)
        
        # Build simple QUBO (temperature only)
        n = grid.N
        Q = np.zeros((n, n))
        for k in range(n):
            Q[k, k] = -grid.get_temperature(k)
        
        # Solve
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(Q, max_iterations=500)
        
        # Validate
        assert len(result.solution) == n
        assert np.sum(result.solution) <= n  # Valid budget
    
    def test_constrained_optimization_scenario(self, medium_grid):
        """
        Test constrained optimization:
        - Medium grid with prohibited zones
        - Exact budget constraint
        - Connectivity requirement
        """
        # Mark some cells as prohibited
        prohibited = {0, 1, 2, 10, 20, 99}
        medium_grid.set_prohibited_cells(prohibited)
        
        # Get available cells
        available = medium_grid.get_candidate_cells()
        
        # Simple solver test
        solver = SimulatedAnnealingSolver(seed=42)
        
        # Reduced QUBO on available cells only
        n_available = len(available)
        Q = np.diag(np.random.randn(n_available))
        
        result = solver.solve(Q, max_iterations=200)
        
        assert len(result.solution) == n_available
    
    def test_multi_objective_scenario(self, toy_grid):
        """
        Test multi-objective optimization:
        - Temperature reduction
        - Connectivity
        - Population coverage
        """
        n = toy_grid.N
        Q = np.zeros((n, n))
        
        # Objective 1: Temperature (weight: 1.0)
        for k in range(n):
            row, col = toy_grid.unflatten_index(k)
            temp = toy_grid.temperature[row, col]
            Q[k, k] += -temp
        
        # Objective 2: Connectivity bonus (weight: 0.5)
        for k in range(n):
            neighbors = toy_grid.get_neighbors(k)
            for neighbor in neighbors:
                Q[k, neighbor] -= 0.5
        
        # Solve
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(Q, max_iterations=300)
        
        assert result is not None


# ============================================================================
# Performance and Scalability Tests
# ============================================================================

class TestScalability:
    """Test scalability of integration workflows."""
    
    def test_medium_grid_performance(self):
        """Test that medium grid problems solve in reasonable time."""
        import time
        
        # Create 15x15 grid
        grid = UrbanGrid(n_rows=15, n_cols=15, cell_size=100.0)
        temps = np.random.uniform(28, 34, (15, 15))
        grid.set_temperature_field(temps)
        
        # Build QUBO
        n = grid.N
        Q = np.zeros((n, n))
        for k in range(n):
            row, col = grid.unflatten_index(k)
            Q[k, k] = -grid.temperature[row, col]
        
        # Solve with time limit
        start = time.time()
        solver = SimulatedAnnealingSolver(seed=42)
        result = solver.solve(Q, max_iterations=500)
        elapsed = time.time() - start
        
        # Should complete in under 10 seconds
        assert elapsed < 10.0
    
    def test_connectivity_analysis_fast(self, medium_grid):
        """Test connectivity analysis is fast."""
        import time
        
        analyzer = ConnectivityAnalyzer(medium_grid, connectivity=4)
        
        # Random solution
        solution = np.random.choice(medium_grid.N, size=20, replace=False).tolist()
        
        start = time.time()
        is_connected = analyzer.verify_connectivity(solution)
        components = analyzer.get_connected_components(solution)
        elapsed = time.time() - start
        
        # Should be very fast
        assert elapsed < 1.0


# ============================================================================
# Edge Cases in Integration
# ============================================================================

class TestIntegrationEdgeCases:
    """Test edge cases in integrated workflows."""
    
    def test_empty_solution(self, toy_grid):
        """Test handling of empty solution."""
        analyzer = ConnectivityAnalyzer(toy_grid, connectivity=4)
        
        empty_solution = []
        is_connected = analyzer.verify_connectivity(empty_solution)
        
        # Empty is vacuously connected
        assert is_connected
    
    def test_all_cells_prohibited(self):
        """Test grid with all cells prohibited."""
        grid = UrbanGrid(n_rows=3, n_cols=3, cell_size=50.0)
        
        all_cells = set(range(grid.N))
        grid.set_prohibited_cells(all_cells)
        
        available = grid.get_candidate_cells()
        assert len(available) == 0
    
    def test_single_cell_solution(self, toy_grid):
        """Test solution with single cell."""
        analyzer = ConnectivityAnalyzer(toy_grid, connectivity=4)
        
        single_cell = [12]
        is_connected = analyzer.verify_connectivity(single_cell)
        
        assert is_connected
        
        components = analyzer.get_connected_components(single_cell)
        assert len(components) == 1
        assert components[0] == single_cell


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
