# UHI-QUBO Validation Framework

Production-ready validation modules for the UHI-QUBO research framework.

## Overview

This validation framework provides comprehensive testing and verification tools for UHI-QUBO (Urban Heat Island - Quadratic Unconstrained Binary Optimization) solutions. It includes toy examples, synthetic instance generators, constraint checkers, and multi-level solution validators.

## Modules

### 1. Test Cases (`validation/test_cases/`)

#### `toy_examples.py` - Small Verifiable Test Instances

Provides manually verifiable test problems for algorithm development and debugging:

- **4-cell example (2×2 grid)**: Minimal problem for basic testing
- **8-cell example (2×4 grid)**: Medium-scale with heterogeneous costs
- **Simple grid layouts**: Customizable grids with exact count constraints

```python
from validation.test_cases import get_4cell_example, get_all_toy_examples

# Get a single example
problem, solution = get_4cell_example()
print(f"Problem has {problem.n_candidates} candidate cells")
print(f"Expected solution: {solution.solution_vector}")

# Get all predefined examples
examples = get_all_toy_examples()
for name, (prob, sol) in examples.items():
    print(f"{name}: {prob.n_cells} cells, optimal={sol.is_optimal}")
```

**Features:**
- Known optimal or good solutions
- Manual verification notes
- Heterogeneous cell properties (costs, temperatures, land uses)
- Fixed green space examples
- Property verification utilities

#### `synthetic_instances.py` - Parametric Instance Generator

Generate random UHI-QUBO instances with controlled characteristics:

```python
from validation.test_cases import (
    generate_random_instance,
    generate_benchmark_suite,
    ProblemDifficulty,
    LandUseDistribution
)

# Generate single instance
problem, metadata = generate_random_instance(
    grid_size=10,
    difficulty=ProblemDifficulty.MEDIUM,
    land_use_dist=LandUseDistribution.CLUSTERED,
    seed=42
)

# Generate benchmark suite
suite = generate_benchmark_suite(
    grid_sizes=[5, 10, 15, 20],
    instances_per_config=3
)
print(f"Generated {len(suite)} benchmark instances")
```

**Parameters:**
- **Grid size**: 5×5 to 100×100+ grids
- **Difficulty levels**: EASY, MEDIUM, HARD, INFEASIBLE
- **Land use distributions**: UNIFORM, CLUSTERED, ZONED, CONCENTRIC
- **Constraint tightness**: Control feasibility region size
- **Reproducibility**: Seed-based generation

**Generators:**
- `generate_random_instance()`: Single instance with full control
- `generate_benchmark_suite()`: Cross-product of sizes × difficulties
- `generate_scaling_suite()`: Scaling analysis (logarithmic sizes)
- `generate_constraint_stress_test()`: Varying constraint tightness

### 2. Verification (`validation/verification/`)

#### `constraint_checker.py` - Constraint Satisfaction Verification

Comprehensive constraint checking with detailed violation reports:

```python
from validation.verification import ConstraintChecker

checker = ConstraintChecker(problem, tolerance=1e-6)
result = checker.check_all_constraints(solution)

if result.is_feasible:
    print("✓ All constraints satisfied")
else:
    print(f"✗ {result.n_violations} violations found")
    for violation in result.violations:
        if not violation.is_satisfied:
            print(f"  {violation.constraint_name}: "
                  f"exceeded by {violation.violation_amount:.2f} "
                  f"({violation.severity})")
```

**Constraint Types Checked:**
1. **Binary integrity**: Solution is in {0,1}ⁿ
2. **Area constraint**: ∑ area_i × x_i ≤ A_budget
3. **Budget constraint**: ∑ cost_i × x_i ≤ B_budget
4. **Cardinality**: min_cells ≤ ∑ x_i ≤ max_cells
5. **Spatial constraints**: Connectivity, separation (when defined)

**Violation Severity Levels:**
- `none`: No violation
- `minor`: < 5% over threshold
- `moderate`: 5-20% over threshold
- `severe`: > 20% over threshold

**Key Methods:**
- `check_all_constraints()`: Complete verification
- `check_constraint_type()`: Check specific constraint type
- `compute_total_violation_penalty()`: Aggregate penalty value

#### `solution_validator.py` - Multi-Level Solution Validation

Four-level comprehensive validation with detailed reporting:

```python
from validation.verification import SolutionValidator

validator = SolutionValidator(problem)
report = validator.validate_complete(solution, verbose=True)

print(f"Overall status: {report.overall_status.value}")
print(f"Valid: {report.is_valid}")
print(f"Execution time: {report.total_execution_time:.3f}s")

# Check specific levels
for level_name, level in report.levels.items():
    status = "✓ PASS" if level.passed else "✗ FAIL"
    print(f"  [{status}] {level.level_name}")
    for issue in level.issues:
        print(f"      • {issue}")
```

**Validation Levels:**

1. **Binary Integrity** (Critical)
   - Vector length matches problem size
   - All values in {0, 1}
   - No NaN or infinite values

2. **Constraint Satisfaction** (Critical)
   - Uses `ConstraintChecker` internally
   - Checks all problem constraints
   - Quantifies violations

3. **Energy Consistency** (Important)
   - QUBO energy calculation: E = x^T Q x
   - Energy decomposition verification
   - Comparison with expected energy

4. **Physical Plausibility** (Advisory)
   - Spatial distribution analysis
   - Cooling benefit estimation
   - Clustering detection
   - Warnings for unusual patterns

**Validation Statuses:**
- `VALID`: All checks passed
- `WARNING`: Passed with warnings (non-critical issues)
- `INVALID`: Critical failures detected
- `ERROR`: Validation could not complete

**Quick Validation:**
```python
# For rapid checking (binary + constraints only)
is_valid = validator.validate_quick(solution)
```

## Usage Examples

### Example 1: Algorithm Development Workflow

```python
from validation.test_cases import get_4cell_example
from validation.verification import SolutionValidator

# 1. Get toy problem
problem, expected_solution = get_4cell_example()

# 2. Build QUBO
Q, metadata = problem.build_qubo()

# 3. Solve with your algorithm
# solution = my_solver.solve(Q)

# 4. Validate solution
validator = SolutionValidator(problem)
report = validator.validate_complete(solution)

if not report.is_valid:
    print("Issues found:")
    for issue in report.get_all_issues():
        print(f"  - {issue}")
```

### Example 2: Solver Benchmarking

```python
from validation.test_cases import generate_benchmark_suite
from validation.verification import ConstraintChecker
import pandas as pd

# Generate benchmark suite
suite = generate_benchmark_suite(
    grid_sizes=[10, 20, 30],
    difficulties=[ProblemDifficulty.EASY, ProblemDifficulty.MEDIUM],
    instances_per_config=5
)

results = []
for problem, metadata in suite:
    # Solve
    Q, _ = problem.build_qubo()
    solution = my_solver.solve(Q)
    
    # Validate
    checker = ConstraintChecker(problem)
    result = checker.check_all_constraints(solution.best_solution)
    
    results.append({
        'size': metadata.grid_size[0],
        'difficulty': metadata.difficulty.value,
        'feasible': result.is_feasible,
        'energy': solution.best_energy,
        'violations': result.n_violations
    })

df = pd.DataFrame(results)
print(df.groupby(['size', 'difficulty']).mean())
```

### Example 3: Constraint Debugging

```python
from validation.verification import ConstraintChecker

checker = ConstraintChecker(problem)

# Check specific constraint type
area_violations = checker.check_constraint_type(solution, 'area')
budget_violations = checker.check_constraint_type(solution, 'budget')

for v in area_violations:
    print(f"Area: target={v.target_value:.1f}, "
          f"actual={v.actual_value:.1f}, "
          f"violation={v.violation_amount:.1f}")

# Compute total penalty
penalty = checker.compute_total_violation_penalty(solution)
print(f"Total penalty: {penalty:.2f}")
```

### Example 4: Scaling Analysis

```python
from validation.test_cases import generate_scaling_suite
import time

suite = generate_scaling_suite(
    min_size=10,
    max_size=100,
    num_sizes=10,
    instances_per_size=3
)

scaling_data = []
for problem, metadata in suite:
    start = time.time()
    Q, _ = problem.build_qubo()
    solution = my_solver.solve(Q)
    runtime = time.time() - start
    
    scaling_data.append({
        'n_candidates': metadata.n_candidates,
        'runtime': runtime,
        'energy': solution.best_energy
    })

# Analyze scaling behavior
import matplotlib.pyplot as plt
plt.loglog([d['n_candidates'] for d in scaling_data],
           [d['runtime'] for d in scaling_data], 'o-')
plt.xlabel('Number of candidates')
plt.ylabel('Runtime (s)')
plt.show()
```

## Testing

Comprehensive unit tests ensure correctness:

```bash
# Run all validation tests
python -m pytest validation/testing/test_validation_framework.py -v

# Run specific test class
python -m pytest validation/testing/test_validation_framework.py::TestConstraintChecker -v

# Run with coverage
python -m pytest validation/testing/test_validation_framework.py --cov=validation
```

**Test Coverage:**
- 23 unit tests across all modules
- Toy example generation and verification
- Synthetic instance generation with all parameters
- Constraint checking for all constraint types
- Multi-level solution validation
- Integration tests for full workflows

## Module Integration

The validation framework integrates seamlessly with the core UHI-QUBO modules:

```python
from core.problem_modeling.uhi_green_layout import UHIGreenLayoutProblem, UHIProblemConfig
from core.problem_modeling.cooling_kernels import GaussianCoolingKernel
from validation.test_cases import generate_random_instance
from validation.verification import SolutionValidator

# Core problem
config = UHIProblemConfig(grid_rows=10, grid_cols=10)
problem = UHIGreenLayoutProblem(config)
problem.setup_uniform_grid()
problem.setup_cooling_model(kernel=GaussianCoolingKernel(sigma=50, amplitude=-2))

# Or use validation generator
problem, metadata = generate_random_instance(grid_size=10, seed=42)

# Build and solve
Q, qubo_meta = problem.build_qubo()
# solution = solver.solve(Q)

# Validate
validator = SolutionValidator(problem)
report = validator.validate_complete(solution.best_solution)
```

## API Reference

### Toy Examples

| Function | Returns | Description |
|----------|---------|-------------|
| `get_4cell_example()` | (problem, solution) | 2×2 grid, 4 candidates |
| `get_8cell_example()` | (problem, solution) | 2×4 grid, 7-8 candidates |
| `get_simple_grid_layout(r, c, k)` | (problem, solution) | r×c grid, select exactly k |
| `get_all_toy_examples()` | dict | All predefined examples |
| `verify_toy_example_properties()` | dict | Verify example correctness |

### Synthetic Instances

| Function | Returns | Description |
|----------|---------|-------------|
| `generate_random_instance()` | (problem, metadata) | Single random instance |
| `generate_benchmark_suite()` | list[(problem, metadata)] | Cross-product suite |
| `generate_scaling_suite()` | list[(problem, metadata)] | Scaling analysis suite |
| `generate_constraint_stress_test()` | list[(problem, metadata)] | Constraint tightness suite |

### Constraint Checker

| Method | Returns | Description |
|--------|---------|-------------|
| `check_all_constraints()` | ConstraintCheckResult | Complete constraint check |
| `check_constraint_type()` | list[ConstraintViolation] | Check specific type |
| `compute_total_violation_penalty()` | float | Aggregate penalty |

### Solution Validator

| Method | Returns | Description |
|--------|---------|-------------|
| `validate_complete()` | ValidationReport | 4-level validation |
| `validate_quick()` | bool | Fast binary + constraint check |
| `print_report()` | None | Pretty-print report |

## Data Structures

### InstanceMetadata
```python
metadata.seed                    # Random seed used
metadata.grid_size               # (rows, cols)
metadata.n_candidates            # Number of candidate cells
metadata.difficulty              # ProblemDifficulty enum
metadata.constraint_tightness    # 0-1, lower is tighter
metadata.land_use_distribution   # LandUseDistribution enum
```

### ConstraintCheckResult
```python
result.is_feasible              # Overall feasibility
result.n_violations             # Number of violated constraints
result.violations               # List[ConstraintViolation]
result.max_violation_percentage # Worst violation %
result.constraint_details       # Detailed breakdown
```

### ValidationReport
```python
report.overall_status           # ValidationStatus enum
report.is_valid                 # Boolean validity
report.levels                   # Dict of ValidationLevel objects
report.solution_statistics      # Solution stats
report.get_all_issues()         # All issues across levels
report.get_all_warnings()       # All warnings
```

## Performance

- **Toy example generation**: < 1ms per example
- **Random instance generation (10×10)**: ~5ms
- **Benchmark suite (100 instances)**: < 1s
- **Constraint checking**: < 1ms for small problems, < 10ms for 100×100
- **Complete validation**: 1-5ms (depends on QUBO build time)

## Requirements

- Python 3.8+
- NumPy 1.20+
- Core UHI-QUBO modules (`core.problem_modeling`, `core.qubo_formulation`)
- Optional: pytest (for running tests)

## Citation

If you use this validation framework in your research, please cite:

```bibtex
@software{uhi_qubo_validation,
  title={UHI-QUBO Validation Framework},
  author={UHI-QUBO Research Team},
  year={2024},
  url={https://github.com/your-repo/UHIP_Quantum}
}
```

## License

See LICENSE file in repository root.

## Contributing

Contributions welcome! Please:
1. Add tests for new functionality
2. Follow existing code style
3. Update documentation
4. Ensure all tests pass

## Support

For issues or questions:
- Open an issue on GitHub
- Check existing documentation
- Review test cases for usage examples
